<?php

/**
 * Plugin Name: Reform Contact Form
 * Plugin URI: https://vlthemes.me/reform/
 * Description: Contact forms written in plain HTML, with fields you drag in, conditions, stored entries and templates your theme can restyle.
 * Version: 1.0.0
 * Author: VLThemes
 * Author URI: https://vlthemes.me/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: reform-contact-form
 * Requires at least: 6.5
 * Requires PHP: 7.4
 */
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/src/Autoloader.php';

VLT\Reform\Autoloader::register( __DIR__ . '/src' );
VLT\Reform\Plugin::boot( __FILE__ );
