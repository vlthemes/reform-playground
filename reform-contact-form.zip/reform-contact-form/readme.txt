=== ReForm – Contact Form Builder with Conditional Fields & Entries ===
Contributors: vlthemes
Tags: contact form, form builder, conditional fields, entries, captcha
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Contact forms written in plain HTML. Drag fields in, show parts on conditions, keep every message, and let your theme style it all.

== Description ==

🧪 [Try it in WordPress Playground](https://playground.wordpress.net/?blueprint-url=https%3A%2F%2Fraw.githubusercontent.com%2Fvlthemes%2Freform-playground%2Fmain%2Fblueprint.json) · 📖 [Documentation](https://vlthemes.me/docs/reform/) · 💬 [Ideas or bugs? Tell us](https://wordpress.org/support/plugin/reform-contact-form/)

ReForm is a contact form plugin for people who like their own markup, and a drop-in replacement for Contact Form 7: it imports your CF7 forms and keeps their shortcodes working. A form is plain HTML: you drag fields into it from a toolbar, and each field's settings sit in a sidebar instead of inside a cryptic tag. Switch to Visual and you see the form with your theme's styles while you work. Everything is free: there is no Pro version.

= ✍️ An editor that stays out of the way =

* Plain HTML with a chip for each field. Drag fields in, drag chips around, double-click one to remove it.
* Click a chip to set the field up in the sidebar: its type, options, limits, style, classes and attributes.
* Visual view: the form with your theme's styles, updated as you type. Click a field there to edit it.
* A tip with an example for the field you picked, at the bottom of the editor.
* Describe your form (WordPress 7.0+ with an AI service connected): say what you need and the site's AI writes the form. One click undoes it.
* Save as draft, duplicate, and a Beautify button for the markup.

= 🧩 17 field types =

* Text, email, URL, phone, number, date and textarea.
* Select, checkboxes and radio buttons. Checkboxes can allow one at a time.
* Acceptance, a quiz against bots, file upload and hidden values.
* Submit, as a button or a link.
* Output, a live mirror of what someone types in another field ("Thanks, Ann!").
* Count, the characters typed in another field ("120 characters left").
* Every field can be required and get its own classes, ID, attributes and style.
* A field can start with a value from the link (?product=pro), a shortcode attribute, a custom field of the page or the logged-in user.

= 🔀 Conditions =

Select some code, right-click and make it a group. Show or hide the group depending on what visitors pick or type: is, is not, contains, is empty, greater than and more, with all or any of the rules. Groups can be nested. Fields in a hidden group aren't checked or sent, and the server checks the same rules again.

= ✉️ Mail =

* Two mails per form: one to you, one optional copy for the sender.
* Mail tags such as [your_name], option labels or raw values, and blocks that show only when their group does.
* Special tags for the site, the page, the visitor and the date.
* HTML or plain text, and uploaded files as attachments.
* The Mail tab points out unknown tags and addresses that won't work.

= 🗄️ Entries =

* Every message is saved in Contact Form → Entries, even when the mail fails.
* Unread ones stand out. Filter by form and export a CSV.
* WordPress's personal data export and erase tools find them.
* Delete them after a number of days, or turn saving off for a form.

= 🛡️ Spam =

* On every form, without bothering anyone: a honeypot, a minimum time to fill the form, a limit per visitor and your Disallowed Comment Keys (Settings → Discussion).
* Add Cloudflare Turnstile, hCaptcha or Google reCAPTCHA v3 to a form.
* Check messages with Akismet.

= 🎨 Made for themes =

* Each field and the response box are templates your theme can override, or add styles to, from its own reform/ folder.
* The default look uses CSS variables, and one setting or filter turns it off.
* A small script and styles, only on pages that show a form. No jQuery, and forms still work with JavaScript turned off.
* Hooks for every step, in the spirit of Contact Form 7's, and an API to add field types.

= 📍 Place it anywhere =

The Contact Form block, the Elementor widget, the WPBakery element, a classic widget or the [reform id="…"] shortcode.

= 🚚 Move in and out =

* Import your Contact Form 7 forms with their fields, mails and messages. Mail tags stay the same, and old [contact-form-7] shortcodes keep working once CF7 is off.
* Export every form to one file and import it on another site (Settings → Export & import).
* Copy a single form's code to another site from its Advanced tab.

= 🧪 Safe to test =

Test mode checks the fields and sends nothing; "Don't send mail" still saves entries. Turn them on per form, or for the whole site with REFORM_TEST_MODE and REFORM_DISABLE_MAIL in wp-config.php.

= 🔌 Also =

* Webhooks: each message posted as JSON to Zapier, Make, n8n or your own code.
* "Logged-in users only" per form.
* Abilities for AI assistants (WordPress 6.9+): list, read, create and update forms, and read entries.

== Installation ==

1. Install and activate the plugin.
2. Go to Contact Form → Add New. The new form starts with name, email, subject and message fields.
3. Copy its shortcode, or add the Contact Form block, the Elementor widget or the WPBakery element to a page.

== Frequently Asked Questions ==

= Can I try it first? =

Yes. [Open the demo in WordPress Playground](https://playground.wordpress.net/?blueprint-url=https%3A%2F%2Fraw.githubusercontent.com%2Fvlthemes%2Freform-playground%2Fmain%2Fblueprint.json): a site in your browser with three ready forms. Nothing is installed anywhere.

= Can I move my Contact Form 7 forms? =

Yes. Contact Form → Settings → Migrate from CF7 brings each form over with its fields, both mails, its messages and its additional settings. Field names stay the same, so mail tags keep working, and your Contact Form 7 forms aren't changed. Once you turn Contact Form 7 off, its [contact-form-7] shortcodes show the imported forms.

= Can I move my forms to another site? =

Yes. Settings → Export & import downloads every form in one file; import that file on the other site. A form keeps its shortcode unless the other site already has a form with it. For one form, copy its code from its Advanced tab and paste it into a form on the other site.

= Where is the source of the editor's script? =

The form editor is built from the files in assets/src/editor, which ship with the plugin. They are bundled with @wordpress/scripts into assets/build.

= Why don't my mails arrive? =

Reform hands mails to WordPress, which needs a working mail setup. If mails go missing, use an SMTP plugin. The message is saved in Entries either way.

= How do I style the form? =

Set the --reform-* CSS variables in your theme, override the templates in your-theme/reform/, or turn the default look off with the reform_default_styles filter.

== External services ==

Reform connects to these services only when you turn them on:

* Cloudflare Turnstile, when a form uses it: the widget loads from challenges.cloudflare.com and each answer is checked there. [Terms](https://www.cloudflare.com/website-terms/), [privacy policy](https://www.cloudflare.com/privacypolicy/).
* hCaptcha, when a form uses it: the widget loads from js.hcaptcha.com and each answer is checked at api.hcaptcha.com. [Terms](https://www.hcaptcha.com/terms), [privacy policy](https://www.hcaptcha.com/privacy).
* Google reCAPTCHA v3, when a form uses it: the script loads from google.com and each token is checked there. [Terms](https://policies.google.com/terms), [privacy policy](https://policies.google.com/privacy).
* Akismet, when you turn it on in Settings → Spam: the sender's name, email, message, IP address and browser are sent to Akismet to be checked. [Privacy policy](https://automattic.com/privacy/).
* Webhooks, when you add addresses to a form: each message is sent to the addresses you entered.

== Changelog ==

= 1.0.0 =
* First release.
