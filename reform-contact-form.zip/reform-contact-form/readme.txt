=== ReForm – Contact Form Builder with Conditional Fields & Entries ===
Contributors: vlthemes
Tags: contact form, form builder, conditional fields, stripe, paypal
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Contact forms written in plain HTML. Drag fields in, show parts on conditions, keep every message, and let your theme style it all.

== Description ==

🧪 [Try it in WordPress Playground](https://playground.wordpress.net/?blueprint-url=https%3A%2F%2Fraw.githubusercontent.com%2Fvlthemes%2Freform-playground%2Fmain%2Fblueprint.json) · 📖 [Documentation](https://vlthemes.me/docs/reform/) · 💬 [Ideas or bugs? Tell us](https://wordpress.org/support/plugin/reform-contact-form/)

ReForm is a contact form plugin for people who like their own markup, and a drop-in replacement for Contact Form 7: it imports your CF7 forms and keeps their shortcodes working. A form is plain HTML: you drag fields into it from a toolbar, and each field's settings sit in a sidebar instead of inside a cryptic tag. Preview shows the form with your theme's styles before you save. Everything is free: there is no Pro version.

= ✍️ An editor that stays out of the way =

* Plain HTML with a chip for each field. Drag fields in, drag chips around, double-click one to remove it.
* Click a chip to set the field up in the sidebar: its type, options, limits, style, classes and attributes.
* Preview: the unsaved form with your theme's styles, updated as you type. Click a field there to edit it.
* A tip with an example for the field you picked, at the bottom of the editor.
* Describe your form (WordPress 7.0+ with an AI service connected): say what you need and the site's AI writes the form. One click undoes it.
* Save as draft, duplicate, and a Beautify button for the markup.

= 🧩 19 field types =

* Text, email, URL, phone, number, date and textarea.
* Select, checkboxes and radio buttons. Checkboxes can allow one at a time.
* Acceptance, a quiz against bots, file upload and hidden values.
* Submit, as a button or a link.
* Output, a live mirror of what someone types in another field ("Thanks, Ann!").
* Count, the characters typed in another field ("120 characters left").
* Stripe and PayPal payments: visitors pay in the form before their message goes. A set amount, or one taken from a field such as a select of plans.
* Every field can be required and get its own classes, ID, attributes and style.
* A field can start with a value from the link (?product=pro), a shortcode attribute, a custom field of the page or the logged-in user.

= 🔀 Conditions =

Select some code, right-click and make it a group. Show or hide the group depending on what visitors pick or type: is, is not, contains, is empty, greater than and more, with all or any of the rules. Groups can be nested. Fields in a hidden group aren't checked or sent, and the server checks the same rules again.

= ✉️ Mail =

* Two mails per form: one to you, one optional copy for the sender.
* Mail tags such as [your_name], option labels or raw values, and blocks that show only when their group does.
* Special tags for the site, the page, the visitor and the date.
* HTML or plain text, and uploaded files as attachments.
* The Mail tab points out unknown tags and addresses that won't work.

= 🗄️ Entries =

* Every message is saved in Contact Form → Entries, even when the mail fails.
* Unread ones stand out. Filter by form and export a CSV.
* WordPress's personal data export and erase tools find them, and a suggested text for your privacy policy is ready in Settings → Privacy.
* The visitor's IP is saved shortened by default; save it whole, or not at all, in Settings → Entries.
* Delete them after a number of days, or turn saving off for a form.

= 💳 Payments =

* Stripe and PayPal fields: visitors pay inside the form before their message goes, as with Contact Form 7's Stripe module.
* A set amount, or one taken from a field: a select of plans, a number, checkboxes that add up.
* The amount is worked out again on your server, and each payment is checked with Stripe or PayPal before the mail goes. One payment sends one message.
* The payment shows in the mail and in Entries. Test keys and PayPal's sandbox work for trying it out.
* No fees from ReForm: you paste your own keys in Settings → Payments.

= 🛡️ Spam =

* On every form, without bothering anyone: a honeypot, a minimum time to fill the form, a limit per visitor and your Disallowed Comment Keys (Settings → Discussion).
* Cloudflare Turnstile, hCaptcha and Google reCAPTCHA v3: save their keys once and they run on every form, alone or together. A form can skip them. They go before the send button, or wherever you drop the Captcha chip. reCAPTCHA's badge can be hidden for Google's line of text under the form.
* Check messages with Akismet.

= 🎨 Made for themes =

* Each field and the response box are templates your theme can override, or add styles to, from its own reform/ folder.
* The default look uses CSS variables, and one setting or filter turns it off.
* Hooks for every step, in the spirit of Contact Form 7's, and an API to add field types and chips of your own to the editor.
* Right-to-left languages: forms, the editor and the settings read the right way round in Arabic, Hebrew or Persian.

= ⚡ Lightweight =

* One small script and inline styles, only on pages that show a form. No jQuery.
* Payment and captcha scripts load only when a form needs them; Stripe's or PayPal's only once a visitor pays.
* Forms still work with JavaScript turned off.
* The whole plugin is a download of about 400 KB.

= 🔒 Private and safe =

* GDPR in mind: the visitor's IP is saved shortened by default, or whole, or not at all.
* Messages work with WordPress's privacy tools: a visitor can get a copy or have them erased.
* Delete entries after a number of days, or don't save them for a form.
* A suggested text for your privacy policy, in Settings → Privacy.
* Uploaded files sit in a folder the web can't open, their real type checked.
* Webhooks are set by administrators only and never reach your own network.
* Outside services (captchas, Akismet, webhooks, Stripe, PayPal) stay off until you turn them on.

= 📍 Place it anywhere =

The ReForm Contact Form block, Elementor widget, WPBakery element or classic widget, or the [reform id="…"] shortcode.

= 🚚 Move in and out =

* Import your Contact Form 7 forms with their fields, mails and messages. Mail tags stay the same, and old [contact-form-7] shortcodes keep working once CF7 is off.
* Export every form to one file and import it on another site (Settings → Export & import).
* Copy a single form's code to another site from its Advanced tab.

= 🧪 Safe to test =

Test mode checks the fields and sends nothing; "Don't send mail" still saves entries. Turn them on per form, or for the whole site with REFORM_TEST_MODE and REFORM_DISABLE_MAIL in wp-config.php.

= 🔌 Also =

* Webhooks: each message posted as JSON to Zapier, Make, n8n or your own code.
* "Logged-in users only" per form.
* Abilities for AI assistants (WordPress 6.9+): list, read, create and update forms, and read entries.

== Installation ==

1. Install and activate the plugin.
2. Go to Contact Form → Add New. The new form starts with name, email, subject and message fields.
3. Copy its shortcode, or add the ReForm Contact Form block, Elementor widget or WPBakery element to a page.

== Frequently Asked Questions ==

= Can I try it first? =

Yes. [Open the demo in WordPress Playground](https://playground.wordpress.net/?blueprint-url=https%3A%2F%2Fraw.githubusercontent.com%2Fvlthemes%2Freform-playground%2Fmain%2Fblueprint.json): a site in your browser with three ready forms. Nothing is installed anywhere.

= Can I move my Contact Form 7 forms? =

Yes. Contact Form → Settings → Migrate from CF7 brings each form over with its fields, both mails, its messages and its additional settings. Field names stay the same, so mail tags keep working. The markup comes over as you wrote it, neatly indented, without the <p> and <br> tags CF7 adds. Your Contact Form 7 forms aren't changed. Once you turn Contact Form 7 off, its [contact-form-7] shortcodes show the imported forms.

= Can I move my forms to another site? =

Yes. Settings → Export & import downloads every form in one file; import that file on the other site. A form keeps its shortcode unless the other site already has a form with it. For one form, copy its code from its Advanced tab and paste it into a form on the other site.

= Is it ready for the GDPR? =

ReForm gives you what the GDPR asks of a form plugin: messages can be exported or erased with WordPress's privacy tools, deleted after a number of days or not saved at all, the visitor's IP is shortened by default, an acceptance box asks for consent, and a suggested privacy policy text lists what is collected. Outside services (captchas, Akismet, webhooks, payments) are off until you turn them on. Your own privacy policy and how you use the messages are still up to you.

= Where is the source of the editor's script? =

The form editor is built from the files in assets/src/editor, which ship with the plugin. They are bundled with @wordpress/scripts into assets/build.

= Why don't my mails arrive? =

ReForm hands mails to WordPress, which needs a working mail setup. If mails go missing, use an SMTP plugin. The message is saved in Entries either way.

= How do I take payments? =

Paste your Stripe keys or PayPal app's client ID and secret in Contact Form → Settings → Payments. Then add a Stripe or PayPal payment field to a form from the editor's More menu and set its amount, or pick the field it comes from. Visitors send the form, pay in it, and the message goes once the payment is through. Try it first with Stripe's test keys or PayPal's sandbox.

= How do I style the form? =

Set the --reform-* CSS variables in your theme, override the templates in your-theme/reform/, or turn the default look off with the reform_default_styles filter.

== External services ==

ReForm connects to these services only when you turn them on:

* Cloudflare Turnstile, when a form uses it: the widget loads from challenges.cloudflare.com and each answer is checked there. [Terms](https://www.cloudflare.com/website-terms/), [privacy policy](https://www.cloudflare.com/privacypolicy/).
* hCaptcha, when a form uses it: the widget loads from js.hcaptcha.com and each answer is checked at api.hcaptcha.com. [Terms](https://www.hcaptcha.com/terms), [privacy policy](https://www.hcaptcha.com/privacy).
* Google reCAPTCHA v3, when a form uses it: the script loads from google.com and each token is checked there. [Terms](https://policies.google.com/terms), [privacy policy](https://policies.google.com/privacy).
* Akismet, when you turn it on in Settings → Spam: the sender's name, email, message, IP address and browser are sent to Akismet to be checked. [Privacy policy](https://automattic.com/privacy/).
* Webhooks, when you add addresses to a form: each message is sent to the addresses you entered.
* Stripe, when a form has a Stripe payment field: once the visitor sends the form, the payment's amount, currency, description and the visitor's email are sent to api.stripe.com, the card fields load from js.stripe.com, and the payment is checked there before the message goes. [Terms](https://stripe.com/legal/ssa), [privacy policy](https://stripe.com/privacy).
* PayPal, when a form has a PayPal payment field: once the visitor sends the form, the payment's amount, currency and description are sent to api-m.paypal.com, the buttons load from paypal.com, and the payment is checked and taken there before the message goes. [Terms](https://www.paypal.com/legalhub/useragreement-full), [privacy policy](https://www.paypal.com/myaccount/privacy/privacyPrevious).

== Changelog ==

= 1.0.0 =
* First release.
