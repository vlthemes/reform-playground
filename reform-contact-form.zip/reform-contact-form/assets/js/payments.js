/**
 * Payments of Reform forms (Stripe, PayPal): when the first Send asks for a payment (reform:payment), the provider's
 * card fields or buttons show in the form and the rest of it stays as sent; once paid, the payment's ID goes in the
 * field and the form is sent again. reform.js loads this script with that first reply, and the provider's script
 * loads only then too.
 */
(() => {
	const scripts = {};

	const load = (src) =>
		(scripts[src] ||= new Promise((resolve, reject) => {
			const script = document.createElement('script');

			script.src = src;
			script.onload = resolve;
			script.onerror = reject;
			document.head.append(script);
		}));

	// Each shows the payment in box, calls done( id ) once paid, fail( message ) on an error; returns a clean-up
	const providers = {
		stripe: async (box, payment, done, fail) => {
			await load('https://js.stripe.com/v3/');

			const stripe = window.Stripe(box.dataset.key);
			const elements = stripe.elements({ clientSecret: payment.secret });
			const element = elements.create('payment');
			const pay = box.querySelector('.reform-payment__pay');

			element.mount(box.querySelector('.reform-payment__element'));
			pay.textContent = (box.dataset.label || '{amount}').split('{amount}').join(payment.amount);
			pay.onclick = async () => {
				pay.disabled = true;
				fail('');

				// Cards and wallets only (the server asks for no redirects), so the page stays
				const { error, paymentIntent } = await stripe.confirmPayment({ elements, redirect: 'if_required', confirmParams: { return_url: window.location.href } });

				pay.disabled = false;

				if (error) {
					fail(error.message || payment.failed);
				} else if (paymentIntent?.status === 'succeeded') {
					done(paymentIntent.id);
				}
			};

			return () => element.destroy();
		},

		paypal: async (box, payment, done, fail) => {
			await load(`https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(box.dataset.key)}&currency=${payment.currency}&intent=capture&components=buttons`);

			const buttons = window.paypal.Buttons({
				createOrder: () => payment.order,
				onApprove: () => done(payment.order),
				onError: () => fail(payment.failed),
			});

			await buttons.render(box.querySelector('.reform-payment__element'));

			return () => buttons.close();
		},
	};

	// Back to the form as it was: the payment hidden, the fields open again
	const close = (form) => {
		const paying = form.reformPaying;

		if (!paying) {
			return;
		}

		form.reformPaying = null;
		paying.destroy?.();
		paying.box.hidden = true;
		paying.box.querySelector('.reform-payment__element').replaceChildren();
		paying.locked.forEach((el) => (el.inert = false));
		form.closest('.reform')?.classList.remove('is-paying');
	};

	document.addEventListener('reform:payment', async (event) => {
		const { form, response } = event.detail;
		const payment = response?.data?.payment;
		const wrap = payment && form.querySelector(`[data-reform-field="${CSS.escape(payment.field)}"]`);
		const box = wrap?.querySelector('[data-reform-payment]');
		const provider = box && providers[box.dataset.reformPayment];

		if (!provider) {
			return;
		}

		close(form);

		const input = wrap.querySelector(`input[name="${CSS.escape(payment.field)}"]`);
		const error = box.querySelector('.reform-payment__error');
		const fail = (message) => {
			error.textContent = message;
			error.hidden = !message;
		};
		// The amount was worked out from what was sent: those fields wait
		const locked = [...form.querySelectorAll('[data-reform-field]')].filter((el) => el !== wrap && !el.inert);
		const paying = { box, locked };

		locked.forEach((el) => (el.inert = true));
		form.reformPaying = paying;
		form.closest('.reform')?.classList.add('is-paying');
		box.hidden = false;
		fail('');
		box.querySelector('.reform-payment__cancel').onclick = () => close(form);

		try {
			paying.destroy = await provider(box, payment, (id) => {
				input.value = id;
				form.requestSubmit();
			}, fail);

			// Closed while the provider's script was loading
			if (form.reformPaying !== paying) {
				paying.destroy?.();
			}
		} catch {
			fail(payment.failed);
		}

		box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
	});

	// Any other reply ends the payment step; the IDs sent go with it
	document.addEventListener('reform:sent', (event) => {
		const { form, response } = event.detail;

		if (response?.status === 'payment') {
			return;
		}

		close(form);
		form.querySelectorAll('[data-reform-payment]').forEach((box) => {
			const input = box.previousElementSibling;

			if (input?.type === 'hidden') {
				input.value = '';
			}
		});
	});
})();
