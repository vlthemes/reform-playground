/**
 * Captchas of Reform forms: a reCAPTCHA v3 token asked for as the form is sent, Turnstile and hCaptcha widgets
 * reset after each reply (their answers work once)
 */
(() => {
	const reform = window.reform;

	if (!reform) {
		return;
	}

	reform.beforeSend.push(async (form) => {
		const input = form.querySelector('[data-reform-captcha="recaptcha"]');

		if (!input || !window.grecaptcha) {
			return;
		}

		await new Promise((resolve) => window.grecaptcha.ready(resolve));
		input.value = await window.grecaptcha.execute(input.dataset.sitekey, { action: 'contact_form' });
	});

	document.addEventListener('reform:sent', (event) => {
		const widget = event.target.querySelector('[data-reform-captcha]');

		if (widget?.dataset.reformCaptcha === 'turnstile') {
			window.turnstile?.reset(`#${widget.id}`);
		} else if (widget?.dataset.reformCaptcha === 'hcaptcha') {
			window.hcaptcha?.reset(widget.querySelector('iframe')?.dataset.hcaptchaWidgetId);
		}
	});
})();
