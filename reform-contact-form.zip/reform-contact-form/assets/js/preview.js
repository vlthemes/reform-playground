/**
 * The editor's Visual view (Admin\Preview), static: a click on a field selects it in the editor, the editor's selection
 * is outlined here, and the scroll position survives each reload
 */
(() => {
	const key = 'reform-preview-scroll';

	try {
		window.scrollTo(0, Number(sessionStorage.getItem(key)) || 0);
		window.addEventListener('scroll', () => sessionStorage.setItem(key, String(window.scrollY)), { passive: true });
	} catch {}

	// Static: a click selects the field, nothing gets focus, opens, ticks or is sent
	['click', 'mousedown', 'submit'].forEach((type) =>
		document.addEventListener(
			type,
			(event) => {
				event.stopPropagation();
				event.preventDefault();

				const field = 'click' === type && event.target.closest?.('[data-reform-field]');

				if (field) {
					window.parent.postMessage({ reform: 'select', name: field.dataset.reformField }, '*');
				}
			},
			true
		)
	);

	window.addEventListener('message', (event) => {
		if (event.source !== window.parent || event.data?.reform !== 'selected') {
			return;
		}

		document.querySelectorAll('.is-reform-selected').forEach((el) => el.classList.remove('is-reform-selected'));
		document.querySelectorAll(`[data-reform-field="${CSS.escape(event.data.name || '')}"]`).forEach((el) => el.classList.add('is-reform-selected'));
	});
})();
