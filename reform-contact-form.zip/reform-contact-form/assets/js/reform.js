/**
 * Reform forms: checks fields, shows and hides groups, mirrors output fields, counts characters and sends without a reload
 *
 * Events on the <form>, with detail { id, form, response }:
 *   reform:submit (cancelable, before sending), reform:sent (any reply), reform:success, reform:invalid,
 *   reform:failed, reform:spam, reform:aborted, reform:payment (a payment to make first: payments.js), reform:reset
 * Forms added later (popups, AJAX): window.reform.init( element ). window.reform.beforeSend: async steps before
 * sending. Captchas are handled here: reCAPTCHA v3's token asked for as the form is sent, Turnstile and hCaptcha
 * widgets reset after each reply (their answers work once). A reply's data.script (the payment script) loads before
 * its event fires.
 */
(() => {
	const data = window.reformData || {};

	// reCAPTCHA v3: a token for this send. Its script is loaded now if a cookie banner or an optimizer held it back:
	// without a token the message is turned down as spam.
	const recaptcha = async (form) => {
		const input = form.querySelector('[data-reform-captcha="recaptcha"]');

		if (!input) {
			return;
		}

		if (!window.grecaptcha?.execute && input.dataset.src) {
			await load(input.dataset.src);
		}

		await new Promise((resolve) => window.grecaptcha.ready(resolve));
		input.value = await window.grecaptcha.execute(input.dataset.sitekey, { action: 'contact_form' });
	};

	// A form may run several captchas: each widget is reset
	const resetCaptchas = (form) =>
		form.querySelectorAll('[data-reform-captcha]').forEach((widget) => {
			if (widget.dataset.reformCaptcha === 'turnstile') {
				window.turnstile?.reset(`#${widget.id}`);
			} else if (widget.dataset.reformCaptcha === 'hcaptcha') {
				window.hcaptcha?.reset(widget.querySelector('iframe')?.dataset.hcaptchaWidgetId);
			}
		});

	// A script a reply asks for, once
	const scripts = {};
	const load = (src) =>
		(scripts[src] ||= new Promise((resolve, reject) => {
			const script = document.createElement('script');

			script.src = src;
			script.onload = resolve;
			script.onerror = reject;
			document.head.append(script);
		}));

	// Async functions awaited before a form is sent: ( form ) => Promise
	const beforeSend = [recaptcha];
	const STATUSES = ['sending', 'success', 'invalid', 'failed', 'spam', 'aborted', 'payment'];

	const isEmpty = (value) => (Array.isArray(value) ? !value.some((item) => String(item) !== '') : String(value).trim() === '');
	const isNumber = (value) => !Array.isArray(value) && String(value).trim() !== '' && !Number.isNaN(Number(value));

	// The same rules as Submission\Conditions
	const rule = (r, value) => {
		const target = String(r.value ?? '');

		switch (r.op) {
			case 'is':
				return Array.isArray(value) ? value.map(String).includes(target) : String(value) === target;
			case 'is_not':
				return !rule({ ...r, op: 'is' }, value);
			case 'contains':
				return Array.isArray(value) ? value.map(String).includes(target) : String(value).toLowerCase().includes(target.toLowerCase());
			case 'not_contains':
				return !rule({ ...r, op: 'contains' }, value);
			case 'empty':
				return isEmpty(value);
			case 'not_empty':
				return !isEmpty(value);
			case 'gt':
				return isNumber(value) && isNumber(target) && Number(value) > Number(target);
			case 'lt':
				return isNumber(value) && isNumber(target) && Number(value) < Number(target);
		}

		return false;
	};

	const matches = (group, values) => {
		const results = group.rules.map((r) => rule(r, values[r.field] ?? ''));

		return group.match === 'any' ? results.includes(true) : !results.includes(false);
	};

	const tokens = (el, attr) => (el.getAttribute(attr) || '').split(/\s+/).filter(Boolean);

	function init(root) {
		const form = root.querySelector('form[data-reform]');

		if (!form || form.reformReady) {
			return;
		}

		form.reformReady = true;

		const configEl = root.querySelector('.reform__config');
		const config = configEl ? JSON.parse(configEl.textContent || '{}') : {};
		const messages = config.messages || {};
		const groups = config.groups || {};
		const box = form.querySelector('[data-reform-response]');
		let tried = false;

		const wrappers = () => [...form.querySelectorAll('[data-reform-field]')];
		const wrapper = (name) => form.querySelector(`[data-reform-field="${CSS.escape(name)}"]`);
		const controls = (wrap) => [...wrap.querySelectorAll('input, select, textarea')].filter((el) => el.name && !el.name.startsWith('_reform'));
		const groupsOf = (el) => {
			const names = [];

			for (let group = el.parentElement?.closest('[data-reform-group]'); group; group = group.parentElement?.closest('[data-reform-group]')) {
				names.push(group.dataset.reformGroup);
			}

			return names;
		};

		// A field's value: a list for checkboxes and multiple selects; labels instead of values when asked
		const read = (wrap, labels = false) => {
			const els = controls(wrap);
			const picked = [];
			const multiple = wrap.dataset.reformType === 'checkbox' || els.some((el) => el.multiple && el.tagName === 'SELECT');

			els.forEach((el) => {
				if (el.type === 'checkbox' || el.type === 'radio') {
					if (el.checked) {
						picked.push(labels ? el.closest('.reform-choice')?.querySelector('.reform-choice__label')?.textContent ?? el.value : el.value);
					}
				} else if (el.tagName === 'SELECT') {
					[...el.selectedOptions].filter((option) => option.value !== '').forEach((option) => picked.push(labels ? option.textContent : option.value));
				} else if (el.type === 'file') {
					picked.push([...el.files].map((file) => file.name).join(', '));
				} else {
					picked.push(el.value);
				}
			});

			return multiple ? picked : (picked[0] ?? '');
		};

		const conditions = () => {
			const values = {};
			const parents = {};

			wrappers().forEach((wrap) => {
				values[wrap.dataset.reformField] = read(wrap);
				parents[wrap.dataset.reformField] = groupsOf(wrap);
			});

			let hidden = [];

			// A rule may read a field another group hides: settle in a few passes
			for (let pass = 0; pass < 3; pass++) {
				const visible = { ...values };

				Object.keys(visible).forEach((name) => {
					if (parents[name].some((group) => hidden.includes(group))) {
						visible[name] = Array.isArray(visible[name]) ? [] : '';
					}
				});

				const next = [];

				Object.entries(groups).forEach(([name, group]) => {
					if ((group.parents || []).some((parent) => next.includes(parent))) {
						next.push(name);
					} else if (group.rules?.length && (group.action === 'show') !== matches(group, visible)) {
						next.push(name);
					}
				});

				if (next.join() === hidden.join()) {
					break;
				}

				hidden = next;
			}

			form.querySelectorAll('[data-reform-group]').forEach((el) => {
				const hide = hidden.includes(el.dataset.reformGroup);

				if (el.hidden !== hide) {
					el.hidden = hide;
					el.inert = hide;

					if (hide) {
						el.querySelectorAll('[data-reform-field]').forEach((wrap) => setError(wrap, ''));
					}
				}
			});
		};

		const outputs = () => {
			form.querySelectorAll('[data-reform-output]').forEach((out) => {
				const wrap = wrapper(out.dataset.reformOutput);
				const value = wrap && !wrap.closest('[data-reform-group][hidden]') ? read(wrap, true) : '';
				const text = Array.isArray(value) ? value.join(', ') : String(value);

				out.textContent = text === '' ? out.dataset.empty || '' : (out.dataset.format || '{value}').split('{value}').join(text);
			});

			// Characters as Count::text() counts them (code points, as mb_strlen)
			form.querySelectorAll('[data-reform-count]').forEach((out) => {
				const el = wrapper(out.dataset.reformCount)?.querySelector('input, textarea');
				const count = el ? [...el.value].length : 0;
				const max = Number(out.dataset.max || 0);
				const min = Number(out.dataset.min || 0);
				const values = { '{count}': count, '{left}': max ? max - count : '', '{max}': max || '' };

				out.textContent = (out.dataset.format || '{count}').replace(/\{(count|left|max)\}/g, (token) => values[token]);
				out.classList.toggle('is-over', Boolean(max) && count > max);
				out.classList.toggle('is-under', Boolean(min) && count > 0 && count < min);
			});
		};

		const setError = (wrap, message) => {
			const error = wrap.querySelector('[data-reform-error]');

			wrap.classList.toggle('is-invalid', Boolean(message));

			if (error) {
				error.textContent = message;
				error.hidden = !message;
			}

			controls(wrap).forEach((el) => {
				if (el.type === 'hidden') {
					return;
				}

				const described = tokens(el, 'aria-describedby').filter((id) => !error || id !== error.id);

				if (message) {
					el.setAttribute('aria-invalid', 'true');

					if (error) {
						described.push(error.id);
					}
				} else {
					el.removeAttribute('aria-invalid');
				}

				if (described.length) {
					el.setAttribute('aria-describedby', described.join(' '));
				} else {
					el.removeAttribute('aria-describedby');
				}
			});
		};

		// The message key of the browser's own checks, named as the server names them
		const problem = (type, el) => {
			const v = el.validity;

			if (v.valueMissing) {
				return type === 'acceptance' ? 'accept_terms' : 'required';
			}

			if (v.typeMismatch || v.patternMismatch || v.badInput || v.stepMismatch) {
				return messages[`invalid_${type}`] ? `invalid_${type}` : 'invalid';
			}

			if (v.tooLong) {
				return 'too_long';
			}

			if (v.tooShort) {
				return 'too_short';
			}

			if (v.rangeUnderflow) {
				return type === 'date' ? 'date_too_early' : 'number_too_small';
			}

			if (v.rangeOverflow) {
				return type === 'date' ? 'date_too_late' : 'number_too_large';
			}

			if (el.type === 'file') {
				const max = Number(el.dataset.reformMaxSize || 0);
				const accept = (el.accept || '').toLowerCase().split(',').filter(Boolean);

				for (const file of el.files) {
					if (max && file.size > max) {
						return 'upload_file_too_large';
					}

					if (accept.length && !accept.some((ext) => file.name.toLowerCase().endsWith(ext))) {
						return 'upload_file_type_invalid';
					}
				}
			}

			return '';
		};

		const check = (wrap) => {
			if (wrap.closest('[data-reform-group][hidden]')) {
				setError(wrap, '');

				return true;
			}

			const els = controls(wrap);
			let key = wrap.hasAttribute('data-reform-required') && !els.some((el) => el.checked) ? 'required' : '';

			for (const el of els) {
				key = key || problem(wrap.dataset.reformType, el);
			}

			// An inverted acceptance: sent only with the box clear
			if (!key && wrap.hasAttribute('data-reform-invert') && els.some((el) => el.checked)) {
				key = 'accept_terms';
			}

			setError(wrap, key ? messages[key] || messages.invalid || '' : '');

			return !key;
		};

		const setStatus = (status) => {
			root.classList.remove(...STATUSES.map((s) => `is-${s}`));

			if (status) {
				root.classList.add(`is-${status}`);
			}

			form.toggleAttribute('aria-busy', status === 'sending');
		};

		const emit = (name, response = null, cancelable = false) =>
			form.dispatchEvent(new CustomEvent(`reform:${name}`, { bubbles: true, cancelable, detail: { id: Number(form.dataset.reform), form, response } }));

		const focusFirst = () => form.querySelector('[aria-invalid="true"]')?.focus();

		const alert = (status, message) => {
			const div = document.createElement('div');
			const text = document.createElement('span');

			div.className = `reform-alert reform-alert--${status}`;
			text.className = 'reform-alert__text';
			text.textContent = message;
			div.append(text);
			box.replaceChildren(div);
		};

		const post = (withNonce) =>
			fetch(`${data.restUrl}forms/${form.dataset.reform}/submit`, {
				method: 'POST',
				body: new FormData(form),
				credentials: 'same-origin',
				headers: withNonce && form.dataset.nonce ? { 'X-WP-Nonce': form.dataset.nonce } : {},
			});

		const send = async () => {
			setStatus('sending');
			box.replaceChildren();

			try {
				for (const fn of beforeSend) {
					await fn(form);
				}

				let res = await post(true);

				// A cached page's nonce has expired: send as a visitor
				if (res.status === 403 && form.dataset.nonce) {
					res = await post(false);
				}

				const json = await res.json();

				if (!res.ok || !json.status) {
					throw new Error(json.message || res.statusText);
				}

				wrappers().forEach((wrap) => setError(wrap, ''));
				(json.invalid || []).forEach(({ field, message }) => {
					const wrap = wrapper(field);

					if (wrap) {
						setError(wrap, message);
					}
				});

				setStatus(json.status);
				box.innerHTML = json.html || '';

				if (!box.innerHTML) {
					alert(json.status, json.message);
				}

				if (json.status === 'invalid') {
					focusFirst();
				}

				if (json.status === 'success') {
					tried = false;
					form.reset();
				}

				resetCaptchas(form);

				if (json.data?.script) {
					await load(json.data.script);
				}

				emit('sent', json);
				emit(json.status, json);

				if (json.redirect) {
					window.location.assign(json.redirect);
				}
			} catch (err) {
				setStatus('failed');
				alert('failed', messages.failed || err.message);
				emit('failed');
			}
		};

		form.addEventListener('submit', (event) => {
			event.preventDefault();

			if (root.classList.contains('is-sending')) {
				return;
			}

			tried = true;

			if (wrappers().map(check).includes(false)) {
				setStatus('invalid');
				alert('invalid', messages.invalid || '');
				focusFirst();
				emit('invalid');

				return;
			}

			// The editor's preview checks the fields but sends nothing
			if (form.dataset.reformPreview) {
				setStatus('success');
				alert('success', form.dataset.reformPreview);

				return;
			}

			if (emit('submit', null, true)) {
				send();
			}
		});

		const changed = (event) => {
			// Exclusive checkboxes: ticking one clears the others
			if (event.type === 'change' && event.target.checked && event.target.closest('[data-reform-exclusive]')) {
				controls(event.target.closest('[data-reform-field]')).forEach((el) => el !== event.target && (el.checked = false));
			}

			conditions();
			outputs();

			const wrap = event.target.closest?.('[data-reform-field]');

			if (wrap && (tried || wrap.classList.contains('is-invalid'))) {
				check(wrap);
			}
		};

		// A link used as the submit button; a date opens its calendar wherever it's clicked, not only on the icon
		form.addEventListener('click', (event) => {
			if (event.target.closest('[data-reform-submit]')) {
				event.preventDefault();
				form.requestSubmit();
			}

			if (event.target.matches?.('input[type="date"]:not([readonly], :disabled)')) {
				try {
					event.target.showPicker();
				} catch {}
			}
		});

		form.addEventListener('keydown', (event) => {
			if (event.key === ' ' && event.target.closest('[data-reform-submit]')) {
				event.preventDefault();
				form.requestSubmit();
			}
		});

		form.addEventListener('input', changed);
		form.addEventListener('change', changed);

		form.addEventListener('reset', () => {
			// The controls are reset after this event
			setTimeout(() => {
				wrappers().forEach((wrap) => setError(wrap, ''));
				conditions();
				outputs();
				emit('reset');
			});
		});

		conditions();
		outputs();
	}

	const initAll = (scope = document) => {
		(scope.matches?.('.reform') ? [scope] : [...scope.querySelectorAll('.reform')]).forEach(init);
	};

	window.reform = { init: initAll, beforeSend };

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', () => initAll());
	} else {
		initAll();
	}
})();
