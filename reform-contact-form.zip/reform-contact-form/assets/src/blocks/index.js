/**
 * Contact Form block: a saved Reform form, shown as the site will show it
 */
import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Button, ExternalLink, PanelBody, Placeholder, SelectControl } from '@wordpress/components';
import ServerSideRender from '@wordpress/server-side-render';
import './editor.scss';

const { forms = [], editUrl, newUrl, canEdit } = window.reformBlocks || {};

const options = [{ value: 0, label: __( 'Choose a form', 'reform-contact-form' ) }, ...forms.map((form) => ({ value: form.id, label: form.title }))];

const Logo = () => (
	<svg viewBox="16.3 10.2 41 41" width="24" height="24" aria-hidden="true">
		<rect x="10" y="5" width="53" height="52" rx="5" fill="#1B2AFF" />
		<text x="36.5" y="38" textAnchor="middle" fontSize="20" fontWeight="700" fill="#fff" fontFamily="-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif">
			Re:
		</text>
	</svg>
);

const FormSelect = ({ value, onChange, hideLabel = false }) => (
	<SelectControl
		label={__( 'Form', 'reform-contact-form' )}
		hideLabelFromVision={hideLabel}
		value={value}
		options={options}
		onChange={(next) => onChange(Number(next))}
		__nextHasNoMarginBottom
		__next40pxDefaultSize
	/>
);

registerBlockType('reform/form', {
	icon: <Logo />,
	edit({ attributes, setAttributes }) {
		const props = useBlockProps();
		// By hash first: after an export and import the saved post ID is another form's, or none
		const form = forms.find((f) => attributes.hash && f.hash === attributes.hash) || forms.find((f) => f.id === attributes.id);
		const id = form ? form.id : attributes.id;
		const pick = (next) => setAttributes({ id: next, hash: forms.find((f) => f.id === next)?.hash || '' });

		return (
			<div {...props}>
				<InspectorControls>
					<PanelBody title={__( 'Form', 'reform-contact-form' )}>
						<FormSelect value={id} onChange={pick} />
						{id > 0 && canEdit && <ExternalLink href={editUrl + id}>{__( 'Edit this form', 'reform-contact-form' )}</ExternalLink>}
					</PanelBody>
				</InspectorControls>

				{id > 0 ? (
					<div className="reform-block-preview">
						<ServerSideRender block="reform/form" attributes={attributes} />
					</div>
				) : (
					<Placeholder icon={<Logo />} label={__( 'Contact Form', 'reform-contact-form' )} instructions={forms.length ? __( 'Pick one of your forms.', 'reform-contact-form' ) : __( 'There are no forms yet.', 'reform-contact-form' )}>
						{forms.length > 0 && <FormSelect value={0} onChange={pick} hideLabel />}
						{canEdit && (
							<Button variant="secondary" href={newUrl} target="_blank" __next40pxDefaultSize>
								{__( 'Make a new form', 'reform-contact-form' )}
							</Button>
						)}
					</Placeholder>
				)}
			</div>
		);
	},
	save: () => null,
});
