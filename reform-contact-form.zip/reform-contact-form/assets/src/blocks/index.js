/**
 * ReForm Contact Form block: picks a saved form. The editor shows which one, not the form itself; the site renders it
 */
import { __, sprintf } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Button, ExternalLink, PanelBody, Placeholder, SelectControl } from '@wordpress/components';

const { forms = [], editUrl, newUrl, canEdit, icon } = window.reformBlocks || {};

const options = [{ value: 0, label: __( 'Choose a form', 'reform-contact-form' ) }, ...forms.map((form) => ({ value: form.id, label: form.title }))];

// The ReForm mark (assets/icons/block.svg), the same as Elementor's and WPBakery's
// A bare <svg>, so the editor spaces it as its own icons
const Logo = () => <svg viewBox="10 5 53 52" width="24" height="24" aria-hidden="true" dangerouslySetInnerHTML={{ __html: (icon || '').replace(/^<svg[^>]*>|<\/svg>\s*$/g, '') }} />;

const FormSelect = ({ value, onChange, hideLabel = false }) => (
	<SelectControl
		label={__( 'Form', 'reform-contact-form' )}
		hideLabelFromVision={hideLabel}
		value={value}
		options={options}
		onChange={(next) => onChange(Number(next))}
		__nextHasNoMarginBottom
		__next40pxDefaultSize
	/>
);

registerBlockType('reform/form', {
	icon: <Logo />,
	edit({ attributes, setAttributes }) {
		const props = useBlockProps();
		// By hash first: after an export and import the saved post ID is another form's, or none
		const form = forms.find((f) => attributes.hash && f.hash === attributes.hash) || forms.find((f) => f.id === attributes.id);
		const id = form ? form.id : attributes.id;
		const pick = (next) => setAttributes({ id: next, hash: forms.find((f) => f.id === next)?.hash || '' });

		return (
			<div {...props}>
				<InspectorControls>
					<PanelBody title={__( 'Form', 'reform-contact-form' )}>
						<FormSelect value={id} onChange={pick} />
						{id > 0 && canEdit && <ExternalLink href={editUrl + id}>{__( 'Edit this form', 'reform-contact-form' )}</ExternalLink>}
					</PanelBody>
				</InspectorControls>

				<Placeholder
					icon={<Logo />}
					label={__( 'ReForm Contact Form', 'reform-contact-form' )}
					instructions={
						form
							? /* translators: %s: form title */ sprintf( __( 'Shows “%s” on the site.', 'reform-contact-form' ), form.title )
							: forms.length
								? __( 'Pick one of your forms.', 'reform-contact-form' )
								: __( 'There are no forms yet.', 'reform-contact-form' )
					}
				>
					{forms.length > 0 && <FormSelect value={form ? id : 0} onChange={pick} hideLabel />}
					{form && canEdit && (
						<Button variant="secondary" href={editUrl + id} target="_blank" __next40pxDefaultSize>
							{__( 'Edit this form', 'reform-contact-form' )}
						</Button>
					)}
					{!form && canEdit && (
						<Button variant="secondary" href={newUrl} target="_blank" __next40pxDefaultSize>
							{__( 'Make a new form', 'reform-contact-form' )}
						</Button>
					)}
				</Placeholder>
			</div>
		);
	},
	save: () => null,
});
