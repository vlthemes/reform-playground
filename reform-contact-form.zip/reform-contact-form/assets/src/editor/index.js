/**
 * The form editor (Contact Form → Contact Forms → a form)
 */
import { createRoot } from '@wordpress/element';
import App from './app.js';
import * as controls from './controls.js';
import { Icon } from './icons.js';
import './editor.scss';

// The editor's controls, for the tabs add-ons add (reform.tabs)
window.reformEditorUI = { ...controls, Icon };

// Mounted once every script of the page has run, so add-ons' tabs (reform.tabs) are there
const start = () => {
	const mount = document.getElementById('reform-editor');

	if (mount) {
		createRoot(mount).render(<App />);
	}
};

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', start);
} else {
	start();
}
