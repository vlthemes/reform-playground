/**
 * Messages tab: what visitors read, for the fields this form uses, in groups (every form, then each field type)
 */
import { createInterpolateElement } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Text } from '../controls.js';
import data, { placed, typeOf } from '../state.js';

const MessagesTab = ({ config, template, update }) => {
	const messages = config.messages || {};
	const used = [...new Set(placed(template).fields.map((n) => config.fields[n]?.type).filter(Boolean))];
	const shown = new Set();
	const groups = [{ title: __( 'Every form', 'reform-contact-form' ), keys: data.general || [] }];

	(data.general || []).forEach((key) => shown.add(key));

	used.forEach((type) => {
		const keys = (typeOf(type)?.messages || []).filter((key) => !shown.has(key));

		keys.forEach((key) => shown.add(key));

		if (keys.length) {
			groups.push({ title: typeOf(type).label, keys });
		}
	});

	// Messages of the settings that are on (Logged-in users only…)
	Object.entries(data.settingMessages || {}).forEach(([setting, keys]) => {
		if (config.settings[setting] && keys.length) {
			groups.push({ title: __( 'Logged-in users only', 'reform-contact-form' ), keys });
		}
	});

	return (
		<>
			{groups.map((group, i) => (
				<section className="reform-panel" key={group.title}>
					<h2 className="reform-panel__title">{group.title}</h2>
					{i === 0 && (
						<p className="reform-panel__intro">
							{createInterpolateElement(__( 'What visitors see after sending, or when a field needs fixing, for the fields in this form. Leave one empty to use the text of <a>Settings → Messages</a>, shown in grey.', 'reform-contact-form' ), {
								a: <a href={data.settingsUrl} target="_blank" rel="noopener noreferrer" />,
							})}
						</p>
					)}
					{group.keys.map((key) => (
						<Text key={key} label={data.messages[key]?.label || key} placeholder={data.messages[key]?.default} value={messages[key] ?? ''} onChange={(v) => update('messages', { ...messages, [key]: v })} />
					))}
				</section>
			))}
		</>
	);
};

export default MessagesTab;
