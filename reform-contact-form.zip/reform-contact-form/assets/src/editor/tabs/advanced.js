/**
 * Advanced tab: the form's look, where it goes after sending, and how it behaves
 */
import { createInterpolateElement, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button, Field, Select, Text, Textarea, Toggle } from '../controls.js';
import data from '../state.js';

/**
 * Copy to another site: this form's code to copy, and a box to paste another site's code into this form
 */
const FormCode = ({ code, onCopy, onPaste }) => {
	const [pasted, setPasted] = useState('');
	const [error, setError] = useState('');

	return (
		<section className="reform-panel">
			<h2 className="reform-panel__title">{__( 'Copy to another site', 'reform-contact-form' )}</h2>
			<Textarea
				label={__( 'This form\'s code', 'reform-contact-form' )}
				help={__( 'The whole form: its markup, fields, mails, messages and settings. Copy it here, then paste it into a form on the other site, such as a new one from Add New.', 'reform-contact-form' )}
				rows={4}
				mono
				readOnly
				value={code}
				onFocus={(e) => e.target.select()}
				onChange={() => {}}
			/>
			<Button icon="copy" onClick={onCopy}>
				{__( 'Copy form code', 'reform-contact-form' )}
			</Button>
			<Textarea
				label={__( 'Paste form code', 'reform-contact-form' )}
				help={__( 'Code copied from a form on another site. It replaces everything in this form; nothing is saved until you click Save.', 'reform-contact-form' )}
				rows={4}
				mono
				placeholder='{ "reform": 1, … }'
				value={pasted}
				onChange={(v) => {
					setPasted(v);
					setError('');
				}}
			/>
			{error && <p className="reform-side__error">{error}</p>}
			<Button
				disabled={!pasted.trim()}
				onClick={() => {
					// eslint-disable-next-line no-alert
					if (!window.confirm(__( 'Replace everything in this form with the pasted code?', 'reform-contact-form' ))) {
						return;
					}

					const problem = onPaste(pasted);

					setError(problem);

					if (!problem) {
						setPasted('');
					}
				}}
			>
				{__( 'Replace this form', 'reform-contact-form' )}
			</Button>
		</section>
	);
};

const AdvancedTab = ({ config, update, formCode, onCopy, onPaste }) => {
	const settings = config.settings;
	const set = (key, value) => update('settings', { ...settings, [key]: value });

	return (
		<>
			<section className="reform-panel">
				<h2 className="reform-panel__title">{__( 'Look and redirect', 'reform-contact-form' )}</h2>
				<Select
					label={__( 'Form style', 'reform-contact-form' )}
					help={__( 'ReForm style: the plugin draws the form and its fields. Inherit from theme: no ReForm CSS, your theme styles everything. A field can still pick a style of its own, and your theme can add styles in its reform/ folder.', 'reform-contact-form' )}
					value={settings.style}
					options={data.formStyles || { default: __( 'ReForm style', 'reform-contact-form' ) }}
					onChange={(v) => set('style', v)}
				/>
				<Text
					label={__( 'Page to open after sending', 'reform-contact-form' )}
					help={__( 'A thank-you page, for example. Leave empty to stay on the page and show the message.', 'reform-contact-form' )}
					type="url"
					placeholder="https://"
					value={settings.redirect}
					onChange={(v) => set('redirect', v)}
				/>
				<Text label={__( 'CSS classes', 'reform-contact-form' )} help={__( "Added to the form's wrapper.", 'reform-contact-form' )} value={settings.class} onChange={(v) => set('class', v)} />
			</section>

			<section className="reform-panel">
				<h2 className="reform-panel__title">{__( 'Behavior', 'reform-contact-form' )}</h2>
				<Toggle
					label={__( 'Save entries', 'reform-contact-form' )}
					help={__( 'Keeps a copy of every message in Contact Form → Entries, even when the mail fails.', 'reform-contact-form' )}
					checked={settings.store_entries}
					onChange={(v) => set('store_entries', v)}
				/>
				<Toggle
					label={__( 'Browser autofill', 'reform-contact-form' )}
					help={__( 'Lets browsers suggest saved names, emails and addresses. Some browsers still offer saved addresses when it is off.', 'reform-contact-form' )}
					checked={settings.autocomplete}
					onChange={(v) => set('autocomplete', v)}
				/>
				<Toggle
					label={__( 'Logged-in users only', 'reform-contact-form' )}
					help={__( 'Visitors who are not logged in see a message instead of the form. You can change it in the Messages tab.', 'reform-contact-form' )}
					checked={settings.subscribers_only}
					onChange={(v) => set('subscribers_only', v)}
				/>
			</section>

			<section className="reform-panel">
				<h2 className="reform-panel__title">{__( 'Spam', 'reform-contact-form' )}</h2>
				<Field label={__( 'Captcha', 'reform-contact-form' )} help={__( 'Goes before the submit button, or where you put [[captcha]] in the code. The honeypot, time check and rate limit of Settings → Spam run on every form anyway.', 'reform-contact-form' )}>
					<div className="reform-picks" role="radiogroup" aria-label={__( 'Captcha', 'reform-contact-form' )}>
						{[['', { label: __( 'None', 'reform-contact-form' ), logo: '' }], ...Object.entries(data.captchas || {})].map(([id, captcha]) => (
							<button key={id || 'none'} type="button" role="radio" aria-checked={(settings.captcha || '') === id} className="reform-pick" onClick={() => set('captcha', id)}>
								{captcha.logo ? <span className="reform-pick__logo" aria-hidden="true" dangerouslySetInnerHTML={{ __html: captcha.logo }} /> : <span className="reform-pick__logo is-none" aria-hidden="true" />}
								{captcha.label}
							</button>
						))}
					</div>
				</Field>
				{!Object.keys(data.captchas || {}).length && (
					<p className="reform-panel__intro">
						{createInterpolateElement(__( 'Add the keys of Cloudflare Turnstile, hCaptcha or reCAPTCHA in <a>Settings → Spam</a> to pick one here.', 'reform-contact-form' ), {
							a: <a href={data.settingsUrl} />,
						})}
					</p>
				)}
			</section>

			<section className="reform-panel">
				<h2 className="reform-panel__title">{__( 'Webhooks', 'reform-contact-form' )}</h2>
				<Textarea
					label={__( 'Send each message to', 'reform-contact-form' )}
					help={__( 'Web addresses, one per line. Each message that goes through is posted to them as JSON: the form, the entry, every field (labels and raw values) and the page it came from. Use it with Zapier, Make, n8n or your own code.', 'reform-contact-form' )}
					rows={3}
					mono
					placeholder="https://"
					value={(settings.webhooks || []).join('\n')}
					onChange={(v) => set('webhooks', v.split('\n'))}
				/>
			</section>

			<section className="reform-panel">
				<h2 className="reform-panel__title">{__( 'Testing', 'reform-contact-form' )}</h2>
				<Toggle
					label={__( 'Test mode', 'reform-contact-form' )}
					help={
						data.testMode
							? __( 'On for every form: REFORM_TEST_MODE is set in wp-config.php. Remove it there to turn it off.', 'reform-contact-form' )
							: __( 'Fields are checked as usual, then nothing is sent or saved and visitors see the "sent" message. Turn it off before the site goes live.', 'reform-contact-form' )
					}
					checked={data.testMode || settings.demo}
					disabled={data.testMode}
					onChange={(v) => set('demo', v)}
				/>
				<Toggle
					label={__( "Don't send mail", 'reform-contact-form' )}
					help={
						data.mailOff
							? __( 'On for every form: REFORM_DISABLE_MAIL is set in wp-config.php. Entries are still saved. Remove it there to send mail again.', 'reform-contact-form' )
							: __( 'No mail goes out, but entries are still saved.', 'reform-contact-form' )
					}
					checked={data.mailOff || settings.skip_mail}
					disabled={data.mailOff}
					onChange={(v) => set('skip_mail', v)}
				/>
				<p className="reform-panel__intro">
					{__( "To test every form at once, on a staging site for example, add define( 'REFORM_TEST_MODE', true ); or define( 'REFORM_DISABLE_MAIL', true ); to wp-config.php.", 'reform-contact-form' )}
				</p>
			</section>

			<FormCode code={formCode} onCopy={onCopy} onPaste={onPaste} />
		</>
	);
};

export default AdvancedTab;
