/**
 * Mail tab: Mail and Mail 2, and the tags they can use
 */
import { useRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Textarea, Text, Toggle } from '../controls.js';
import data, { mailProblems, placed, typeOf } from '../state.js';

const MailPanel = ({ title, intro, mail, onChange, focus }) => {
	const set = (key, value) => onChange({ ...mail, [key]: value });
	const bind = (key) => ({ value: mail[key], onChange: (v) => set(key, v), onFocus: (e) => (focus.current = { el: e.target, key, set }) });

	return (
		<section className="reform-panel">
			<h2 className="reform-panel__title">{title}</h2>
			{intro && <p className="reform-panel__intro">{intro}</p>}
			<div className="reform-panel__grid">
				<Text label={__( 'To', 'reform-contact-form' )} help={__( 'Who gets this mail. Several addresses: separate them with commas. Tags work, such as [your_email].', 'reform-contact-form' )} {...bind('to')} />
				<Text label={__( 'From', 'reform-contact-form' )} help={__( 'Use an address on your own domain, or mail servers may treat the mail as spam.', 'reform-contact-form' )} {...bind('from')} />
			</div>
			<Text label={__( 'Subject', 'reform-contact-form' )} help={__( 'The subject line. Tags work here too.', 'reform-contact-form' )} {...bind('subject')} />
			<Textarea label={__( 'Additional headers', 'reform-contact-form' )} help={__( 'One per line, such as Reply-To: [your_email] or Cc: someone@example.com.', 'reform-contact-form' )} rows={2} mono {...bind('headers')} />
			<Textarea label={__( 'Message', 'reform-contact-form' )} help={__( 'The text of the mail. Tags in square brackets are replaced with what visitors sent; click one on the right to add it.', 'reform-contact-form' )} rows={10} mono {...bind('body')} />
			<Textarea label={__( 'Attachments', 'reform-contact-form' )} help={__( 'The tags of file fields whose files go with the mail, such as [your_file].', 'reform-contact-form' )} rows={2} mono {...bind('attachments')} />
			<Toggle label={__( 'Send as HTML', 'reform-contact-form' )} help={__( 'Line breaks become paragraphs and the mail gets a simple layout. Off: plain text.', 'reform-contact-form' )} checked={mail.html} onChange={(v) => set('html', v)} />
		</section>
	);
};

const MailTab = ({ config, template, update }) => {
	const focus = useRef(null);
	const fields = placed(template).fields.filter((n) => typeOf(config.fields[n]?.type)?.submits);
	const insert = (tag) => {
		const target = focus.current;

		if (!target?.el?.isConnected) {
			navigator.clipboard?.writeText(tag);

			return;
		}

		const { el, set } = target;
		const start = el.selectionStart ?? el.value.length;
		const value = el.value.slice(0, start) + tag + el.value.slice(el.selectionEnd ?? start);

		set(target.key, value);
		requestAnimationFrame(() => {
			el.focus();
			el.setSelectionRange(start + tag.length, start + tag.length);
		});
	};

	const problems = mailProblems(config, template);

	return (
		<div className="reform-mail">
			<div className="reform-mail__main">
				{problems.length > 0 && (
					<section className="reform-panel reform-problems" role="alert">
						<h2 className="reform-panel__title">{__( 'Check these before saving', 'reform-contact-form' )}</h2>
						<ul>
							{problems.map((problem, i) => (
								<li key={i}>
									<strong>{problem.mail}:</strong> {problem.text}
								</li>
							))}
						</ul>
					</section>
				)}
				<MailPanel title={__( 'Mail', 'reform-contact-form' )} mail={config.mail} focus={focus} onChange={(v) => update('mail', v)} />
				<section className="reform-panel">
					<Toggle
						label={__( 'Send Mail 2', 'reform-contact-form' )}
						help={__( 'A second mail sent after the first one, often a copy for the person who filled in the form.', 'reform-contact-form' )}
						checked={config.mail_2.active}
						onChange={(v) => update('mail_2', { ...config.mail_2, active: v })}
					/>
				</section>
				{config.mail_2.active && <MailPanel title={__( 'Mail 2', 'reform-contact-form' )} mail={config.mail_2} focus={focus} onChange={(v) => update('mail_2', v)} />}
			</div>
			<aside className="reform-mail__tags">
				<h3>{__( 'Tags', 'reform-contact-form' )}</h3>
				<p>{__( 'Click a tag to put it where your cursor is.', 'reform-contact-form' )}</p>
				<div className="reform-tags">
					{fields.map((name) => (
						<button type="button" key={name} className="reform-tag is-field" onMouseDown={(e) => e.preventDefault()} onClick={() => insert(`[${name}]`)}>
							[{name}]
						</button>
					))}
				</div>
				<h4>{__( 'Site and visitor', 'reform-contact-form' )}</h4>
				<div className="reform-tags">
					{(data.specialTags || []).map((tag) => (
						<button type="button" key={tag} className="reform-tag" onMouseDown={(e) => e.preventDefault()} onClick={() => insert(`[${tag}]`)}>
							[{tag}]
						</button>
					))}
				</div>
				<p className="reform-mail__hint">{__( '[_raw_name] prints the values of options instead of their labels. [group:name] … [/group:name] prints its text only when the group was shown.', 'reform-contact-form' )}</p>
			</aside>
		</div>
	);
};

export default MailTab;
