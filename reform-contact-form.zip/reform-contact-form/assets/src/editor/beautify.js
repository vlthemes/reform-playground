/**
 * Beautify HTML: the form's markup, indented. A small formatter of our own instead of js-beautify (130 KB): block
 * elements and [[group:…]] … [[/group]] each on their lines with their content indented, unless it's inline and fits
 * on one line. Inline content too long for a line breaks only where it already has spaces, so the page looks the
 * same; an empty line stays (one at most); <pre>, <textarea>, <script> and <style> as written. Forms\Beautify is
 * its PHP twin: change both together.
 */
const WIDTH = 100;
const BLOCK = new Set('address article aside blockquote details dialog dd div dl dt fieldset figcaption figure footer form h1 h2 h3 h4 h5 h6 header hgroup hr legend li main nav ol optgroup option p pre script section style summary table tbody td tfoot th thead tr ul'.split(' '));
// Inline elements whose content can start and end on lines of its own
const BOX = new Set(['button', 'select']);
const VOID = new Set('area base br col embed hr img input link meta source track wbr'.split(' '));
const RAW = new Set(['pre', 'textarea', 'script', 'style']);
const TOKEN = /<!--[\s\S]*?-->|<\/?[a-zA-Z][^>"']*(?:(?:"[^"]*"|'[^']*')[^>"']*)*>|\[\[\/?group(?::[^\]]*)?\]\]/g;

// The markup as a tree: { open, name, close, children } for elements and groups, strings for text and comments
const parse = (html) => {
	const root = { children: [] };
	const stack = [root];
	let at = 0;
	let match;

	const text = (str) => str && stack[stack.length - 1].children.push(str);

	TOKEN.lastIndex = 0;

	while ((match = TOKEN.exec(html))) {
		const token = match[0];
		const parent = stack[stack.length - 1];

		text(html.slice(at, match.index));
		at = TOKEN.lastIndex;

		if (token.startsWith('<!--')) {
			parent.children.push({ comment: token });
			continue;
		}

		const group = token.startsWith('[[');
		const closing = token.startsWith('</') || token.startsWith('[[/');
		const name = group ? 'group' : token.match(/^<\/?([a-zA-Z][\w-]*)/)[1].toLowerCase();

		if (closing) {
			// Back to the element it closes; a stray closing tag stays where it is
			const index = stack.map((node) => node.name).lastIndexOf(name);

			if (index > 0) {
				stack.length = index + 1;
				stack.pop().close = token;
			} else {
				text(token);
			}

			continue;
		}

		const node = { open: token, name, close: '', children: [] };

		parent.children.push(node);

		if (RAW.has(name)) {
			// Its content as written, up to its closing tag
			const end = html.toLowerCase().indexOf(`</${name}`, at);
			const stop = end < 0 ? html.length : html.indexOf('>', end) + 1 || html.length;

			node.raw = html.slice(at, end < 0 ? html.length : end);
			node.close = end < 0 ? '' : html.slice(end, stop);
			at = TOKEN.lastIndex = stop;
		} else if (!VOID.has(name) && !token.endsWith('/>')) {
			stack.push(node);
		}
	}

	text(html.slice(at));

	return root;
};

const isInline = (node) => 'string' === typeof node || (node.name && 'group' !== node.name && !BLOCK.has(node.name) && node.children.every(isInline));

// An inline node on one line, its spaces collapsed
const flat = (node) => {
	if ('string' === typeof node) {
		return node.replace(/\s+/g, ' ');
	}

	return node.open + (node.raw ?? node.children.map(flat).join('')) + node.close;
};

// Whether an inline element's content can go on lines of its own: a box, or spaces at both its ends already
const opens = (node) => {
	const first = node.children[0];
	const last = node.children[node.children.length - 1];

	return BOX.has(node.name) || ('string' === typeof first && /^\s/.test(first) && 'string' === typeof last && /\s$/.test(last));
};

/**
 * Indent a form's markup
 *
 * @param {string} html   Markup
 * @param {number} spaces Spaces per level
 * @return {string} Markup
 */
export default function beautify(html, spaces = 2) {
	const out = [];
	let blank = false;

	const push = (depth, line) => {
		if (blank && out.length) {
			out.push('');
		}

		blank = false;
		out.push(' '.repeat(spaces * depth) + line);
	};

	const fits = (depth, line) => spaces * depth + [...line].length <= WIDTH;

	const children = (nodes, depth) => {
		// Inline nodes with no space between them: they stay on one line
		let line = [];
		let started = false;

		const flush = () => {
			const text = line.map(flat).join('').trim();

			if (text) {
				if (1 === line.length && 'string' !== typeof line[0] && !fits(depth, text) && opens(line[0])) {
					wrap(line[0], depth);
				} else {
					push(depth, text);
				}

				started = true;
			}

			line = [];
		};

		// A space: the line can break there; two line breaks in it keep an empty line
		const space = (str) => {
			flush();
			blank = blank || (started && (str.match(/\n/g) || []).length > 1);
		};

		nodes.forEach((node) => {
			if ('string' === typeof node) {
				node.split(/(\s*\n\s*)/).forEach((part, i) => {
					if (i % 2) {
						space(part);
						return;
					}

					const [, before, word, after] = part.match(/^(\s*)([\s\S]*?)(\s*)$/);

					if (before) {
						space(before);
					}

					if (word) {
						line.push(word);
					}

					if (after) {
						space(after);
					}
				});
			} else if (isInline(node)) {
				line.push(node);
			} else {
				flush();
				block(node, depth);
				started = true;
			}
		});

		flush();
	};

	const wrap = (node, depth) => {
		push(depth, node.open);
		children(node.children, depth + 1);
		blank = false;

		if (node.close) {
			push(depth, node.close);
		}
	};

	const block = (node, depth) => {
		if (node.comment) {
			push(depth, node.comment.trim());
		} else if (undefined !== node.raw) {
			push(depth, node.open + node.raw + node.close);
		} else if ('group' !== node.name && node.children.every(isInline) && fits(depth, node.open + node.children.map(flat).join('').trim() + node.close)) {
			// Inline only and short: one line
			push(depth, node.open + node.children.map(flat).join('').trim() + node.close);
		} else {
			wrap(node, depth);
		}
	};

	children(parse(html).children, 0);

	return out.join('\n');
}
