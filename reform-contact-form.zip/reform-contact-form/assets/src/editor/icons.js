/**
 * Line icons (24×24, stroke): field types and the editor's buttons
 */
const PATHS = {
	text: 'M4 7V4h16v3M9 20h6M12 4v16',
	email: 'M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm0 0v1.5a2.5 2.5 0 0 0 5 0V12a9 9 0 1 0-9 9h4',
	url: 'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71',
	tel: 'M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2ZM12 18h.01',
	number: 'M4 9h16M4 15h16M10 3 8 21M16 3l-2 18',
	date: 'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z',
	textarea: 'M3 6h18M3 12h18M3 18h12',
	select: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
	checkbox: 'M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2ZM9 12l2 2 4-4',
	radio: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z',
	acceptance: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM8 12l3 3 5-5',
	quiz: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01',
	file: 'm21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48',
	hidden: 'M9.88 9.88a3 3 0 1 0 4.24 4.24M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68M6.61 6.61A13.53 13.53 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61M2 2l20 20',
	submit: 'M22 2 11 13M22 2l-7 20-4-9-9-4 20-7Z',
	output: 'm17 1 4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3',
	count: 'M4 6h10M4 12h7M4 18h10M18 9v10M15 16l3 3 3-3',
	stripe: 'M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2ZM2 10h20M6 15h4',
	paypal: 'M8 21V3h6a5 5 0 0 1 0 10H8',
	group: 'M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2',
	copy: 'M9 9h11a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V10a1 1 0 0 1 1-1ZM5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1',
	save: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM8 12l3 3 5-5',
	eye: 'M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7ZM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z',
	pencil: 'M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z',
	trash: 'M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M10 11v6M14 11v6',
	captcha: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10ZM9 12l2 2 4-4',
	response: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z',
	info:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20ZM12 16v-4M12 8h.01',
	close: 'M18 6 6 18M6 6l12 12',
	plus: 'M12 5v14M5 12h14',
	code: 'm16 18 6-6-6-6M8 6l-6 6 6 6',
	layout: 'M3 3h18v18H3zM3 9h18M9 21V9',
	grip: 'M9 5h.01M9 12h.01M9 19h.01M15 5h.01M15 12h.01M15 19h.01',
	chevron: 'm6 9 6 6 6-6',
	warning: 'M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0ZM12 9v4M12 17h.01',
	check: 'M20 6 9 17l-5-5',
	sparkles: 'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9ZM5 3v4M3 5h4M19 17v4M17 19h4',
};

// A path of an add-on's own (Field::icon()): commands and numbers only
const OWN_PATH = /^[MmLlHhVvCcSsQqTtAaZz0-9.,\s-]+$/;

/**
 * An icon's SVG markup
 *
 * @param {string} name Icon, or the d of a 24×24 path
 * @return {string} SVG
 */
export const svg = (name) =>
	`<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="${PATHS[name] || (name && /^[Mm]/.test(name) && OWN_PATH.test(name) ? name : PATHS.text)}"/></svg>`;

/**
 * An icon as an element
 */
export const Icon = ({ name, className = '' }) => <span className={`reform-icon ${className}`} dangerouslySetInnerHTML={{ __html: svg(name) }} />;
