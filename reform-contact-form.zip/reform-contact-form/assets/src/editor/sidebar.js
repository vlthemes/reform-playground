/**
 * The Form tab's sidebar: the settings of the selected field or group
 */
import { Fragment, useState } from '@wordpress/element';
import { applyFilters } from '@wordpress/hooks';
import { __, sprintf } from '@wordpress/i18n';
import { Button, DateControl, Field, LinesControl, NumberInput, Select, Text, Textarea, Toggle } from './controls.js';
import { Icon } from './icons.js';
import data, { optionsToText, pairsToText, placed, textToOptions, textToPairs, typeOf, types } from './state.js';

const OPERATORS = {
	is: __( 'is', 'reform-contact-form' ),
	is_not: __( 'is not', 'reform-contact-form' ),
	contains: __( 'contains', 'reform-contact-form' ),
	not_contains: __( "doesn't contain", 'reform-contact-form' ),
	empty: __( 'is empty', 'reform-contact-form' ),
	not_empty: __( "isn't empty", 'reform-contact-form' ),
	gt: __( 'is more than', 'reform-contact-form' ),
	lt: __( 'is less than', 'reform-contact-form' ),
};

/**
 * The name with its rename button
 */
const NameHead = ({ name, prefix = '', onRename, onBack }) => {
	const [editing, setEditing] = useState(false);
	const [value, setValue] = useState(name);
	const [error, setError] = useState('');

	const commit = () => {
		if (value === name) {
			setEditing(false);

			return;
		}

		const problem = onRename(value);

		setError(problem);

		if (!problem) {
			setEditing(false);
		}
	};

	if (editing) {
		return (
			<div className="reform-side__head is-editing">
				<input
					className="reform-input"
					value={value}
					autoFocus
					aria-label={__( 'Name', 'reform-contact-form' )}
					onChange={(e) => setValue(e.target.value.replace(/\s/g, '_'))}
					onKeyDown={(e) => {
						if (e.key === 'Enter') {
							commit();
						} else if (e.key === 'Escape') {
							setValue(name);
							setError('');
							setEditing(false);
						}
					}}
					onBlur={commit}
				/>
				{error && <p className="reform-side__error">{error}</p>}
			</div>
		);
	}

	return (
		<>
			<button type="button" className="reform-side__back" onClick={onBack}>
				← {__( 'All fields', 'reform-contact-form' )}
			</button>
			<div className="reform-side__head">
				<h2 className="reform-side__name">
					<button type="button" onClick={() => setEditing(true)} title={__( 'Change name', 'reform-contact-form' )}>
						{prefix}
						{name}
					</button>
				</h2>
				<button type="button" className="reform-side__rename" onClick={() => setEditing(true)}>
					<Icon name="pencil" />
					{__( 'Change name', 'reform-contact-form' )}
				</button>
			</div>
		</>
	);
};

/**
 * One control of a field type's schema; a type of the add-on's own comes from reform.control. def.when
 * ({ setting: [ values ] }) shows it only while those settings have one of those values.
 *
 *     wp.hooks.addFilter( 'reform.control', 'my-addon', ( control, { def, value, onChange } ) =>
 *         def.type === 'stars' ? <MyStars value={ value } onChange={ onChange } /> : control );
 */
const Control = ({ id, def, field, set, fieldNames }) => {
	if (def.when && !Object.entries(def.when).every(([key, values]) => values.includes(field[key]))) {
		return null;
	}

	const value = field[id];
	const common = { label: def.label, help: def.help };
	const custom = applyFilters('reform.control', null, { id, def, value, field, onChange: (v) => set(id, v) });

	if (custom) {
		return custom;
	}

	switch (def.type) {
		case 'toggle':
			return <Toggle {...common} checked={value} onChange={(v) => set(id, v)} />;
		case 'number':
			return <NumberInput {...common} value={value} onChange={(v) => set(id, v)} />;
		case 'textarea':
			return <Textarea {...common} value={value} onChange={(v) => set(id, v)} />;
		case 'select':
			return <Select {...common} value={value} options={def.options || {}} onChange={(v) => set(id, v)} />;
		case 'options':
			return <LinesControl {...common} value={value} toText={optionsToText} fromText={textToOptions} placeholder={'val1 : Option 1\nval2 : Option 2'} onChange={(v) => set(id, v)} />;
		case 'pairs':
			return <LinesControl {...common} value={value} toText={pairsToText} fromText={textToPairs} placeholder="1 + 1 = ? | 2" onChange={(v) => set(id, v)} />;
		case 'date':
			return <DateControl {...common} value={value} empty={def.empty} onChange={(v) => set(id, v)} />;
		case 'field':
			return <Select {...common} value={value} options={{ '': __( '— Pick a field —', 'reform-contact-form' ), ...Object.fromEntries(fieldNames.map((n) => [n, n])) }} onChange={(v) => set(id, v)} />;
		default:
			return <Text {...common} value={value} onChange={(v) => set(id, v)} />;
	}
};

/**
 * Custom attributes: name and value rows
 */
const Attributes = ({ value, onChange }) => {
	const rows = value || [];
	const update = (i, key, v) => onChange(rows.map((row, j) => (j === i ? { ...row, [key]: v } : row)));

	return (
		<Field label={__( 'Custom attributes', 'reform-contact-form' )} help={__( 'Extra attributes on the input, such as data-something or inputmode.', 'reform-contact-form' )}>
			{rows.map((row, i) => (
				<div className="reform-attr" key={i}>
					<input className="reform-input" placeholder={__( 'name', 'reform-contact-form' )} value={row.name} onChange={(e) => update(i, 'name', e.target.value)} />
					<input className="reform-input" placeholder={__( 'value', 'reform-contact-form' )} value={row.value} onChange={(e) => update(i, 'value', e.target.value)} />
					<button type="button" className="reform-attr__remove" aria-label={__( 'Remove attribute', 'reform-contact-form' )} onClick={() => onChange(rows.filter((r, j) => j !== i))}>
						<Icon name="close" />
					</button>
				</div>
			))}
			<Button className="is-full" onClick={() => onChange([...rows, { name: '', value: '' }])}>
				{__( 'Add attribute', 'reform-contact-form' )}
			</Button>
		</Field>
	);
};

export const FieldSidebar = ({ name, field, template, onChange, onRename, onType, onDelete, onBack }) => {
	const type = typeOf(field.type);
	const set = (key, value) => onChange({ ...field, [key]: value });
	const fieldNames = placed(template).fields.filter((n) => n !== name);
	const styles = type?.styles || {};

	return (
		<div className="reform-side">
			<NameHead name={name} onRename={onRename} onBack={onBack} />

			<Select
				label={__( 'Field type', 'reform-contact-form' )}
				help={__( 'Changing the type keeps the name and the settings both types share.', 'reform-contact-form' )}
				value={field.type}
				options={Object.fromEntries(types.map((t) => [t.type, t.label]))}
				onChange={onType}
			/>

			{Object.entries(type?.schema || {}).map(([id, def]) => (
				<Control key={id} id={id} def={def} field={field} set={set} fieldNames={fieldNames} />
			))}

			{type?.required && (
				<Toggle
					label={__( 'Required', 'reform-contact-form' )}
					help={__( 'Visitors must fill it in before they can send the form. Add a * to its label in the code so they know.', 'reform-contact-form' )}
					checked={field.required}
					onChange={(v) => set('required', v)}
				/>
			)}

			{Object.keys(styles).length > 0 && (
				<Select
					label={__( 'Style', 'reform-contact-form' )}
					help={__( 'How the field looks. Your theme can add styles of its own.', 'reform-contact-form' )}
					value={field.style || ''}
					options={{ '': __( 'Same as the form', 'reform-contact-form' ), ...styles }}
					onChange={(v) => set('style', v)}
				/>
			)}

			{field.type !== 'hidden' && (
				<>
					<Text label={__( 'CSS classes', 'reform-contact-form' )} help={__( 'Classes added to the input, separated by spaces.', 'reform-contact-form' )} value={field.class} onChange={(v) => set('class', v)} />
					<Text label={__( 'ID', 'reform-contact-form' )} help={__( 'Leave empty and Reform makes one. Set it only if your CSS or scripts need a fixed ID.', 'reform-contact-form' )} value={field.id} onChange={(v) => set('id', v)} />
					<Attributes value={field.attrs} onChange={(v) => set('attrs', v)} />
				</>
			)}

			{/* Add-ons' own controls: reform.fieldControls returns elements for this field */}
			{(applyFilters('reform.fieldControls', [], { name, field, type, set }) || []).map((control, i) => (
				<Fragment key={i}>{control}</Fragment>
			))}

			{type?.submits && (
				<p className="reform-side__note">
					{sprintf(
						/* translators: %s: mail tag such as [your_name] */
						__( 'To use what visitors type here in a mail, put %s in the mail.', 'reform-contact-form' ),
						`[${name}]`
					)}
				</p>
			)}

			<Button variant="danger" icon="trash" className="is-full" onClick={onDelete}>
				{__( 'Delete field', 'reform-contact-form' )}
			</Button>
		</div>
	);
};

export const GroupSidebar = ({ name, group, config, template, onChange, onRename, onUngroup, onBack }) => {
	const rules = group.rules || [];
	const fieldNames = placed(template).fields.filter((n) => typeOf(config.fields[n]?.type)?.submits);
	const setRule = (i, key, value) => onChange({ ...group, rules: rules.map((r, j) => (j === i ? { ...r, [key]: value } : r)) });

	return (
		<div className="reform-side">
			<NameHead name={name} prefix={__( 'Group: ', 'reform-contact-form' )} onRename={onRename} onBack={onBack} />

			<p className="reform-side__note">{__( 'Show or hide everything inside this group, depending on what visitors pick or type. Hidden fields are not checked or sent.', 'reform-contact-form' )}</p>

			<div className="reform-side__pair">
				<Select
					help={__( 'Show: the group appears only when the rules match. Hide: it disappears when they match.', 'reform-contact-form' )}
					value={group.action || 'show'}
					options={{ show: __( 'Show this group', 'reform-contact-form' ), hide: __( 'Hide this group', 'reform-contact-form' ) }}
					onChange={(v) => onChange({ ...group, action: v })}
				/>
				<Select
					value={group.match || 'all'}
					options={{ all: __( 'when all rules match', 'reform-contact-form' ), any: __( 'when any rule matches', 'reform-contact-form' ) }}
					onChange={(v) => onChange({ ...group, match: v })}
				/>
			</div>

			{rules.map((rule, i) => {
				const source = config.fields[rule.field];
				const options = source?.options;
				const noValue = rule.op === 'empty' || rule.op === 'not_empty';

				return (
					<div className="reform-rule" key={i}>
						<Select value={rule.field} options={{ '': __( '— Field —', 'reform-contact-form' ), ...Object.fromEntries(fieldNames.map((n) => [n, n])) }} onChange={(v) => setRule(i, 'field', v)} />
						<Select value={rule.op} options={OPERATORS} onChange={(v) => setRule(i, 'op', v)} />
						{!noValue &&
							(options?.length ? (
								<Select value={rule.value} options={{ '': '—', ...Object.fromEntries(options.map((o) => [o.value, o.label])) }} onChange={(v) => setRule(i, 'value', v)} />
							) : (
								<input className="reform-input" value={rule.value} placeholder={__( 'Value', 'reform-contact-form' )} onChange={(e) => setRule(i, 'value', e.target.value)} />
							))}
						<button type="button" className="reform-attr__remove" aria-label={__( 'Remove rule', 'reform-contact-form' )} onClick={() => onChange({ ...group, rules: rules.filter((r, j) => j !== i) })}>
							<Icon name="close" />
						</button>
					</div>
				);
			})}

			{!rules.length && <p className="reform-side__note">{__( 'No rules yet, so the group always shows.', 'reform-contact-form' )}</p>}

			<Button className="is-full" icon="plus" onClick={() => onChange({ ...group, rules: [...rules, { field: fieldNames[0] || '', op: 'is', value: '' }] })}>
				{__( 'Add rule', 'reform-contact-form' )}
			</Button>

			<Button variant="danger" className="is-full" onClick={onUngroup}>
				{__( 'Ungroup', 'reform-contact-form' )}
			</Button>
		</div>
	);
};

export const EmptySidebar = ({ template, config, onSelect }) => {
	const { fields } = placed(template);

	return (
		<div className="reform-side is-empty">
			<h2 className="reform-side__name">{__( 'Fields', 'reform-contact-form' )}</h2>
			<p className="reform-side__note">{__( 'Click a blue chip in the editor, or a name below, to change its settings. To make a group, select some code and right-click.', 'reform-contact-form' )}</p>
			<p className="reform-side__note">
				<a href={data.docsUrl} target="_blank" rel="noopener noreferrer">
					{__( 'Read the documentation', 'reform-contact-form' )}
				</a>
			</p>
			<ul className="reform-side__list">
				{fields.map((name) => (
					<li key={name}>
						<button type="button" onClick={() => onSelect(name)}>
							<Icon name={typeOf(config.fields[name]?.type)?.icon || 'info'} />
							{name}
						</button>
					</li>
				))}
			</ul>
		</div>
	);
};
