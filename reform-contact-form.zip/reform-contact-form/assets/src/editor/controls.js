/**
 * Small controls of the sidebar and the tabs, in the editor's own look
 */
import { useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Icon } from './icons.js';

let uid = 0;
const useId = (prefix) => useState(() => `reform-${prefix}-${++uid}`)[0];

// The label row (label, then the "i" shown on hover), the folded tip under it, then the control; a toggle's tip
// goes under the toggle
export const Field = ({ label, help, id, children, inline = false }) => {
	const [open, setOpen] = useState(false);
	const info = help && (
		<button type="button" className={`reform-field-row__info${open ? ' is-active' : ''}`} aria-expanded={open} aria-label={__( 'Help', 'reform-contact-form' )} onClick={() => setOpen(!open)}>
			i
		</button>
	);
	const tip = help && open && <p className="reform-field-row__help">{help}</p>;

	if (inline) {
		return (
			<div className="reform-field-row is-inline">
				<div className="reform-field-row__head">
					{children}
					{info}
				</div>
				{tip}
			</div>
		);
	}

	return (
		<div className="reform-field-row">
			{(label || info) && (
				<div className="reform-field-row__head">
					{label && (
						<label className="reform-field-row__label" htmlFor={id}>
							{label}
						</label>
					)}
					{info}
				</div>
			)}
			{tip}
			{children}
		</div>
	);
};

export const Text = ({ label, help, value, onChange, ...rest }) => {
	const id = useId('text');

	return (
		<Field label={label} help={help} id={id}>
			<input id={id} className="reform-input" type="text" value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest} />
		</Field>
	);
};

// How far the ruler moves for one step, px
const TURN = 2;

// A number with a ruler under it: drag the ruler sideways or step with its arrows
// (Shift: by 10). Empty stays empty
export const NumberInput = ({ label, help, value, onChange, step = 1, min = 0 }) => {
	const id = useId('number');
	const track = useRef(null);
	const drag = useRef(null);
	const spin = useRef(0);
	const [dragging, setDragging] = useState(false);
	const shown = value === 0 || value === '' || value === undefined || value === null ? '' : value;
	const current = () => parseFloat(drag.current?.value ?? shown) || 0;

	const turn = (steps) => {
		spin.current += steps * TURN;

		if (track.current) {
			track.current.style.backgroundPositionX = `${Math.round(spin.current)}px`;
		}
	};

	const set = (next) => onChange(String(Math.max(min, Math.round(next / step) * step)));

	const onPointerDown = (event) => {
		event.currentTarget.setPointerCapture(event.pointerId);
		drag.current = { x: event.clientX, value: current() };
		setDragging(true);
	};

	const onPointerMove = (event) => {
		if (!drag.current) {
			return;
		}

		// Let go where no pointerup came (out of the window): the drag is over
		if (!event.buttons) {
			onPointerUp();

			return;
		}

		const steps = (event.clientX - drag.current.x) * (event.shiftKey ? 10 : 1);

		drag.current.x = event.clientX;
		drag.current.value = Math.max(min, drag.current.value + steps * step);
		turn(steps);
		set(drag.current.value);
	};

	const onPointerUp = () => {
		drag.current = null;
		setDragging(false);
	};

	const stepBy = (event, direction) => {
		const delta = direction * step * (event.shiftKey ? 10 : 1);

		turn(delta / step);
		set(current() + delta);
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className={`reform-number${dragging ? ' is-dragging' : ''}`}>
				<input id={id} className="reform-input" type="number" min={min} step={step} value={shown} onChange={(e) => onChange(e.target.value)} />
				<div className="reform-number__ruler">
					<button type="button" className="reform-number__step" tabIndex={-1} aria-hidden="true" onClick={(e) => stepBy(e, -1)}>
						◀
					</button>
					<span
						className="reform-number__track"
						ref={track}
						title={__( 'Drag to change (Shift: faster)', 'reform-contact-form' )}
						onPointerDown={onPointerDown}
						onPointerMove={onPointerMove}
						onPointerUp={onPointerUp}
						onPointerCancel={onPointerUp}
						onLostPointerCapture={onPointerUp}
					/>
					<button type="button" className="reform-number__step" tabIndex={-1} aria-hidden="true" onClick={(e) => stepBy(e, 1)}>
						▶
					</button>
				</div>
			</div>
		</Field>
	);
};

export const Textarea = ({ label, help, value, onChange, rows = 4, mono = false, ...rest }) => {
	const id = useId('textarea');

	return (
		<Field label={label} help={help} id={id}>
			<textarea id={id} className={`reform-input${mono ? ' is-mono' : ''}`} rows={rows} value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest} />
		</Field>
	);
};

// Text edited as lines, parsed on each change but kept as typed while the field is open
export const LinesControl = ({ label, help, value, toText, fromText, onChange, rows = 4, placeholder }) => {
	const [text, setText] = useState(() => toText(value));

	return (
		<Textarea
			label={label}
			help={help}
			rows={rows}
			mono
			placeholder={placeholder}
			value={text}
			onChange={(next) => {
				setText(next);
				onChange(fromText(next));
			}}
		/>
	);
};

export const Select = ({ label, help, value, onChange, options }) => {
	const id = useId('select');

	return (
		<Field label={label} help={help} id={id}>
			<select id={id} className="reform-input reform-select" value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
				{Object.entries(options).map(([key, text]) => (
					<option key={key} value={key}>
						{text}
					</option>
				))}
			</select>
		</Field>
	);
};

// A date setting: none, today, days from today (today+7, today-1) or a fixed YYYY-MM-DD; the site turns "today"
// into a date when the form is shown
const RELATIVE = /^today([+-]\d+)?$/;
const isoDay = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

export const DateControl = ({ label, help, value, onChange, empty }) => {
	const id = useId('date');
	const current = value || '';
	const relative = current.match(RELATIVE);
	let mode = 'date';

	if (!current) {
		mode = 'none';
	} else if (current === 'today') {
		mode = 'today';
	} else if (relative) {
		mode = 'offset';
	}

	const days = relative ? Number(relative[1] || 0) : 0;
	const preview = (offset) => {
		const date = new Date();

		date.setDate(date.getDate() + offset);

		return date.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
	};

	const pick = (next) => {
		if (next === 'none') {
			onChange('');
		} else if (next === 'today') {
			onChange('today');
		} else if (next === 'offset') {
			onChange('today+7');
		} else {
			onChange(isoDay(new Date()));
		}
	};

	return (
		<Field label={label} help={help} id={id}>
			<div className="reform-date">
				<select id={id} className="reform-input reform-select" value={mode} onChange={(e) => pick(e.target.value)}>
					<option value="none">{empty || __( 'None', 'reform-contact-form' )}</option>
					<option value="today">{__( 'Today', 'reform-contact-form' )}</option>
					<option value="offset">{__( 'Days from today', 'reform-contact-form' )}</option>
					<option value="date">{__( 'A set date', 'reform-contact-form' )}</option>
				</select>

				{mode === 'date' && (
					<input className="reform-input" type="date" aria-label={label} value={current} onChange={(e) => onChange(e.target.value)} />
				)}

				{mode === 'offset' && (
					<div className="reform-date__offset">
						<input
							className="reform-input"
							type="number"
							step="1"
							aria-label={__( 'Days from today', 'reform-contact-form' )}
							value={days}
							onChange={(e) => {
								const n = parseInt(e.target.value, 10) || 0;

								onChange(n ? `today${n > 0 ? '+' : ''}${n}` : 'today');
							}}
						/>
						<span>{__( 'days; a minus is before today', 'reform-contact-form' )}</span>
					</div>
				)}

				{(mode === 'today' || mode === 'offset') && (
					<p className="reform-date__preview">
						{/* translators: %s: a date */ sprintf( __( 'Today that is %s. It moves with each day.', 'reform-contact-form' ), preview(days) )}
					</p>
				)}
			</div>
		</Field>
	);
};

export const Toggle = ({ label, help, checked, onChange, disabled = false }) => {
	const id = useId('toggle');

	return (
		<Field help={help} inline>
			<label className="reform-check" htmlFor={id}>
				<input id={id} type="checkbox" checked={Boolean(checked)} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
				<span>{label}</span>
			</label>
		</Field>
	);
};

export const Button = ({ variant = 'secondary', icon, children, className = '', ...rest }) => (
	<button type="button" className={`reform-button is-${variant} ${className}`} {...rest}>
		{icon && <Icon name={icon} />}
		{children}
	</button>
);
