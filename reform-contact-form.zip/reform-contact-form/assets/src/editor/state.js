/**
 * The editor's data helpers: field types, names, renames, what is placed in the template
 */
import { __, sprintf } from '@wordpress/i18n';

const data = window.reformEditor || {};

export const TOKEN = /\[\[(\/group|group:[a-zA-Z][\w-]*|[a-zA-Z][\w-]*)\]\]/g;
export const NAME = /^[a-zA-Z][\w-]*$/;
// Places (reform_places): [[captcha]], [[response]] and the add-ons' tokens with no settings
export const places = data.places || {};
export const RESERVED = ['group', ...Object.keys(places)];

export const types = data.types || [];
export const typeOf = (type) => types.find((t) => t.type === type);

/**
 * Where the HTML tag around a position ends, or -1 when the position is between tags (a token there would break
 * the tag: <div clas[[name]]s="…">)
 *
 * @param {string} text Template
 * @param {number} pos  Position
 * @return {number} End of the tag, after its >
 */
export const tagEndAt = (text, pos) => {
	const open = text.lastIndexOf('<', pos - 1);

	if (open < 0 || text.lastIndexOf('>', pos - 1) > open || !/[a-zA-Z/]/.test(text[open + 1] || '')) {
		return -1;
	}

	const close = text.indexOf('>', pos);

	return close < 0 ? text.length : close + 1;
};

/**
 * A position out of any tag: the end of the tag it falls in, else itself
 *
 * @param {string} text Template
 * @param {number} pos  Position
 * @return {number} Position
 */
export const outsideTag = (text, pos) => {
	const end = tagEndAt(text, pos);

	return end < 0 ? pos : end;
};

/**
 * Names of the fields and groups whose tokens sit inside an HTML tag
 *
 * @param {string} template Template
 * @return {string[]} Names, as the chips show them
 */
export const misplaced = (template) => [...template.matchAll(TOKEN)].filter((m) => m[1] !== '/group' && tagEndAt(template, m.index) >= 0).map((m) => m[1].replace(/^group:/, __( 'group ', 'reform-contact-form' )));

/**
 * Field names and group names in the template, in order
 *
 * @param {string} template Template
 * @return {{fields: string[], groups: string[]}} Names
 */
export const placed = (template) => {
	const fields = [];
	const groups = [];

	for (const [, inner] of template.matchAll(TOKEN)) {
		if (inner.startsWith('group:')) {
			groups.includes(inner.slice(6)) || groups.push(inner.slice(6));
		} else if (inner !== '/group' && !RESERVED.includes(inner) && !fields.includes(inner)) {
			fields.push(inner);
		}
	}

	return { fields, groups };
};

/**
 * A free name for a new field or group: text_1, text_2…
 *
 * @param {string} base   Start of the name
 * @param {Object} config Settings
 * @param {string} template Template
 * @return {string} Name
 */
export const freeName = (base, config, template) => {
	const taken = new Set([...Object.keys(config.fields || {}), ...Object.keys(config.groups || {}), ...placed(template).fields, ...placed(template).groups]);

	for (let i = 1; ; i++) {
		if (!taken.has(`${base}_${i}`)) {
			return `${base}_${i}`;
		}
	}
};

/**
 * Whether a new name can be used
 *
 * @param {string} name     Name
 * @param {Object} config   Settings
 * @param {string} template Template
 * @return {boolean} Usable
 */
export const nameFree = (name, config, template) =>
	NAME.test(name) && !RESERVED.includes(name) && !(name in (config.fields || {})) && !(name in (config.groups || {})) && !placed(template).fields.includes(name) && !placed(template).groups.includes(name);

/**
 * A field of another type: what both types share is kept
 *
 * @param {Object} field Field settings
 * @param {string} type  New type
 * @return {Object} Field settings
 */
export const changeType = (field, type) => {
	const defaults = { ...(typeOf(type)?.defaults || {}) };

	Object.keys(defaults).forEach((key) => {
		if (key !== 'type' && key in field) {
			defaults[key] = field[key];
		}
	});

	return { ...defaults, type };
};

/**
 * Replace a name everywhere the settings use it: the fields' key, output sources, group rules, mail tags
 *
 * @param {Object} config Settings
 * @param {string} from   Old name
 * @param {string} to     New name
 * @param {string} kind   field or group
 * @return {Object} Settings
 */
export const rename = (config, from, to, kind) => {
	const next = structuredClone(config);
	const swap = (obj) => Object.fromEntries(Object.entries(obj || {}).map(([key, value]) => [key === from ? to : key, value]));
	const tags = (text) =>
		kind === 'field'
			? String(text).replaceAll(`[${from}]`, `[${to}]`).replaceAll(`[_raw_${from}]`, `[_raw_${to}]`)
			: String(text).replaceAll(`[group:${from}]`, `[group:${to}]`).replaceAll(`[/group:${from}]`, `[/group:${to}]`);

	if (kind === 'field') {
		next.fields = swap(next.fields);
		Object.values(next.fields).forEach((field) => {
			if (field.source === from) {
				field.source = to;
			}
		});
		Object.values(next.groups || {}).forEach((group) => (group.rules || []).forEach((r) => r.field === from && (r.field = to)));
	} else {
		next.groups = swap(next.groups);
	}

	['mail', 'mail_2'].forEach((mail) => {
		['to', 'from', 'subject', 'headers', 'body', 'attachments'].forEach((key) => {
			if (next[mail]?.[key]) {
				next[mail][key] = tags(next[mail][key]);
			}
		});
	});

	return next;
};

/**
 * The settings of what is placed only, for saving
 *
 * @param {Object} config   Settings
 * @param {string} template Template
 * @return {Object} Settings
 */
export const prune = (config, template) => {
	const { fields, groups } = placed(template);
	const pick = (obj, names) => Object.fromEntries(Object.entries(obj || {}).filter(([key]) => names.includes(key)));

	return { ...config, fields: pick(config.fields, fields), groups: pick(config.groups, groups) };
};

/**
 * What would go wrong in the mails: tags no field or group answers to ([email] when the field is your_email), a
 * mail without a recipient
 *
 * @param {Object} config   Settings
 * @param {string} template Template
 * @return {Array<{mail: string, text: string}>} Problems
 */
export const mailProblems = (config, template) => {
	const { fields, groups } = placed(template);
	const known = new Set([...fields, ...(data.specialTags || [])]);
	const labels = {
		to: __( 'To', 'reform-contact-form' ),
		from: __( 'From', 'reform-contact-form' ),
		subject: __( 'Subject', 'reform-contact-form' ),
		headers: __( 'Additional headers', 'reform-contact-form' ),
		body: __( 'Message', 'reform-contact-form' ),
		attachments: __( 'Attachments', 'reform-contact-form' ),
	};
	const problems = [];

	['mail', 'mail_2'].forEach((key) => {
		const mail = config[key] || {};

		if (key === 'mail_2' && !mail.active) {
			return;
		}

		const which = key === 'mail' ? __( 'Mail', 'reform-contact-form' ) : __( 'Mail 2', 'reform-contact-form' );

		if (!String(mail.to || '').trim()) {
			problems.push({ mail: which, text: __( 'To is empty, so this mail has nowhere to go.', 'reform-contact-form' ) });
		}

		Object.keys(labels).forEach((part) => {
			for (const [, close, group, raw, name] of String(mail[part] || '').matchAll(/\[(\/?)(group:)?(_raw_)?([a-zA-Z_][\w-]*)\]/g)) {
				const tag = `[${close}${group || ''}${raw || ''}${name}]`;

				if (group ? !groups.includes(name) : !known.has(name)) {
					problems.push({
						mail: which,
						text: group
							? /* translators: 1: tag, 2: part of the mail */ sprintf( __( '%1$s in %2$s: no group has that name.', 'reform-contact-form' ), tag, labels[part] )
							: /* translators: 1: tag such as [email], 2: part of the mail */ sprintf( __( '%1$s in %2$s: no field has that name.', 'reform-contact-form' ), tag, labels[part] ),
					});
				}
			}
		});
	});

	return problems;
};

/**
 * Options as "value : Label" lines, and back
 */
export const optionsToText = (options) => (options || []).map((o) => (o.value === o.label ? o.value : `${o.value} : ${o.label}`)).join('\n');
export const textToOptions = (text) =>
	text
		.split('\n')
		.map((line) => line.trim())
		.filter(Boolean)
		.map((line) => {
			const [value, ...rest] = line.split(' : ');
			const label = rest.join(' : ').trim();

			return { value: value.trim(), label: label || value.trim() };
		});

/**
 * Quiz questions as "question | answer" lines, and back
 */
export const pairsToText = (pairs) => (pairs || []).map((p) => `${p.question} | ${p.answer}`).join('\n');
export const textToPairs = (text) =>
	text
		.split('\n')
		.map((line) => line.trim())
		.filter(Boolean)
		.map((line) => {
			const [question, ...rest] = line.split('|');

			return { question: question.trim(), answer: rest.join('|').trim() };
		});

export default data;
