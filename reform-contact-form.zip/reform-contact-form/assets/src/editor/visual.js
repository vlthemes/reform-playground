/**
 * Visual view of the Form tab: the unsaved form on a front-end page with the theme's styles (Admin\Preview),
 * reloaded as it changes. A click on a field there selects it here.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import Loader from './loader.js';
import data, { prune } from './state.js';

const Visual = ({ doc, selected, onSelect }) => {
	const frame = useRef(null);
	const post = useRef(null);
	// first: nothing shown yet; true: reloading over the last view; false: shown
	const [loading, setLoading] = useState('first');
	const json = JSON.stringify({ id: data.form.id, title: doc.title, template: doc.template, config: prune(doc.config, doc.template) });

	// Reload a moment after the last change
	useEffect(() => {
		const timer = setTimeout(() => {
			setLoading((state) => (state === 'first' ? state : true));
			post.current?.submit();
		}, 350);

		return () => clearTimeout(timer);
	}, [json]);

	useEffect(() => {
		const receive = (event) => {
			if (event.source === frame.current?.contentWindow && event.data?.reform === 'select') {
				onSelect(event.data.name);
			}
		};

		window.addEventListener('message', receive);

		return () => window.removeEventListener('message', receive);
	}, [onSelect]);

	// The selected field is outlined in the frame, after each load too
	const mark = () => frame.current?.contentWindow?.postMessage({ reform: 'selected', name: selected?.kind === 'field' ? selected.name : '' }, '*');

	useEffect(mark, [selected]); // eslint-disable-line react-hooks/exhaustive-deps

	return (
		<div className={`reform-visual${loading ? ' is-loading' : ''}${loading === 'first' ? ' is-first' : ''}`}>
			<iframe
				ref={frame}
				name="reform-visual-frame"
				title={__( 'Visual view', 'reform-contact-form' )}
				className="reform-visual__frame"
				onLoad={() => {
					// The empty frame loads once before the form is posted to it
					if (frame.current?.contentWindow?.location.href !== 'about:blank') {
						setLoading(false);
					}

					mark();
				}}
			/>
			{loading && (
				<div className="reform-visual__loading">
					<Loader />
				</div>
			)}
			<form ref={post} method="post" action={data.previewUrl} target="reform-visual-frame" hidden>
				<input type="hidden" name="_wpnonce" value={data.previewNonce} />
				<input type="hidden" name="data" value={json} />
			</form>
		</div>
	);
};

export default Visual;
