/**
 * Preview (the header's button): the unsaved form on a front-end page with the theme's styles (Admin\Preview), in a
 * popup, reloaded as it changes. A click on a field there closes it and opens the field's settings.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Icon } from './icons.js';
import Loader from './loader.js';
import data, { prune } from './state.js';

const Visual = ({ doc, selected, onSelect }) => {
	const frame = useRef(null);
	const post = useRef(null);
	// first: nothing shown yet; true: reloading over the last view; false: shown
	const [loading, setLoading] = useState('first');
	const json = JSON.stringify({ id: data.form.id, title: doc.title, template: doc.template, config: prune(doc.config, doc.template) });

	// Reload a moment after the last change
	useEffect(() => {
		const timer = setTimeout(() => {
			setLoading((state) => (state === 'first' ? state : true));
			post.current?.submit();
		}, 350);

		return () => clearTimeout(timer);
	}, [json]);

	useEffect(() => {
		const receive = (event) => {
			if (event.source === frame.current?.contentWindow && event.data?.reform === 'select') {
				onSelect(event.data.name);
			}
		};

		window.addEventListener('message', receive);

		return () => window.removeEventListener('message', receive);
	}, [onSelect]);

	// The selected field is outlined in the frame, after each load too
	const mark = () => frame.current?.contentWindow?.postMessage({ reform: 'selected', name: selected?.kind === 'field' ? selected.name : '' }, '*');

	useEffect(mark, [selected]); // eslint-disable-line react-hooks/exhaustive-deps

	return (
		<div className={`reform-visual${loading ? ' is-loading' : ''}${loading === 'first' ? ' is-first' : ''}`}>
			<iframe
				ref={frame}
				name="reform-visual-frame"
				title={__( 'Visual view', 'reform-contact-form' )}
				className="reform-visual__frame"
				onLoad={() => {
					// The empty frame loads once before the form is posted to it
					if (frame.current?.contentWindow?.location.href !== 'about:blank') {
						setLoading(false);
					}

					mark();
				}}
			/>
			{loading && (
				<div className="reform-visual__loading">
					<Loader />
				</div>
			)}
			<form ref={post} method="post" action={data.previewUrl} target="reform-visual-frame" hidden>
				<input type="hidden" name="_wpnonce" value={data.previewNonce} />
				<input type="hidden" name="data" value={json} />
			</form>
		</div>
	);
};

export default Visual;

export const Preview = ({ doc, selected, onSelect, onClose }) => {
	// Escape closes it, wherever the focus is outside the frame
	useEffect(() => {
		const key = (e) => e.key === 'Escape' && onClose();

		document.addEventListener('keydown', key);

		return () => document.removeEventListener('keydown', key);
	}, [onClose]);

	return (
		<div className="reform-dialog is-preview" role="dialog" aria-modal="true" aria-labelledby="reform-preview-title" onClick={(e) => e.target === e.currentTarget && onClose()}>
			<div className="reform-dialog__box">
				<div className="reform-dialog__head">
					<h2 id="reform-preview-title">
						{__( 'Preview', 'reform-contact-form' )}
						<span>{__( 'With your theme\'s styles, before saving. Click a field to edit it.', 'reform-contact-form' )}</span>
					</h2>
					<button type="button" className="reform-dialog__close" onClick={onClose} aria-label={__( 'Close', 'reform-contact-form' )} autoFocus>
						<Icon name="close" />
					</button>
				</div>
				<Visual doc={doc} selected={selected} onSelect={onSelect} />
			</div>
		</div>
	);
};
