<?php
/**
 * Deleting the plugin: forms, entries and settings go only when Settings → Entries says so
 *
 * @package VLT\Reform
 */

if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$reform_settings = get_option( 'reform_settings', [] );

if ( empty( $reform_settings['entries']['delete_data'] ) ) {
	return;
}

foreach ( [ 'reform_form', 'reform_entry' ] as $reform_type ) {
	$reform_ids = get_posts( [ 'post_type' => $reform_type, 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids' ] );

	foreach ( $reform_ids as $reform_id ) {
		wp_delete_post( $reform_id, true );
	}
}

delete_option( 'reform_settings' );
delete_option( 'reform_version' );
delete_option( 'reform_captcha_status' );
delete_option( 'reform_paypal_merchant' );
wp_clear_scheduled_hook( 'reform_entries_cleanup' );
