<?php

namespace VLT\Reform\Submission;

use VLT\Reform\Fields\File;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Files sent with a form: checked, kept in uploads/reform/ (closed to the web) until mailed
 */
class Uploads {
	/**
	 * Receive a field's files
	 *
	 * @param array|null $upload The field's entry of $_FILES
	 * @param array      $field  Field
	 *
	 * @return array [ files [ [ 'name', 'path', 'size', 'type' ], … ], error message key ]
	 */
	public static function receive( $upload, array $field ) {
		$files = [];

		foreach ( self::normalize( $upload ) as $file ) {
			if ( UPLOAD_ERR_NO_FILE === $file['error'] ) {
				continue;
			}

			$error = self::check( $file, $field );

			if ( $error ) {
				self::delete( $files );

				return [ [], $error ];
			}

			$stored = self::store( $file );

			if ( !$stored ) {
				self::delete( $files );

				return [ [], 'upload_failed' ];
			}

			$files[] = $stored;

			if ( !$field['multiple'] ) {
				break;
			}
		}

		return [ $files, '' ];
	}

	/**
	 * Delete stored files and their folders
	 *
	 * @param array $files Files
	 */
	public static function delete( array $files ) {
		foreach ( $files as $file ) {
			$path = (string) ( $file['path'] ?? '' );

			if ( $path && 0 === strpos( wp_normalize_path( $path ), wp_normalize_path( self::dir() ) ) && is_file( $path ) ) {
				wp_delete_file( $path );
				@rmdir( dirname( $path ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- the file's own folder, empty now
			}
		}
	}

	/**
	 * The folder files are kept in, closed to the web
	 *
	 * @return string
	 */
	public static function dir() {
		$dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'reform';

		if ( !is_dir( $dir ) && wp_mkdir_p( $dir ) ) {
			// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- tiny guard files
			file_put_contents( $dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
			file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" );
			// phpcs:enable
		}

		return $dir;
	}

	/**
	 * A field's files as a list, whether one or several were sent
	 *
	 * @param array|null $upload Entry of $_FILES
	 *
	 * @return array
	 */
	private static function normalize( $upload ) {
		if ( !is_array( $upload ) || !isset( $upload['name'] ) ) {
			return [];
		}

		if ( !is_array( $upload['name'] ) ) {
			return [ self::one( $upload ) ];
		}

		$files = [];

		foreach ( array_keys( $upload['name'] ) as $i ) {
			$files[] = self::one( [
				'name'     => $upload['name'][ $i ],
				'type'     => $upload['type'][ $i ] ?? '',
				'tmp_name' => $upload['tmp_name'][ $i ] ?? '',
				'error'    => $upload['error'][ $i ] ?? UPLOAD_ERR_NO_FILE,
				'size'     => $upload['size'][ $i ] ?? 0,
			] );
		}

		return $files;
	}

	/**
	 * One file's entry, typed
	 *
	 * @param array $file Entry
	 *
	 * @return array
	 */
	private static function one( array $file ) {
		return [
			'name'     => (string) $file['name'],
			'tmp_name' => (string) $file['tmp_name'],
			'error'    => (int) $file['error'],
			'size'     => (int) $file['size'],
		];
	}

	/**
	 * Check a file against the field
	 *
	 * @param array $file  File
	 * @param array $field Field
	 *
	 * @return string Message key, '' when fine
	 */
	private static function check( array $file, array $field ) {
		if ( in_array( $file['error'], [ UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ], true ) ) {
			return 'upload_file_too_large';
		}

		if ( UPLOAD_ERR_OK !== $file['error'] || !is_uploaded_file( $file['tmp_name'] ) ) {
			return 'upload_failed';
		}

		if ( $file['size'] > File::max_bytes( $field ) ) {
			return 'upload_file_too_large';
		}

		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );

		if ( !in_array( $ext, File::extensions( $field ), true ) ) {
			return 'upload_file_type_invalid';
		}

		// Only types WordPress allows, whatever the field lists
		$checked = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );

		return empty( $checked['ext'] ) ? 'upload_file_type_invalid' : '';
	}

	/**
	 * Move a file into a folder of its own, through WordPress's upload handling
	 *
	 * @param array $file File
	 *
	 * @return array|null [ 'name', 'path', 'size', 'type' ]
	 */
	private static function store( array $file ) {
		$folder = self::dir() . '/' . wp_generate_password( 20, false );

		if ( !wp_mkdir_p( $folder ) ) {
			return null;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		// The file goes to the private folder, never to the media library's
		$to_folder = static fn( $dirs ) => [
			'path'    => $folder,
			'url'     => '',
			'subdir'  => '',
			'basedir' => $folder,
			'baseurl' => '',
			'error'   => false,
		] + $dirs;

		// Passed by reference
		$upload = [ 'name' => sanitize_file_name( $file['name'] ) ] + $file;

		add_filter( 'upload_dir', $to_folder );
		$moved = wp_handle_upload( $upload, [ 'test_form' => false ] );
		remove_filter( 'upload_dir', $to_folder );

		if ( empty( $moved['file'] ) ) {
			return null;
		}

		return [
			'name' => wp_basename( $moved['file'] ),
			'path' => $moved['file'],
			'size' => $file['size'],
			'type' => (string) $moved['type'],
		];
	}
}
