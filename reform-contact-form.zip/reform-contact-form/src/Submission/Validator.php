<?php

namespace VLT\Reform\Submission;

use VLT\Reform\Core\Messages;
use VLT\Reform\Fields\FieldRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks a submission's values: each type's rules, then reform_validate_{type} and reform_validate
 */
class Validator {
	/**
	 * Errors of a submission
	 *
	 * @param Submission $submission Submission
	 *
	 * @return array [ name => message ]
	 */
	public static function validate( Submission $submission ) {
		$form   = $submission->form();
		$hidden = Conditions::hidden_fields( $form, $submission->hidden_groups() );
		$errors = [];

		foreach ( $form->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( !$type || !$type->submits() || in_array( $name, $hidden, true ) ) {
				continue;
			}

			$value   = $submission->posted( $name );
			$key     = $type->validate( $value, $field, $submission );
			$message = (string) apply_filters( 'reform_validate_' . $field['type'], $key ? Messages::get( $form, $key ) : '', $value, $field, $submission );

			if ( '' !== $message ) {
				$errors[ $name ] = $message;
			}
		}

		return (array) apply_filters( 'reform_validate', $errors, $submission );
	}
}
