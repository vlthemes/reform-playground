<?php

namespace VLT\Reform\Submission;

use VLT\Reform\Fields\Field;
use VLT\Reform\Forms\Form;
use VLT\Reform\Forms\Template;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Groups shown or hidden by their conditions; reform.js runs the same rules in the browser
 *
 * A group inside a hidden one is hidden, and a field in a hidden group counts as empty for other rules.
 */
class Conditions {
	/**
	 * The hidden groups for these values
	 *
	 * @param Form  $form   Form
	 * @param array $values Values by field name
	 *
	 * @return string[]
	 */
	public static function hidden_groups( Form $form, array $values ) {
		$ancestry = Template::ancestry( $form->template() );
		$groups   = $form->groups();
		$hidden   = [];

		// A rule may read a field another group hides: settle in a few passes
		for ( $pass = 0; $pass < 3; $pass++ ) {
			$visible = $values;

			foreach ( $ancestry['fields'] as $name => $parents ) {
				if ( array_intersect( $parents, $hidden ) && isset( $visible[ $name ] ) ) {
					$visible[ $name ] = is_array( $visible[ $name ] ) ? [] : '';
				}
			}

			$next = [];

			foreach ( $ancestry['groups'] as $name => $parents ) {
				if ( array_intersect( $parents, $next ) ) {
					$next[] = $name;
					continue;
				}

				$group = $groups[ $name ] ?? null;

				if ( !$group || empty( $group['rules'] ) ) {
					continue;
				}

				$matches = self::matches( $group, $visible );

				if ( 'show' === $group['action'] ? !$matches : $matches ) {
					$next[] = $name;
				}
			}

			if ( $next === $hidden ) {
				break;
			}

			$hidden = $next;
		}

		return $hidden;
	}

	/**
	 * The fields inside hidden groups
	 *
	 * @param Form     $form   Form
	 * @param string[] $hidden Hidden groups
	 *
	 * @return string[]
	 */
	public static function hidden_fields( Form $form, array $hidden ) {
		if ( !$hidden ) {
			return [];
		}

		$names = [];

		foreach ( Template::ancestry( $form->template() )['fields'] as $name => $parents ) {
			if ( array_intersect( $parents, $hidden ) ) {
				$names[] = $name;
			}
		}

		return $names;
	}

	/**
	 * Whether a group's rules match
	 *
	 * @param array $group  [ 'match' => all|any, 'rules' ]
	 * @param array $values Values
	 *
	 * @return bool
	 */
	public static function matches( array $group, array $values ) {
		foreach ( $group['rules'] as $rule ) {
			$ok = self::rule( $rule, $values[ $rule['field'] ] ?? '' );

			if ( 'any' === $group['match'] && $ok ) {
				return true;
			}

			if ( 'all' === $group['match'] && !$ok ) {
				return false;
			}
		}

		return 'all' === $group['match'];
	}

	/**
	 * Whether one rule matches a value
	 *
	 * @param array        $rule  [ 'op', 'value' ]
	 * @param string|array $value Field value
	 *
	 * @return bool
	 */
	private static function rule( array $rule, $value ) {
		$target = (string) $rule['value'];

		switch ( $rule['op'] ) {
			case 'is':
				return is_array( $value ) ? in_array( $target, array_map( 'strval', $value ), true ) : (string) $value === $target;
			case 'is_not':
				return !self::rule( [ 'op' => 'is' ] + $rule, $value );
			case 'contains':
				return is_array( $value ) ? in_array( $target, array_map( 'strval', $value ), true ) : false !== mb_stripos( (string) $value, $target );
			case 'not_contains':
				return !self::rule( [ 'op' => 'contains' ] + $rule, $value );
			case 'empty':
				return Field::is_empty( $value );
			case 'not_empty':
				return !Field::is_empty( $value );
			case 'gt':
				return is_numeric( $value ) && is_numeric( $target ) && (float) $value > (float) $target;
			case 'lt':
				return is_numeric( $value ) && is_numeric( $target ) && (float) $value < (float) $target;
		}

		return false;
	}
}
