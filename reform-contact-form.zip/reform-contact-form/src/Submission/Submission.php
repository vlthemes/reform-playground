<?php

namespace VLT\Reform\Submission;

use VLT\Reform\Core\Messages;
use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Forms\Form;
use VLT\Reform\Mail\Mailer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One submission of a form: values, spam check, conditions, validation, mail
 *
 *     $result = ( new Submission( $form, $data, $files ) )->run();
 */
class Submission {
	/**
	 * Form
	 *
	 * @var Form
	 */
	private $form;

	/**
	 * Request data, unslashed
	 *
	 * @var array
	 */
	private $data;

	/**
	 * Uploaded files ($_FILES shape)
	 *
	 * @var array
	 */
	private $files;

	/**
	 * Where and by whom: ip, user_agent, url, post_id, user_id, time
	 *
	 * @var array
	 */
	private $meta;

	/**
	 * Clean values by field name
	 *
	 * @var array
	 */
	private $posted = [];

	/**
	 * Upload errors by field name (message keys)
	 *
	 * @var array
	 */
	private $upload_errors = [];

	/**
	 * Groups hidden by their conditions
	 *
	 * @var string[]
	 */
	private $hidden_groups = [];

	/**
	 * Errors by field name
	 *
	 * @var array
	 */
	private $invalid = [];

	/**
	 * success, invalid, failed, spam or aborted
	 *
	 * @var string
	 */
	private $status = '';

	/**
	 * Message shown
	 *
	 * @var string
	 */
	private $message = '';

	/**
	 * Set by abort()
	 *
	 * @var string|null
	 */
	private $abort = null;

	/**
	 * Constructor
	 *
	 * @param Form  $form  Form
	 * @param array $data  Request data, unslashed
	 * @param array $files Uploaded files
	 * @param array $meta  What is known of the request
	 */
	public function __construct( Form $form, array $data, array $files = [], array $meta = [] ) {
		$this->form  = $form;
		$this->data  = $data;
		$this->files = $files;
		$this->meta  = $meta + [
			'ip'         => self::remote_ip(),
			'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 255 ) : '',
			'url'        => esc_url_raw( (string) wp_get_referer() ),
			'post_id'    => absint( $data['_reform_post'] ?? 0 ),
			'user_id'    => get_current_user_id(),
			'time'       => time(),
		];
	}

	/**
	 * Run it
	 *
	 * @return array [ 'status', 'message', 'invalid' => [ name => message ], 'posted' ]
	 */
	public function run() {
		$settings = $this->form->config()['settings'];

		if ( !empty( $settings['subscribers_only'] ) && !is_user_logged_in() ) {
			return $this->finish( 'aborted', Messages::get( $this->form, 'login_required' ) );
		}

		$this->read();

		if ( !apply_filters( 'reform_skip_spam_check', false, $this ) && apply_filters( 'reform_spam', false, $this ) ) {
			return $this->finish( 'spam' );
		}

		$this->hidden_groups = Conditions::hidden_groups( $this->form, $this->posted );

		// A hidden field sends nothing
		foreach ( Conditions::hidden_fields( $this->form, $this->hidden_groups ) as $name ) {
			if ( array_key_exists( $name, $this->posted ) ) {
				Uploads::delete( 'file' === ( $this->form->field( $name )['type'] ?? '' ) ? (array) $this->posted[ $name ] : [] );
				$this->posted[ $name ] = is_array( $this->posted[ $name ] ) ? [] : '';
				unset( $this->upload_errors[ $name ] );
			}
		}

		$this->invalid = Validator::validate( $this );

		if ( $this->invalid ) {
			return $this->finish( 'invalid' );
		}

		// Test mode: all checked, nothing sent or saved
		if ( $this->is_demo() ) {
			return $this->finish( 'success' );
		}

		do_action_ref_array( 'reform_before_send_mail', [ $this ] );

		if ( null !== $this->abort ) {
			return $this->finish( 'aborted', $this->abort );
		}

		$sent = Mailer::send_all( $this );

		if ( $sent ) {
			do_action( 'reform_mail_sent', $this );
		} else {
			do_action( 'reform_mail_failed', $this );
		}

		return $this->finish( $sent ? 'success' : 'failed' );
	}

	/**
	 * Read the values of the fields placed in the form
	 */
	private function read() {
		foreach ( $this->form->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( !$type || !$type->submits() ) {
				continue;
			}

			if ( 'file' === $field['type'] ) {
				[ $files, $error ] = Uploads::receive( $this->files[ $name ] ?? null, $field );

				$this->posted[ $name ] = $files;

				if ( $error ) {
					$this->upload_errors[ $name ] = $error;
				}

				continue;
			}

			$this->posted[ $name ] = $type->value( $this->data[ $name ] ?? '', $field );
		}

		$this->posted = (array) apply_filters( 'reform_posted_data', $this->posted, $this );
	}

	/**
	 * End with a status
	 *
	 * @param string $status  Status
	 * @param string $message Message ('' = the form's for the status)
	 *
	 * @return array
	 */
	private function finish( $status, $message = '' ) {
		$this->status  = $status;
		$this->message = '' !== $message ? $message : Messages::get( $this->form, 'aborted' === $status ? 'failed' : $status );

		do_action( 'reform_submitted', $this );

		// Files go once mailed, unless something (entries) keeps them
		if ( !apply_filters( 'reform_keep_uploads', false, $this ) ) {
			foreach ( $this->form->fields() as $name => $field ) {
				if ( 'file' === $field['type'] && !empty( $this->posted[ $name ] ) ) {
					Uploads::delete( (array) $this->posted[ $name ] );
				}
			}
		}

		return [
			'status'  => $this->status,
			'message' => $this->message,
			'invalid' => $this->invalid,
			'posted'  => array_filter( $this->posted, fn( $name ) => 'file' !== ( $this->form->field( $name )['type'] ?? '' ), ARRAY_FILTER_USE_KEY ),
		];
	}

	/**
	 * Whether the form is in test mode: checked, never sent or saved
	 *
	 * @return bool
	 */
	public function is_demo() {
		return !empty( $this->form->config()['settings']['demo'] ) || ( defined( 'REFORM_TEST_MODE' ) && REFORM_TEST_MODE );
	}

	/**
	 * Stop before the mail (from reform_before_send_mail)
	 *
	 * @param string $message Message shown ('' = the form's "failed" one)
	 */
	public function abort( $message = '' ) {
		$this->abort = (string) $message;
	}

	/**
	 * Form
	 *
	 * @return Form
	 */
	public function form() {
		return $this->form;
	}

	/**
	 * Clean values, or one
	 *
	 * @param string|null $name Field name
	 *
	 * @return mixed
	 */
	public function posted( $name = null ) {
		return null === $name ? $this->posted : ( $this->posted[ $name ] ?? '' );
	}

	/**
	 * Change a value (from reform_before_send_mail)
	 *
	 * @param string $name  Field name
	 * @param mixed  $value Value
	 */
	public function set( $name, $value ) {
		$this->posted[ $name ] = $value;
	}

	/**
	 * A raw request value (unslashed)
	 *
	 * @param string $key Key
	 *
	 * @return mixed
	 */
	public function raw( $key ) {
		return $this->data[ $key ] ?? null;
	}

	/**
	 * What is known of the request, or one part
	 *
	 * @param string|null $key ip, user_agent, url, post_id, user_id, time
	 *
	 * @return mixed
	 */
	public function meta( $key = null ) {
		return null === $key ? $this->meta : ( $this->meta[ $key ] ?? '' );
	}

	/**
	 * Upload error of a field
	 *
	 * @param string $name Field name
	 *
	 * @return string Message key
	 */
	public function upload_error( $name ) {
		return $this->upload_errors[ $name ] ?? '';
	}

	/**
	 * Groups hidden by their conditions
	 *
	 * @return string[]
	 */
	public function hidden_groups() {
		return $this->hidden_groups;
	}

	/**
	 * Status
	 *
	 * @return string
	 */
	public function status() {
		return $this->status;
	}

	/**
	 * Message
	 *
	 * @return string
	 */
	public function message() {
		return $this->message;
	}

	/**
	 * Errors by field name
	 *
	 * @return array
	 */
	public function invalid() {
		return $this->invalid;
	}

	/**
	 * The visitor's IP address
	 *
	 * @return string
	 */
	private static function remote_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		return (string) apply_filters( 'reform_remote_ip', filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '' );
	}
}
