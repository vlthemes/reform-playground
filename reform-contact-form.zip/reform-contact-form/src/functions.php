<?php
/**
 * Functions for themes. Use these, not the classes, which may move.
 *
 * @package VLT\Reform
 */

use VLT\Reform\Admin\Transfer;
use VLT\Reform\Front\Renderer;
use VLT\Reform\Front\StyleManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's markup
 *
 * @param int|string $id   The form's hash (a1b2c3d), or its post ID
 * @param array      $args 'class', 'html_id', 'atts' (values for fields filled from shortcode attributes)
 *
 * @return string
 */
function reform_render( $id, array $args = [] ) {
	return Renderer::render( is_int( $id ) ? $id : (string) $id, $args );
}

/**
 * An icon of templates/icons/ (the theme's reform/icons/ first)
 *
 * @param string $name  File name without .svg
 * @param string $class Class added to the <svg>
 *
 * @return string
 */
function reform_icon( $name, $class = '' ) {
	return StyleManager::icon( $name, $class );
}

/**
 * Import forms, as Settings → Export & import does (a theme's demo setup, for example)
 *
 *     reform_import_forms( get_template_directory() . '/demo/reform-forms.json', true );
 *
 * @param string|array $source  A file path, a URL, JSON or the decoded data: an exported file or one form's code
 * @param bool         $replace Overwrite forms with the same shortcode instead of adding copies
 *
 * @return int[] [ added, replaced ]
 */
function reform_import_forms( $source, $replace = false ) {
	return Transfer::import_source( $source, $replace );
}
