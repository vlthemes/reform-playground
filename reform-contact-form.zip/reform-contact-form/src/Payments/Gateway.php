<?php

namespace VLT\Reform\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A payment provider, through its REST API (no SDK)
 *
 * $payment: 'amount' (float), 'currency' (lowercase), 'description', 'reference' (form ID and field name), 'email'.
 */
interface Gateway {
	/**
	 * Whether its keys are set
	 *
	 * @return bool
	 */
	public function ready();

	/**
	 * Start a payment: what the script needs to show it
	 *
	 * @param array $payment Payment
	 *
	 * @return array|\WP_Error
	 */
	public function start( array $payment );

	/**
	 * Whether a payment was made for this one and is not used yet; nothing changes
	 *
	 * @param string $id      The provider's payment ID
	 * @param array  $payment Payment
	 *
	 * @return bool
	 */
	public function check( $id, array $payment );

	/**
	 * Take the payment and mark it used, so it can't send a second message; called one request at a time per ID
	 *
	 * @param string $id The provider's payment ID
	 *
	 * @return bool
	 */
	public function complete( $id );
}
