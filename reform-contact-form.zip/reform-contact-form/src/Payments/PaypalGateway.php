<?php

namespace VLT\Reform\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PayPal, through Orders v2: the form gets an order for PayPal's buttons, the server checks the visitor approved it
 * for the same amount and captures it (an order is captured once, so it can't send a second message)
 *
 * The public client ID lets anyone make an order in the browser, paid to someone else: an order counts only when it
 * pays the merchant ReForm's own orders pay (kept in reform_paypal_merchant, by keys).
 */
class PaypalGateway implements Gateway {
	// Amounts without cents in PayPal
	const ZERO_DECIMAL = [ 'huf', 'jpy', 'twd' ];

	const MERCHANT = 'reform_paypal_merchant';

	/**
	 * Orders read in this request
	 *
	 * @var array
	 */
	private $orders = [];

	public function ready() {
		$settings = Payments::settings();

		return '' !== (string) ( $settings['paypal_client'] ?? '' ) && '' !== (string) ( $settings['paypal_secret'] ?? '' );
	}

	public function start( array $payment ) {
		$order = $this->request( 'POST', 'v2/checkout/orders', [
			'intent'         => 'CAPTURE',
			'purchase_units' => [
				[
					'amount'      => [ 'currency_code' => strtoupper( $payment['currency'] ), 'value' => self::value( $payment['amount'], $payment['currency'] ) ],
					'description' => mb_substr( $payment['description'], 0, 127 ),
					'custom_id'   => $payment['reference'],
				],
			],
		] );

		if ( is_wp_error( $order ) ) {
			return $order;
		}

		$merchant = (string) ( $order['purchase_units'][0]['payee']['merchant_id'] ?? '' );

		if ( '' !== $merchant && self::merchant() !== $merchant ) {
			update_option( self::MERCHANT, [ self::keys() => $merchant ], false );
		}

		return [ 'order' => (string) ( $order['id'] ?? '' ), 'currency' => strtoupper( $payment['currency'] ) ];
	}

	public function check( $id, array $payment ) {
		if ( !array_key_exists( $id, $this->orders ) ) {
			$this->orders[ $id ] = preg_match( '/^[A-Z0-9]{10,30}$/', $id ) ? $this->request( 'GET', 'v2/checkout/orders/' . rawurlencode( $id ) ) : null;
		}

		$order = $this->orders[ $id ];
		$unit  = is_array( $order ) ? ( $order['purchase_units'][0] ?? [] ) : [];

		return is_array( $order )
			&& 'APPROVED' === ( $order['status'] ?? '' )
			&& self::value( $payment['amount'], $payment['currency'] ) === ( $unit['amount']['value'] ?? '' )
			&& strtoupper( $payment['currency'] ) === ( $unit['amount']['currency_code'] ?? '' )
			&& $payment['reference'] === ( $unit['custom_id'] ?? '' )
			&& '' !== self::merchant()
			&& self::merchant() === ( $unit['payee']['merchant_id'] ?? '' );
	}

	public function complete( $id ) {
		$order = $this->request( 'POST', 'v2/checkout/orders/' . rawurlencode( $id ) . '/capture', (object) [] );

		return is_array( $order ) && 'COMPLETED' === ( $order['status'] ?? '' );
	}

	/**
	 * An amount as PayPal takes it: a string with the currency's decimals
	 *
	 * @param float  $amount   Amount
	 * @param string $currency Currency
	 *
	 * @return string
	 */
	private static function value( $amount, $currency ) {
		return number_format( $amount, in_array( $currency, self::ZERO_DECIMAL, true ) ? 0 : 2, '.', '' );
	}

	/**
	 * The merchant the orders made with these keys pay
	 *
	 * @return string
	 */
	private static function merchant() {
		return (string) ( ( (array) get_option( self::MERCHANT, [] ) )[ self::keys() ] ?? '' );
	}

	/**
	 * The keys and mode in use, as one string
	 *
	 * @return string
	 */
	private static function keys() {
		$settings = Payments::settings();

		return md5( self::api() . ( $settings['paypal_client'] ?? '' ) . ( $settings['paypal_secret'] ?? '' ) );
	}

	/**
	 * Live or sandbox API
	 *
	 * @return string
	 */
	private static function api() {
		return 'sandbox' === ( Payments::settings()['paypal_mode'] ?? 'live' ) ? 'https://api-m.sandbox.paypal.com/' : 'https://api-m.paypal.com/';
	}

	/**
	 * An access token, kept until it expires
	 *
	 * @return string
	 */
	private static function token() {
		$settings = Payments::settings();
		$key      = 'reform_paypal_token_' . self::keys();
		$token    = get_transient( $key );

		if ( is_string( $token ) && '' !== $token ) {
			return $token;
		}

		$response = wp_remote_post( self::api() . 'v1/oauth2/token', [
			'timeout' => 15,
			'headers' => [ 'Authorization' => 'Basic ' . base64_encode( ( $settings['paypal_client'] ?? '' ) . ':' . ( $settings['paypal_secret'] ?? '' ) ) ], // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic auth
			'body'    => [ 'grant_type' => 'client_credentials' ],
		] );
		$result   = is_wp_error( $response ) ? [] : (array) json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$token    = (string) ( $result['access_token'] ?? '' );

		if ( '' !== $token ) {
			set_transient( $key, $token, max( 60, (int) ( $result['expires_in'] ?? 0 ) - 300 ) );
		}

		return $token;
	}

	/**
	 * A call to PayPal's API
	 *
	 * @param string       $method GET or POST
	 * @param string       $path   Path
	 * @param array|object $body   JSON body
	 *
	 * @return array|\WP_Error
	 */
	private function request( $method, $path, $body = null ) {
		$token = self::token();

		if ( '' === $token ) {
			return new \WP_Error( 'reform_paypal', 'PayPal refused the keys' );
		}

		$response = wp_remote_request( self::api() . $path, [
			'method'  => $method,
			'timeout' => 15,
			'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json', 'Prefer' => 'return=representation' ],
			'body'    => null === $body ? null : wp_json_encode( $body ),
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$result = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( !is_array( $result ) || wp_remote_retrieve_response_code( $response ) >= 400 ) {
			return new \WP_Error( 'reform_paypal', (string) ( $result['message'] ?? 'PayPal error' ) );
		}

		return $result;
	}
}
