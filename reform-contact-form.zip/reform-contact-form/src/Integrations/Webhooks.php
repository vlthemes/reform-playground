<?php

namespace VLT\Reform\Integrations;

use VLT\Reform\Entries\Entries;
use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Submission\Conditions;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Webhooks: each message that went through is posted as JSON to the form's addresses (Advanced → Webhooks),
 * without making the visitor wait
 *
 *     { "form": { "id", "title" }, "entry": 123, "fields": { name: value }, "raw": { name: value }, "meta": {…}, "date" }
 */
class Webhooks {
	/**
	 * Init
	 */
	public static function init() {
		// After the entry is saved (10), so its ID goes along
		add_action( 'reform_submitted', [ __CLASS__, 'send' ], 20 );
	}

	/**
	 * Post the message to the form's webhooks
	 *
	 * @param Submission $submission Submission
	 */
	public static function send( Submission $submission ) {
		$urls = (array) ( $submission->form()->config()['settings']['webhooks'] ?? [] );

		if ( !$urls || !in_array( $submission->status(), [ 'success', 'failed' ], true ) || $submission->is_demo() ) {
			return;
		}

		$body = wp_json_encode( self::payload( $submission ) );

		foreach ( $urls as $url ) {
			wp_remote_post( $url, [
				'blocking' => false,
				'timeout'  => 5,
				'headers'  => [ 'Content-Type' => 'application/json' ],
				'body'     => $body,
			] );
		}
	}

	/**
	 * What a webhook receives
	 *
	 * @param Submission $submission Submission
	 *
	 * @return array
	 */
	public static function payload( Submission $submission ) {
		$form   = $submission->form();
		$hidden = Conditions::hidden_fields( $form, $submission->hidden_groups() );
		$fields = [];
		$raw    = [];

		foreach ( $form->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( $type && $type->submits() && !in_array( $name, $hidden, true ) ) {
				$fields[ $name ] = $type->mail_value( $submission->posted( $name ), $field );
				$raw[ $name ]    = $type->mail_value( $submission->posted( $name ), $field, true );
			}
		}

		return (array) apply_filters( 'reform_webhook_payload', [
			'form'   => [ 'id' => $form->id(), 'title' => $form->title() ],
			'entry'  => Entries::last(),
			'fields' => $fields,
			'raw'    => $raw,
			'meta'   => [
				'url'        => $submission->meta( 'url' ),
				'ip'         => $submission->meta( 'ip' ),
				'user_agent' => $submission->meta( 'user_agent' ),
				'user_id'    => $submission->meta( 'user_id' ),
			],
			'date'   => gmdate( 'c', $submission->meta( 'time' ) ),
		], $submission );
	}
}
