<?php

namespace VLT\Reform\Integrations\WPBakery;

use VLT\Reform\Admin\Admin;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;
use VLT\Reform\Front\Shortcode;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPBakery element. It stays the [reform form="…"] shortcode, so pages keep working without WPBakery.
 */
class Integration {
	/**
	 * Init
	 */
	public static function init() {
		add_action( 'vc_before_init', [ __CLASS__, 'map' ] );
		// The front-end editor renders a new element through AJAX, where the styles its form enqueues never reach the page
		add_action( 'vc_load_iframe_jscss', [ __CLASS__, 'enqueue_editor' ] );
		add_filter( 'vc_shortcode_output', [ __CLASS__, 'notice' ], 10, 4 );
	}


	/**
	 * The forms' look in the front-end editor: every form's styles, its fields' and the theme's included
	 */
	public static function enqueue_editor() {
		Renderer::enqueue_all_styles();
	}

	/**
	 * In the front-end editor, a note while no form is picked (the Elementor widget's)
	 *
	 * @param string $output    Element output
	 * @param object $shortcode WPBakery shortcode object
	 * @param array  $atts      Attributes
	 * @param string $tag       Shortcode
	 *
	 * @return string
	 */
	public static function notice( $output, $shortcode, $atts, $tag ) {
		if ( Shortcode::TAG !== $tag || !function_exists( 'vc_is_page_editable' ) || !vc_is_page_editable() || !empty( $atts['form'] ) ) {
			return $output;
		}

		return '<p class="reform-missing">' . esc_html__( 'Choose a form in the element\'s settings.', 'reform-contact-form' ) . '</p>';
	}

	/**
	 * The element
	 */
	public static function map() {
		// A field of text only, like Elementor's RAW_HTML: no input, so nothing is saved in the shortcode
		vc_add_shortcode_param( 'reform_note', static fn( $settings ) => '<div class="vc_description">' . wp_kses_post( $settings['text'] ?? '' ) . '</div>' );

		vc_map( [
			'name'        => __( 'ReForm Contact Form', 'reform-contact-form' ),
			'base'        => Shortcode::TAG,
			'description' => __( 'A form made with ReForm.', 'reform-contact-form' ),
			'category'    => __( 'Content', 'reform-contact-form' ),
			'icon'        => REFORM_URL . 'assets/icons/block.svg',
			'params'      => [
				[
					'type'        => 'dropdown',
					'heading'     => __( 'Form', 'reform-contact-form' ),
					// Not "id": builders often use that name for the element itself, and a page saved [reform] without it
					'param_name'  => 'form',
					'value'       => self::forms(),
					'admin_label' => true,
				],
				[
					'type'        => 'textfield',
					'heading'     => __( 'CSS classes', 'reform-contact-form' ),
					'param_name'  => 'class',
					'description' => __( 'Added to the form\'s wrapper, separated by spaces.', 'reform-contact-form' ),
				],
				[
					'type'       => 'reform_note',
					'param_name' => 'note',
					'text'       => sprintf(
						/* translators: %s: link to the forms list */
						__( 'Fields, mails and messages are set in %s.', 'reform-contact-form' ),
						'<a href="' . esc_url( Admin::url() ) . '" target="_blank">' . esc_html__( 'Contact Form → Contact Forms', 'reform-contact-form' ) . '</a>'
					),
				],
			],
		] );
	}

	/**
	 * Published forms for the dropdown
	 *
	 * @return array [ title => id ] (WPBakery's order)
	 */
	private static function forms() {
		// WPBakery takes them the other way round: label => value
		return [ __( 'Choose a form', 'reform-contact-form' ) => '' ] + array_flip( Form::choices() );
	}
}
