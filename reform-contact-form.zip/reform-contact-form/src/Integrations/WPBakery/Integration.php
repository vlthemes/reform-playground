<?php

namespace VLT\Reform\Integrations\WPBakery;

use VLT\Reform\Admin\Admin;
use VLT\Reform\Core\Assets;
use VLT\Reform\Core\PostType;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Shortcode;
use VLT\Reform\Front\StyleManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPBakery element. It stays the [reform] shortcode, so pages keep working without WPBakery.
 */
class Integration {
	/**
	 * Init
	 */
	public static function init() {
		add_action( 'vc_before_init', [ __CLASS__, 'map' ] );
		// The front-end editor renders a new element through AJAX, where the styles its form enqueues never reach the page
		add_action( 'vc_load_iframe_jscss', [ __CLASS__, 'enqueue_editor' ] );
		add_filter( 'vc_shortcode_output', [ __CLASS__, 'notice' ], 10, 4 );
	}

	/**
	 * The forms' look in the front-end editor
	 */
	public static function enqueue_editor() {
		Assets::enqueue( 'reform' );
		StyleManager::enqueue( 'form/default', 'form' );
	}

	/**
	 * In the front-end editor, a note while no form is picked (the Elementor widget's)
	 *
	 * @param string $output    Element output
	 * @param object $shortcode WPBakery shortcode object
	 * @param array  $atts      Attributes
	 * @param string $tag       Shortcode
	 *
	 * @return string
	 */
	public static function notice( $output, $shortcode, $atts, $tag ) {
		if ( Shortcode::TAG !== $tag || !function_exists( 'vc_is_page_editable' ) || !vc_is_page_editable() || !empty( $atts['id'] ) ) {
			return $output;
		}

		return '<p class="reform-missing">' . esc_html__( 'Choose a form in the element\'s settings.', 'reform-contact-form' ) . '</p>';
	}

	/**
	 * The element
	 */
	public static function map() {
		// A field of text only, like Elementor's RAW_HTML: no input, so nothing is saved in the shortcode
		vc_add_shortcode_param( 'reform_note', static fn( $settings ) => '<div class="vc_description">' . wp_kses_post( $settings['text'] ?? '' ) . '</div>' );

		vc_map( [
			'name'        => __( 'Contact Form', 'reform-contact-form' ),
			'base'        => Shortcode::TAG,
			'description' => __( 'A form made with Reform.', 'reform-contact-form' ),
			'category'    => __( 'Content', 'reform-contact-form' ),
			'icon'        => REFORM_URL . 'assets/icons/logo.svg',
			'params'      => [
				[
					'type'        => 'dropdown',
					'heading'     => __( 'Form', 'reform-contact-form' ),
					'param_name'  => 'id',
					'value'       => self::forms(),
					'admin_label' => true,
				],
				[
					'type'        => 'textfield',
					'heading'     => __( 'CSS classes', 'reform-contact-form' ),
					'param_name'  => 'class',
					'description' => __( 'Added to the form\'s wrapper, separated by spaces.', 'reform-contact-form' ),
				],
				[
					'type'       => 'reform_note',
					'param_name' => 'note',
					'text'       => sprintf(
						/* translators: %s: link to the forms list */
						__( 'Fields, mails and messages are set in %s.', 'reform-contact-form' ),
						'<a href="' . esc_url( Admin::url() ) . '" target="_blank">' . esc_html__( 'Contact Form → Contact Forms', 'reform-contact-form' ) . '</a>'
					),
				],
			],
		] );
	}

	/**
	 * Published forms for the dropdown
	 *
	 * @return array [ title => id ] (WPBakery's order)
	 */
	private static function forms() {
		$forms = [ __( 'Choose a form', 'reform-contact-form' ) => '' ];
		$posts = get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );

		foreach ( $posts as $post ) {
			// Same titles would overwrite each other as keys
			$hash = Form::hash_of( $post->ID );

			$forms[ ( $post->post_title ?: __( '(no title)', 'reform-contact-form' ) ) . ' (' . $hash . ')' ] = $hash;
		}

		return $forms;
	}
}
