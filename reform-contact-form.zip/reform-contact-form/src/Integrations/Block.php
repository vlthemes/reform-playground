<?php

namespace VLT\Reform\Integrations;

use VLT\Reform\Admin\Admin;
use VLT\Reform\Core\Assets;
use VLT\Reform\Core\PostType;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The ReForm Contact Form block: a saved form, rendered as its shortcode on the site; the editor shows which one
 *
 *     reform/form   { id }
 */
class Block {
	const NAME = 'reform/form';

	/**
	 * Init
	 */
	public static function init() {
		self::register();
		add_action( 'enqueue_block_editor_assets', [ __CLASS__, 'enqueue_editor' ] );
	}

	/**
	 * Register the block
	 */
	public static function register() {
		register_block_type( self::NAME, [
			'api_version'     => 3,
			'title'           => __( 'ReForm Contact Form', 'reform-contact-form' ),
			'description'     => __( 'A form made with ReForm.', 'reform-contact-form' ),
			'category'        => 'widgets',
			'keywords'        => [ 'form', 'contact', 'reform', 'email' ],
			// The hash finds the form after an export and import; the post ID is for the editor's links
			'attributes'      => [
				'id'   => [ 'type' => 'integer', 'default' => 0 ],
				'hash' => [ 'type' => 'string', 'default' => '' ],
			],
			'supports'        => [
				'html'  => false,
				'align' => [ 'wide', 'full' ],
			],
			'render_callback' => [ __CLASS__, 'render' ],
		] );
	}

	/**
	 * The block's markup, in the block wrapper (alignment, the block's own classes)
	 *
	 * @param array $attributes Block attributes
	 *
	 * @return string
	 */
	public static function render( $attributes ) {
		$html = Renderer::render( (string) ( $attributes['hash'] ?? '' ) ?: (int) ( $attributes['id'] ?? 0 ) );

		return '' === $html ? '' : '<div ' . get_block_wrapper_attributes() . '>' . $html . '</div>';
	}

	/**
	 * The editor script
	 */
	public static function enqueue_editor() {
		Assets::enqueue( 'reform-blocks' );
	}

	/**
	 * What the editor script reads (window.reformBlocks)
	 *
	 * @return array
	 */
	public static function script_data() {
		$forms = get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );

		return [
			'forms'   => array_map( static fn( $post ) => [ 'id' => $post->ID, 'hash' => Form::hash_of( $post->ID ), 'title' => $post->post_title ?: '#' . $post->ID ], $forms ),
			'editUrl' => admin_url( 'admin.php?page=' . Admin::PAGE . '&form=' ),
			'newUrl'  => Admin::new_url(),
			'canEdit' => current_user_can( Admin::CAPABILITY ),
			// The ReForm mark, the same as Elementor's and WPBakery's
			'icon'    => Admin::icon( 'block' ),
		];
	}
}
