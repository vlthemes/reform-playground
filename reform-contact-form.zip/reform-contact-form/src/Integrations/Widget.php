<?php

namespace VLT\Reform\Integrations;

use VLT\Reform\Core\PostType;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The classic "Contact Form" widget, for sidebars of classic themes. The block widgets screen has the
 * Contact Form block instead, so this one is hidden from its legacy widget list.
 */
class Widget extends \WP_Widget {
	/**
	 * Init
	 */
	public static function init() {
		add_action( 'widgets_init', static fn() => register_widget( self::class ) );
		add_filter( 'widget_types_to_hide_from_legacy_widget_block', static fn( $types ) => array_merge( (array) $types, [ 'reform_form' ] ) );
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct( 'reform_form', __( 'Contact Form', 'reform-contact-form' ), [
			'description'           => __( 'A form made with ReForm.', 'reform-contact-form' ),
			'customize_selective_refresh' => true,
		] );
	}

	/**
	 * Front end
	 *
	 * @param array $args     Sidebar arguments
	 * @param array $instance Settings
	 */
	public function widget( $args, $instance ) {
		$html = Renderer::render( (string) ( $instance['form'] ?? '' ) );

		if ( '' === $html ) {
			return;
		}

		$title = apply_filters( 'widget_title', (string) ( $instance['title'] ?? '' ), $instance, $this->id_base );

		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- the sidebar's own markup and the form's, escaped as it is built
		echo $args['before_widget'];

		if ( '' !== $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
		}

		echo $html . $args['after_widget'];
		// phpcs:enable
	}

	/**
	 * Settings form
	 *
	 * @param array $instance Settings
	 *
	 * @return string
	 */
	public function form( $instance ) {
		$forms = get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'reform-contact-form' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ?? '' ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'form' ) ); ?>"><?php esc_html_e( 'Form', 'reform-contact-form' ); ?></label>
			<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'form' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'form' ) ); ?>">
				<option value="0"><?php esc_html_e( 'Choose a form', 'reform-contact-form' ); ?></option>
				<?php foreach ( $forms as $form ) : ?>
					<?php $hash = Form::hash_of( $form->ID ); ?>
					<option value="<?php echo esc_attr( $hash ); ?>" <?php selected( in_array( (string) ( $instance['form'] ?? '' ), [ $hash, (string) $form->ID ], true ) ); ?>><?php echo esc_html( $form->post_title ?: '#' . $form->ID ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<?php
		return '';
	}

	/**
	 * Save settings
	 *
	 * @param array $new_instance New settings
	 * @param array $old_instance Old settings
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return [
			'title' => sanitize_text_field( (string) ( $new_instance['title'] ?? '' ) ),
			'form'  => sanitize_key( (string) ( $new_instance['form'] ?? '' ) ),
		];
	}
}
