<?php

namespace VLT\Reform\Integrations;

use VLT\Reform\Admin\Transfer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One Click Demo Import: a demo in ocdi/import_files can carry its forms file (from Settings → Export & import),
 * imported after the content, next to OCDI's own keys:
 *
 *     'import_reform_file_url'   => 'https://…/reform-forms.json',
 *     'local_import_reform_file' => get_template_directory() . '/demo/reform-forms.json',
 *
 * Forms keep their hash, so [reform id="…"] in the demo's pages finds them; a form already here with that hash is
 * replaced (importing the demo again doesn't make copies). Forms in the demo's XML come over without this.
 */
class Ocdi {
	/**
	 * Init
	 */
	public static function init() {
		// Before the theme's own after-import steps, which may read the forms
		add_action( 'ocdi/after_import', [ __CLASS__, 'after_import' ], 5 );
	}

	/**
	 * Import the demo's forms file
	 *
	 * @param array $selected The demo picked in OCDI
	 */
	public static function after_import( $selected ) {
		$source = (string) ( $selected['local_import_reform_file'] ?? '' ) ?: (string) ( $selected['import_reform_file_url'] ?? '' );

		if ( '' !== $source ) {
			Transfer::import_source( $source, true );
		}
	}
}
