<?php

namespace VLT\Reform\Integrations\Elementor;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use VLT\Reform\Admin\Admin;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor widget: a saved Reform form
 */
class FormWidget extends Widget_Base {
	/**
	 * Widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return Integration::WIDGET;
	}

	/**
	 * Widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'ReForm Contact Form', 'reform-contact-form' );
	}

	/**
	 * Widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		// The ReForm mark, drawn by Integration::editor_icon()
		return 'reform-eicon';
	}

	/**
	 * Widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Search keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'form', 'contact', 'reform', 'email' ];
	}

	/**
	 * Styles the widget needs
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return [ 'reform' ];
	}

	/**
	 * Controls
	 */
	protected function register_controls() {
		$this->start_controls_section( 'section_form', [ 'label' => __( 'Form', 'reform-contact-form' ) ] );

		$this->add_control( 'form', [
			'label'   => __( 'Form', 'reform-contact-form' ),
			'type'    => Controls_Manager::SELECT,
			'options' => [ '' => __( 'Choose a form', 'reform-contact-form' ) ] + Form::choices(),
			'default' => '',
		] );

		$this->add_control( 'form_note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => sprintf(
				/* translators: %s: link to the forms list */
				__( 'Fields, mails and messages are set in %s.', 'reform-contact-form' ),
				'<a href="' . esc_url( Admin::url() ) . '" target="_blank">' . esc_html__( 'Contact Form → Contact Forms', 'reform-contact-form' ) . '</a>'
			),
			'content_classes' => 'elementor-descriptor',
		] );

		$this->end_controls_section();
	}

	/**
	 * Output
	 */
	protected function render() {
		$id = (string) $this->get_settings_for_display( 'form' );

		if ( $id ) {
			echo Renderer::render( $id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the form's markup, escaped as it is built
		} elseif ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			echo '<p class="elementor-descriptor">' . esc_html__( 'Choose a form in the widget\'s settings.', 'reform-contact-form' ) . '</p>';
		}
	}
}
