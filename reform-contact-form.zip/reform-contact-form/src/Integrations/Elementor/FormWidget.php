<?php

namespace VLT\Reform\Integrations\Elementor;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use VLT\Reform\Admin\Admin;
use VLT\Reform\Core\PostType;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor widget: a saved Reform form
 */
class FormWidget extends Widget_Base {
	/**
	 * Widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return Integration::WIDGET;
	}

	/**
	 * Widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Contact Form', 'reform-contact-form' );
	}

	/**
	 * Widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Search keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'form', 'contact', 'reform', 'email' ];
	}

	/**
	 * Styles the widget needs
	 *
	 * @return array
	 */
	public function get_style_depends() {
		return [ 'reform' ];
	}

	/**
	 * Controls
	 */
	protected function register_controls() {
		$forms = get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );

		$this->start_controls_section( 'section_form', [ 'label' => __( 'Form', 'reform-contact-form' ) ] );

		$this->add_control( 'form', [
			'label'   => __( 'Form', 'reform-contact-form' ),
			'type'    => Controls_Manager::SELECT,
			// Keyed by the form's hash, which survives export and import
			'options' => [ '' => __( 'Choose a form', 'reform-contact-form' ) ] + array_combine( array_map( static fn( $post ) => Form::hash_of( $post->ID ), $forms ), wp_list_pluck( $forms, 'post_title' ) ),
			'default' => '',
		] );

		$this->add_control( 'form_note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => sprintf(
				/* translators: %s: link to the forms list */
				__( 'Fields, mails and messages are set in %s.', 'reform-contact-form' ),
				'<a href="' . esc_url( Admin::url() ) . '" target="_blank">' . esc_html__( 'Contact Form → Contact Forms', 'reform-contact-form' ) . '</a>'
			),
			'content_classes' => 'elementor-descriptor',
		] );

		$this->end_controls_section();
	}

	/**
	 * Output
	 */
	protected function render() {
		$id = (string) $this->get_settings_for_display( 'form' );

		if ( $id ) {
			echo Renderer::render( $id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the form's markup, escaped as it is built
		} elseif ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			echo '<p class="elementor-descriptor">' . esc_html__( 'Choose a form in the widget\'s settings.', 'reform-contact-form' ) . '</p>';
		}
	}
}
