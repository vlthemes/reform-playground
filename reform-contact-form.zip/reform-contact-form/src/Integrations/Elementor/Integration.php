<?php

namespace VLT\Reform\Integrations\Elementor;

use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor: the Contact Form widget, loaded only when Elementor registers its widgets
 */
class Integration {
	// The widget's name (FormWidget), also what is looked for in a page's Elementor data
	const WIDGET = 'reform-form';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		// The editor renders widgets through AJAX, where the styles a form enqueues never reach the page
		add_action( 'elementor/preview/enqueue_styles', [ __CLASS__, 'enqueue_preview' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ __CLASS__, 'editor_icon' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_early' ], 20 );
	}

	/**
	 * Register the widget
	 *
	 * @param \Elementor\Widgets_Manager $widgets Widgets manager
	 */
	public static function register_widget( $widgets ) {
		$widgets->register( new FormWidget() );
	}

	/**
	 * The widget's icon in Elementor's panel: the same ReForm mark as the block and the WPBakery element
	 */
	public static function editor_icon() {
		wp_add_inline_style( 'elementor-editor', '.reform-eicon{display:inline-block;width:1em;height:1em;background:url("' . esc_url( REFORM_URL . 'assets/icons/block.svg' ) . '") center/contain no-repeat}' );
	}

	/**
	 * The forms' look in the editor preview: every form's styles, its fields' and the theme's included
	 */
	public static function enqueue_preview() {
		Renderer::enqueue_all_styles();
	}

	/**
	 * Assets of the forms the page's widgets show, in <head> rather than late in the footer
	 */
	public static function enqueue_early() {
		$data = is_singular() ? get_post_meta( get_queried_object_id(), '_elementor_data', true ) : '';

		if ( !is_string( $data ) || false === strpos( $data, '"' . self::WIDGET . '"' ) ) {
			return;
		}

		foreach ( array_unique( self::forms( (array) json_decode( $data, true ) ) ) as $id ) {
			$form = Form::find( $id );

			if ( $form ) {
				Renderer::enqueue( $form );
			}
		}
	}

	/**
	 * Forms of the widgets in Elementor elements, nested ones included
	 *
	 * @param array $elements Elementor elements
	 *
	 * @return string[]
	 */
	private static function forms( array $elements ) {
		$forms = [];

		foreach ( $elements as $element ) {
			if ( self::WIDGET === ( $element['widgetType'] ?? '' ) && !empty( $element['settings']['form'] ) ) {
				$forms[] = (string) $element['settings']['form'];
			}

			if ( !empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$forms = array_merge( $forms, self::forms( $element['elements'] ) );
			}
		}

		return $forms;
	}
}
