<?php

namespace VLT\Reform\Entries;

use VLT\Reform\Admin\Settings;
use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Submission\Conditions;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Entries: a copy of each message, kept in the admin
 *
 * A reform_entry post per message: post_parent the form, post_content its values as text (searchable),
 * _reform_data the values by field, _reform_meta the visit (ip, user agent, page, user), _reform_unread until
 * opened. Saved even when the mail fails, so no message is lost.
 */
class Entries {
	const POST_TYPE = 'reform_entry';

	const CRON = 'reform_entries_cleanup';

	/**
	 * The entry saved on this request, for the webhooks
	 *
	 * @var int
	 */
	private static $last = 0;

	/**
	 * Init
	 */
	public static function init() {
		register_post_type( self::POST_TYPE, [
			'labels'          => [
				'name'               => __( 'Entries', 'reform-contact-form' ),
				'singular_name'      => __( 'Entry', 'reform-contact-form' ),
				'search_items'       => __( 'Search Entries', 'reform-contact-form' ),
				'not_found'          => __( 'No entries yet. Messages sent with your forms show up here.', 'reform-contact-form' ),
				'not_found_in_trash' => __( 'No entries in the trash.', 'reform-contact-form' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => false,
			'show_in_rest'    => false,
			'rewrite'         => false,
			'query_var'       => false,
			// Visitors' messages stay out of Tools → Export, and so out of demo content
			'can_export'      => false,
			'capability_type' => 'page',
			'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
			'map_meta_cap'    => true,
			'supports'        => [ 'title' ],
		] );

		add_action( 'reform_submitted', [ __CLASS__, 'save' ] );
		add_action( self::CRON, [ __CLASS__, 'cleanup' ] );
		add_filter( 'wp_privacy_personal_data_exporters', [ __CLASS__, 'exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers', [ __CLASS__, 'eraser' ] );
		add_action( 'admin_init', [ __CLASS__, 'privacy_policy' ] );

		if ( !wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON );
		}
	}

	/**
	 * The visitor's IP as Settings → Entries says to keep it: whole, shortened or not at all
	 *
	 * @param string $ip IP address
	 *
	 * @return string
	 */
	public static function stored_ip( $ip ) {
		$keep = Settings::get( 'entries' )['visitor_ip'] ?? 'short';

		if ( '' === $ip || 'none' === $keep ) {
			return '';
		}

		return 'full' === $keep ? $ip : wp_privacy_anonymize_ip( $ip );
	}

	/**
	 * The visitor's browser, unless Settings → Entries says not to keep it
	 *
	 * @param string $agent User agent
	 *
	 * @return string
	 */
	public static function stored_agent( $agent ) {
		return 'none' === ( Settings::get( 'entries' )['visitor_ip'] ?? 'short' ) ? '' : $agent;
	}

	/**
	 * Suggested text for the site's privacy policy (Settings → Privacy → Policy Guide)
	 */
	public static function privacy_policy() {
		if ( !function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$paragraphs = [
			__( 'When you send a message with a contact form on this site, we receive what you enter in it, such as your name, email address and message, and any file you attach.', 'reform-contact-form' ),
			__( 'The message is emailed to us and may be saved on this site so we can answer it. With it we may keep the page you sent it from, your browser and your IP address, which is usually shortened. Saved messages are deleted after a set time or when you ask us to.', 'reform-contact-form' ),
			__( 'To stop spam, the form may check your message with a service such as Akismet, or show a check from Cloudflare Turnstile, hCaptcha or Google reCAPTCHA, which then receive data about your visit under their own privacy policies.', 'reform-contact-form' ),
			__( 'You can ask for a copy of the messages you sent us, or for them to be deleted.', 'reform-contact-form' ),
		];

		wp_add_privacy_policy_content( 'ReForm', '<p class="privacy-policy-tutorial">' . esc_html__( 'Suggested text. Change it to match how your forms are set up: what they ask, where mails go, how long entries are kept and which spam services you use.', 'reform-contact-form' ) . '</p><p>' . implode( '</p><p>', array_map( 'esc_html', $paragraphs ) ) . '</p>' );
	}

	/**
	 * Save a submission that went through (sent, or its mail failed)
	 *
	 * @param Submission $submission Submission
	 */
	public static function save( Submission $submission ) {
		$form = $submission->form();

		if ( !in_array( $submission->status(), [ 'success', 'failed' ], true ) || $submission->is_demo() || empty( $form->config()['settings']['store_entries'] ) ) {
			return;
		}

		$hidden = Conditions::hidden_fields( $form, $submission->hidden_groups() );
		$data   = [];

		foreach ( $form->fields() as $name => $field ) {
			$type = FieldRegistry::get( $field['type'] );

			if ( !$type || !$type->submits() || in_array( $name, $hidden, true ) ) {
				continue;
			}

			$data[ $name ] = [
				'type'  => $field['type'],
				'value' => $type->mail_value( $submission->posted( $name ), $field ),
			];
		}

		$data = (array) apply_filters( 'reform_entry_data', $data, $submission );
		$text = implode( "\n", array_map( static fn( $name, $item ) => $name . ': ' . $item['value'], array_keys( $data ), $data ) );

		$id = wp_insert_post( wp_slash( [
			'post_type'    => self::POST_TYPE,
			'post_status'  => 'publish',
			'post_parent'  => $form->id(),
			'post_title'   => self::title( $data ) ?: $form->title(),
			'post_content' => $text,
		] ) );

		if ( !$id || is_wp_error( $id ) ) {
			return;
		}

		update_post_meta( $id, '_reform_data', wp_slash( wp_json_encode( $data ) ) );
		update_post_meta( $id, '_reform_meta', wp_slash( wp_json_encode( [
			'ip'         => self::stored_ip( (string) $submission->meta( 'ip' ) ),
			'user_agent' => self::stored_agent( (string) $submission->meta( 'user_agent' ) ),
			'url'        => $submission->meta( 'url' ),
			'post_id'    => $submission->meta( 'post_id' ),
			'user_id'    => $submission->meta( 'user_id' ),
		] ) ) );
		update_post_meta( $id, '_reform_unread', 1 );

		self::$last = (int) $id;

		if ( 'failed' === $submission->status() ) {
			update_post_meta( $id, '_reform_mail_failed', 1 );
		}

		wp_cache_delete( 'unread', 'reform' );

		do_action( 'reform_entry_saved', $id, $submission );
	}

	/**
	 * The entry saved on this request (0 = none)
	 *
	 * @return int
	 */
	public static function last() {
		return self::$last;
	}

	/**
	 * An entry's values by field
	 *
	 * @param int $id Entry ID
	 *
	 * @return array [ name => [ 'type', 'value' ] ]
	 */
	public static function data( $id ) {
		$data = json_decode( (string) get_post_meta( $id, '_reform_data', true ), true );

		return is_array( $data ) ? $data : [];
	}

	/**
	 * An entry's visit: ip, user_agent, url, post_id, user_id
	 *
	 * @param int $id Entry ID
	 *
	 * @return array
	 */
	public static function meta( $id ) {
		$meta = json_decode( (string) get_post_meta( $id, '_reform_meta', true ), true );

		return ( is_array( $meta ) ? $meta : [] ) + [ 'ip' => '', 'user_agent' => '', 'url' => '', 'post_id' => 0, 'user_id' => 0 ];
	}

	/**
	 * The first email address among the values
	 *
	 * @param array $data Values
	 *
	 * @return string
	 */
	public static function email( array $data ) {
		foreach ( $data as $item ) {
			if ( 'email' === $item['type'] && is_email( $item['value'] ) ) {
				return $item['value'];
			}
		}

		return '';
	}

	/**
	 * How many entries are unread
	 *
	 * @return int
	 */
	public static function unread() {
		$count = wp_cache_get( 'unread', 'reform' );

		if ( false === $count ) {
			$query = new \WP_Query( [
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_reform_unread', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- a flag on few posts
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			] );
			$count = (int) $query->found_posts;

			wp_cache_set( 'unread', $count, 'reform' );
		}

		return (int) $count;
	}

	/**
	 * Mark an entry read
	 *
	 * @param int $id Entry ID
	 */
	public static function mark_read( $id ) {
		if ( delete_post_meta( $id, '_reform_unread' ) ) {
			wp_cache_delete( 'unread', 'reform' );
		}
	}

	/**
	 * Delete entries older than Settings → Entries → Keep entries
	 */
	public static function cleanup() {
		$days = (int) ( Settings::get( 'entries' )['retention'] ?? 0 );

		if ( $days < 1 ) {
			return;
		}

		$old = get_posts( [
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'any',
			'posts_per_page' => 200,
			'fields'         => 'ids',
			'date_query'     => [ [ 'before' => $days . ' days ago' ] ],
		] );

		foreach ( $old as $id ) {
			wp_delete_post( $id, true );
		}
	}

	/**
	 * Tools → Export Personal Data
	 *
	 * @param array $exporters Exporters
	 *
	 * @return array
	 */
	public static function exporter( array $exporters ) {
		$exporters['reform-contact-form'] = [
			'exporter_friendly_name' => __( 'ReForm entries', 'reform-contact-form' ),
			'callback'               => static function ( $email, $page = 1 ) {
				$items = [];

				foreach ( self::by_email( $email, $page ) as $post ) {
					$values = [];

					foreach ( self::data( $post->ID ) as $name => $item ) {
						$values[] = [ 'name' => $name, 'value' => $item['value'] ];
					}

					$items[] = [
						'group_id'    => 'reform-entries',
						'group_label' => __( 'Contact form entries', 'reform-contact-form' ),
						'item_id'     => 'reform-entry-' . $post->ID,
						'data'        => $values,
					];
				}

				return [ 'data' => $items, 'done' => count( $items ) < 50 ];
			},
		];

		return $exporters;
	}

	/**
	 * Tools → Erase Personal Data
	 *
	 * @param array $erasers Erasers
	 *
	 * @return array
	 */
	public static function eraser( array $erasers ) {
		$erasers['reform-contact-form'] = [
			'eraser_friendly_name' => __( 'ReForm entries', 'reform-contact-form' ),
			'callback'             => static function ( $email, $page = 1 ) {
				$posts = self::by_email( $email, 1 );

				foreach ( $posts as $post ) {
					wp_delete_post( $post->ID, true );
				}

				return [ 'items_removed' => count( $posts ) > 0, 'items_retained' => false, 'messages' => [], 'done' => count( $posts ) < 50 ];
			},
		];

		return $erasers;
	}

	/**
	 * Entries that hold an email address
	 *
	 * @param string $email Address
	 * @param int    $page  Page of 50
	 *
	 * @return \WP_Post[]
	 */
	private static function by_email( $email, $page ) {
		if ( !is_email( $email ) ) {
			return [];
		}

		return get_posts( [
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'any',
			'posts_per_page' => 50,
			'paged'          => max( 1, (int) $page ),
			's'              => $email,
		] );
	}

	/**
	 * A title from the values: the first line of text that isn't an address
	 *
	 * @param array $data Values
	 *
	 * @return string
	 */
	private static function title( array $data ) {
		foreach ( $data as $item ) {
			if ( in_array( $item['type'], [ 'text', 'textarea' ], true ) && '' !== trim( $item['value'] ) ) {
				return wp_trim_words( $item['value'], 12, '…' );
			}
		}

		return '';
	}
}
