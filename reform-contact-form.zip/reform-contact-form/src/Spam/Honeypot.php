<?php

namespace VLT\Reform\Spam;

use VLT\Reform\Forms\Form;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A text field people never see; bots that fill every field fill it too
 */
class Honeypot {
	const NAME = 'reform_website';

	/**
	 * The field, out of sight and out of the tab order
	 *
	 * @param string $html Form markup
	 * @param Form   $form Form
	 *
	 * @return string
	 */
	public static function html( $html, Form $form ) {
		if ( !self::on( $form ) ) {
			return $html;
		}

		return $html . sprintf(
			'<div class="reform__hp" aria-hidden="true"><label>%s <input type="text" name="%s" value="" tabindex="-1" autocomplete="off"></label></div>',
			esc_html__( 'Leave this field empty', 'reform-contact-form' ),
			esc_attr( self::NAME )
		);
	}

	/**
	 * Whether the field was filled
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		return self::on( $submission->form() ) && '' !== trim( (string) $submission->raw( self::NAME ) );
	}

	/**
	 * Whether the honeypot is on
	 *
	 * @param Form $form Form
	 *
	 * @return bool
	 */
	private static function on( Form $form ) {
		return !empty( Spam::settings()['honeypot'] ) && Spam::enabled( $form );
	}
}
