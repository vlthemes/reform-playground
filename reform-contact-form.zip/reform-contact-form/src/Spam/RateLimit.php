<?php

namespace VLT\Reform\Spam;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * At most N submissions per visitor (IP address) in 10 minutes
 */
class RateLimit {
	const WINDOW = 10 * MINUTE_IN_SECONDS;

	/**
	 * Count this submission; spam once over the limit
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		$limit = (int) ( Spam::settings()['rate_limit'] ?? 0 );
		$ip    = (string) $submission->meta( 'ip' );

		if ( $limit < 1 || '' === $ip || !Spam::enabled( $submission->form() ) ) {
			return false;
		}

		$key  = 'reform_rate_' . md5( $ip );
		$rate = get_transient( $key );
		$now  = time();

		// The window runs from the first message: tries made while blocked don't push it back
		if ( !is_array( $rate ) || $now - (int) ( $rate['start'] ?? 0 ) >= self::WINDOW ) {
			$rate = [ 'start' => $now, 'count' => 0 ];
		}

		$rate['count']++;

		set_transient( $key, $rate, max( 1, $rate['start'] + self::WINDOW - $now ) );

		return $rate['count'] > $limit;
	}
}
