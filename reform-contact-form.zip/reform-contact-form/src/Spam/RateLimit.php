<?php

namespace VLT\Reform\Spam;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * At most N submissions per visitor (IP address) in 10 minutes
 */
class RateLimit {
	const WINDOW = 10 * MINUTE_IN_SECONDS;

	/**
	 * Count this submission; spam once over the limit
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		$limit = (int) ( Spam::settings()['rate_limit'] ?? 0 );
		$ip    = (string) $submission->meta( 'ip' );

		if ( $limit < 1 || '' === $ip || !Spam::enabled( $submission->form() ) ) {
			return false;
		}

		$key   = 'reform_rate_' . md5( $ip );
		$count = (int) get_transient( $key ) + 1;

		set_transient( $key, $count, self::WINDOW );

		return $count > $limit;
	}
}
