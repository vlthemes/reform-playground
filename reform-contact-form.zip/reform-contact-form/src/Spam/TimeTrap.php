<?php

namespace VLT\Reform\Spam;

use VLT\Reform\Forms\Form;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * People take a few seconds to fill a form, bots don't: the page carries the time it was made (signed), and a
 * form sent sooner than the minimum is spam. A cached page only makes the time older, never too recent.
 */
class TimeTrap {
	const NAME = '_reform_time';

	/**
	 * The signed time among the form's hidden inputs
	 *
	 * @param array $inputs Hidden inputs
	 * @param Form  $form   Form
	 *
	 * @return array
	 */
	public static function input( array $inputs, Form $form ) {
		if ( self::seconds( $form ) ) {
			$time                 = time();
			$inputs[ self::NAME ] = $time . '.' . self::sign( $time );
		}

		return $inputs;
	}

	/**
	 * Whether the form came back too fast, or without a valid time
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		$seconds = self::seconds( $submission->form() );

		if ( !$seconds ) {
			return false;
		}

		$parts = explode( '.', (string) $submission->raw( self::NAME ), 2 );
		$time  = (int) $parts[0];

		if ( 2 !== count( $parts ) || !hash_equals( self::sign( $time ), $parts[1] ) ) {
			return true;
		}

		return time() - $time < $seconds;
	}

	/**
	 * Least seconds between the page and the submission (0 = off)
	 *
	 * @param Form $form Form
	 *
	 * @return int
	 */
	private static function seconds( Form $form ) {
		return Spam::enabled( $form ) ? max( 0, (int) ( Spam::settings()['min_time'] ?? 0 ) ) : 0;
	}

	/**
	 * Signature of a time
	 *
	 * @param int $time Unix time
	 *
	 * @return string
	 */
	private static function sign( $time ) {
		return substr( wp_hash( 'reform-time|' . (int) $time ), 0, 16 );
	}
}
