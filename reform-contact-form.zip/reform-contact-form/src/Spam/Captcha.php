<?php

namespace VLT\Reform\Spam;

use VLT\Reform\Core\Assets;
use VLT\Reform\Forms\Form;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Captchas, set up once in Settings → Spam: Cloudflare Turnstile, hCaptcha and Google reCAPTCHA v3, any mix, on every
 * form unless a form skips them (Advanced). A message must pass each. Placed where [[captcha]] is, else before the
 * first submit button: the Submit field, or a <button> or <input type="submit"> in the markup; with none, at the end.
 */
class Captcha {
	const PROVIDERS = [
		'turnstile' => [
			'label'    => 'Cloudflare Turnstile',
			'script'   => 'https://challenges.cloudflare.com/turnstile/v0/api.js', // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- the captcha service's own script and API (External services in readme.txt)
			'response' => 'cf-turnstile-response',
			'verify'   => 'https://challenges.cloudflare.com/turnstile/v0/siteverify', // phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- the captcha service's own script and API (External services in readme.txt)
			// It checks the secret before the answer, so a made-up answer tells whether the secret is right
			'check'    => true,
		],
		'hcaptcha'  => [
			'label'    => 'hCaptcha',
			'script'   => 'https://js.hcaptcha.com/1/api.js',
			'response' => 'h-captcha-response',
			'verify'   => 'https://api.hcaptcha.com/siteverify',
		],
		'recaptcha' => [
			'label'    => 'Google reCAPTCHA v3',
			'script'   => 'https://www.google.com/recaptcha/api.js',
			'response' => 'g-recaptcha-response',
			'verify'   => 'https://www.google.com/recaptcha/api/siteverify',
		],
	];

	// What is known of each secret: [ id => [ 'state' => ok|bad|unreachable|waiting, 'key' => hash of the secret ] ],
	// from a check when the keys are saved (Turnstile) or from the last real answer checked (all of them)
	const STATUS = 'reform_captcha_status';

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'reform_token_captcha', [ __CLASS__, 'html' ], 10, 2 );
		add_filter( 'reform_assets', [ __CLASS__, 'assets' ] );
		// Keys saved in Settings → Spam: ask each provider whether it knows the secret
		add_action( 'update_option_' . \VLT\Reform\Admin\Settings::OPTION, [ __CLASS__, 'check_keys' ] );
		add_action( 'add_option_' . \VLT\Reform\Admin\Settings::OPTION, [ __CLASS__, 'check_keys' ] );
	}

	/**
	 * Check the secrets that changed since the last check (or whose provider couldn't be reached then); a provider
	 * that can't be asked so waits for its first real answer
	 */
	public static function check_keys() {
		$settings = Spam::settings();
		$status   = (array) get_option( self::STATUS, [] );

		foreach ( array_keys( self::PROVIDERS ) as $id ) {
			$secret = (string) ( $settings[ $id . '_secret' ] ?? '' );

			if ( '' === $secret ) {
				unset( $status[ $id ] );
				continue;
			}

			$hash = md5( $secret );

			if ( ( $status[ $id ]['key'] ?? '' ) !== $hash || 'unreachable' === ( $status[ $id ]['state'] ?? '' ) ) {
				$status[ $id ] = [ 'state' => empty( self::PROVIDERS[ $id ]['check'] ) ? 'waiting' : self::check_secret( $id, $secret ), 'key' => $hash ];
			}
		}

		update_option( self::STATUS, $status, false );
	}

	/**
	 * Whether a provider accepts a secret: a made-up answer is refused either way, the error says which part was wrong
	 *
	 * @param string $id     Provider
	 * @param string $secret Secret key
	 *
	 * @return string ok, bad or unreachable
	 */
	private static function check_secret( $id, $secret ) {
		$response = wp_remote_post( self::PROVIDERS[ $id ]['verify'], [
			'timeout' => 10,
			'body'    => [ 'secret' => $secret, 'response' => 'reform-key-check' ],
		] );
		$result   = is_wp_error( $response ) ? null : json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( !is_array( $result ) ) {
			return 'unreachable';
		}

		return array_intersect( [ 'invalid-input-secret', 'missing-input-secret' ], (array) ( $result['error-codes'] ?? [] ) ) ? 'bad' : 'ok';
	}

	/**
	 * A provider's state for Settings → Spam: [ label, tone ]
	 *
	 * @param string $id Provider
	 *
	 * @return array
	 */
	public static function status( $id ) {
		// The saved values as they are: Spam::settings() builds the settings sections, which ask for this status
		$settings = (array) ( ( (array) get_option( \VLT\Reform\Admin\Settings::OPTION, [] ) )['spam'] ?? [] );
		$site     = !empty( $settings[ $id . '_site' ] );
		$secret   = !empty( $settings[ $id . '_secret' ] );

		if ( !$site && !$secret ) {
			return [ __( 'Not set up', 'reform-contact-form' ), 'muted' ];
		}

		if ( !$site || !$secret ) {
			return [ __( 'Needs both keys', 'reform-contact-form' ), 'warning' ];
		}

		if ( 'off' === ( $settings[ $id . '_use' ] ?? 'all' ) ) {
			return [ __( 'Off', 'reform-contact-form' ), 'muted' ];
		}

		switch ( ( (array) get_option( self::STATUS, [] ) )[ $id ]['state'] ?? '' ) {
			case 'ok':
				return [ __( 'Connected', 'reform-contact-form' ), 'success' ];

			case 'bad':
				return [ __( 'Secret key not accepted: not used', 'reform-contact-form' ), 'danger' ];

			case 'waiting':
				return [ __( 'Waiting for the first message', 'reform-contact-form' ), 'muted' ];

			default:
				return [ __( 'Not checked yet: save to check', 'reform-contact-form' ), 'muted' ];
		}
	}

	/**
	 * The providers with both keys that Settings → Spam uses on every form; one whose secret was refused sits out, or
	 * every message would be turned down (its state in Settings → Spam says why)
	 *
	 * @return array [ id => label ]
	 */
	public static function available() {
		$settings  = Spam::settings();
		$status    = (array) get_option( self::STATUS, [] );
		$available = [];

		foreach ( self::PROVIDERS as $id => $provider ) {
			$secret  = (string) ( $settings[ $id . '_secret' ] ?? '' );
			$refused = 'bad' === ( $status[ $id ]['state'] ?? '' ) && md5( $secret ) === ( $status[ $id ]['key'] ?? '' );

			if ( !empty( $settings[ $id . '_site' ] ) && '' !== $secret && !$refused && 'off' !== ( $settings[ $id . '_use' ] ?? 'all' ) ) {
				$available[ $id ] = $provider['label'];
			}
		}

		return $available;
	}

	/**
	 * A provider's logo (assets/icons/captcha-{id}.svg)
	 *
	 * @param string $id Provider
	 *
	 * @return string SVG
	 */
	public static function logo( $id ) {
		return \VLT\Reform\Admin\Admin::icon( 'captcha-' . $id );
	}

	/**
	 * The providers a form runs: every one Settings → Spam turns on, unless the form skips them
	 *
	 * @param Form $form Form
	 *
	 * @return string[]
	 */
	public static function of( Form $form ) {
		return empty( $form->config()['settings']['captcha_off'] ) && Spam::enabled( $form ) ? array_keys( self::available() ) : [];
	}

	/**
	 * The providers' scripts (reform.js asks reCAPTCHA for a token and resets the widgets after sending)
	 *
	 * @param array $assets Handles
	 *
	 * @return array
	 */
	public static function assets( array $assets ) {
		$settings = Spam::settings();

		foreach ( self::PROVIDERS as $id => $provider ) {
			$url = 'recaptcha' === $id ? add_query_arg( 'render', rawurlencode( (string) ( $settings['recaptcha_site'] ?? '' ) ), $provider['script'] ) : $provider['script'];

			$assets[ 'reform-' . $id ] = [ 'url' => $url, 'version' => null ];
		}

		return $assets;
	}

	/**
	 * The widgets of a form's providers, Turnstile and hCaptcha shown, reCAPTCHA's hidden field
	 *
	 * @param string $html Markup so far
	 * @param Form   $form Form
	 *
	 * @return string
	 */
	public static function html( $html, Form $form ) {
		$settings = Spam::settings();

		foreach ( self::of( $form ) as $id ) {
			$site = (string) $settings[ $id . '_site' ];

			Assets::enqueue( 'reform-' . $id );

			if ( 'recaptcha' === $id ) {
				// Invisible: reform.js asks for a token as the form is sent, and loads the script then if something held it back
				$html .= sprintf( '<input type="hidden" name="g-recaptcha-response" value="" data-reform-captcha="recaptcha" data-sitekey="%s" data-src="%s">', esc_attr( $site ), esc_url( Assets::src( 'reform-recaptcha' ) ) );

				// Google's badge hidden (reform.css, while this line is on the page): its terms ask for this line instead
				if ( 'hide' === ( $settings['recaptcha_badge'] ?? 'show' ) ) {
					$html .= '<span class="reform-recaptcha-note">' . sprintf(
						/* translators: 1: Privacy Policy link, 2: Terms of Service link */
						esc_html__( 'This site is protected by reCAPTCHA and the Google %1$s and %2$s apply.', 'reform-contact-form' ),
						'<a href="https://policies.google.com/privacy" target="_blank" rel="noopener">' . esc_html__( 'Privacy Policy', 'reform-contact-form' ) . '</a>',
						'<a href="https://policies.google.com/terms" target="_blank" rel="noopener">' . esc_html__( 'Terms of Service', 'reform-contact-form' ) . '</a>'
					) . '</span>';
				}

				continue;
			}

			$html .= sprintf(
				'<div class="reform-captcha %s" id="reform-captcha-%s" data-reform-captcha="%s" data-sitekey="%s"></div>',
				'turnstile' === $id ? 'cf-turnstile' : 'h-captcha',
				esc_attr( wp_unique_id() ),
				esc_attr( $id ),
				esc_attr( $site )
			);
		}

		return $html;
	}

	/**
	 * Whether the provider turned the submission down
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		/**
		 * Skip the captchas of a submission (a form sent again once paid: an answer works once)
		 *
		 * @param bool       $skip       Skip
		 * @param Submission $submission Submission
		 */
		if ( apply_filters( 'reform_skip_captcha', false, $submission ) ) {
			return false;
		}

		$settings = Spam::settings();

		// Every provider the form runs must pass
		foreach ( self::of( $submission->form() ) as $id ) {
			$token = (string) $submission->raw( self::PROVIDERS[ $id ]['response'] );

			if ( '' === $token ) {
				return true;
			}

			$response = wp_remote_post( self::PROVIDERS[ $id ]['verify'], [
				'timeout' => 10,
				'body'    => [
					'secret'   => (string) $settings[ $id . '_secret' ],
					'response' => $token,
					'remoteip' => $submission->meta( 'ip' ),
				],
			] );

			// The provider can't be reached: let the message through rather than lose it
			if ( is_wp_error( $response ) ) {
				continue;
			}

			$result = (array) json_decode( (string) wp_remote_retrieve_body( $response ), true );

			self::remember( $id, (string) $settings[ $id . '_secret' ], $result );

			if ( empty( $result['success'] ) ) {
				return true;
			}

			if ( 'recaptcha' === $id && isset( $result['score'] ) && (float) $result['score'] < (float) ( $settings['recaptcha_score'] ?? 0.5 ) ) {
				return true;
			}
		}

		return false;
	}


	/**
	 * What a real answer's check tells of the secret, kept for Settings → Spam (written only when it changes)
	 *
	 * @param string $id     Provider
	 * @param string $secret Secret key
	 * @param array  $result The provider's reply
	 */
	private static function remember( $id, $secret, array $result ) {
		$bad   = (bool) array_intersect( [ 'invalid-input-secret', 'missing-input-secret' ], (array) ( $result['error-codes'] ?? [] ) );
		$state = $bad ? 'bad' : ( !empty( $result['success'] ) ? 'ok' : '' );

		if ( '' === $state ) {
			return;
		}

		$status = (array) get_option( self::STATUS, [] );
		$entry  = [ 'state' => $state, 'key' => md5( $secret ) ];

		if ( ( $status[ $id ] ?? null ) !== $entry ) {
			$status[ $id ] = $entry;
			update_option( self::STATUS, $status, false );
		}
	}

}
