<?php

namespace VLT\Reform\Spam;

use VLT\Reform\Core\Assets;
use VLT\Reform\Forms\Form;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A captcha per form (Advanced → Spam check): Cloudflare Turnstile, hCaptcha or Google reCAPTCHA v3, with the
 * keys of Settings → Spam. Placed where [[captcha]] is, or before the submit button.
 */
class Captcha {
	const PROVIDERS = [
		'turnstile' => [
			'label'    => 'Cloudflare Turnstile',
			'script'   => 'https://challenges.cloudflare.com/turnstile/v0/api.js',
			'response' => 'cf-turnstile-response',
			'verify'   => 'https://challenges.cloudflare.com/turnstile/v0/siteverify',
		],
		'hcaptcha'  => [
			'label'    => 'hCaptcha',
			'script'   => 'https://js.hcaptcha.com/1/api.js',
			'response' => 'h-captcha-response',
			'verify'   => 'https://api.hcaptcha.com/siteverify',
		],
		'recaptcha' => [
			'label'    => 'Google reCAPTCHA v3',
			'script'   => 'https://www.google.com/recaptcha/api.js',
			'response' => 'g-recaptcha-response',
			'verify'   => 'https://www.google.com/recaptcha/api/siteverify',
		],
	];

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'reform_token_captcha', [ __CLASS__, 'html' ], 10, 2 );
		add_filter( 'reform_assets', [ __CLASS__, 'assets' ] );
	}

	/**
	 * The providers whose keys are set
	 *
	 * @return array [ id => label ]
	 */
	public static function available() {
		$settings  = Spam::settings();
		$available = [];

		foreach ( self::PROVIDERS as $id => $provider ) {
			if ( !empty( $settings[ $id . '_site' ] ) && !empty( $settings[ $id . '_secret' ] ) ) {
				$available[ $id ] = $provider['label'];
			}
		}

		return $available;
	}

	/**
	 * A provider's logo (assets/icons/captcha-{id}.svg)
	 *
	 * @param string $id Provider
	 *
	 * @return string SVG
	 */
	public static function logo( $id ) {
		return \VLT\Reform\Admin\Admin::icon( 'captcha-' . $id );
	}

	/**
	 * The provider a form uses, when its keys are set
	 *
	 * @param Form $form Form
	 *
	 * @return string '' = none
	 */
	public static function of( Form $form ) {
		$id = (string) ( $form->config()['settings']['captcha'] ?? '' );

		return isset( self::available()[ $id ] ) && Spam::enabled( $form ) ? $id : '';
	}

	/**
	 * The providers' scripts, and the script that asks reCAPTCHA for a token and resets widgets after sending
	 *
	 * @param array $assets Handles
	 *
	 * @return array
	 */
	public static function assets( array $assets ) {
		$settings = Spam::settings();

		foreach ( self::PROVIDERS as $id => $provider ) {
			$url = 'recaptcha' === $id ? add_query_arg( 'render', rawurlencode( (string) ( $settings['recaptcha_site'] ?? '' ) ), $provider['script'] ) : $provider['script'];

			$assets[ 'reform-' . $id ] = [ 'url' => $url, 'version' => null ];
		}

		$assets['reform-captcha'] = [ 'script' => 'js/captcha.js', 'deps' => [ 'reform' ] ];

		return $assets;
	}

	/**
	 * The widget of a form's provider
	 *
	 * @param string $html Markup so far
	 * @param Form   $form Form
	 *
	 * @return string
	 */
	public static function html( $html, Form $form ) {
		$id = self::of( $form );

		if ( !$id ) {
			return $html;
		}

		$site = (string) Spam::settings()[ $id . '_site' ];

		Assets::enqueue( 'reform-' . $id, 'reform-captcha' );

		if ( 'recaptcha' === $id ) {
			// Invisible: reform.js asks for a token as the form is sent
			return $html . sprintf( '<input type="hidden" name="g-recaptcha-response" value="" data-reform-captcha="recaptcha" data-sitekey="%s">', esc_attr( $site ) );
		}

		return $html . sprintf(
			'<div class="reform-captcha %s" id="reform-captcha-%s" data-reform-captcha="%s" data-sitekey="%s"></div>',
			'turnstile' === $id ? 'cf-turnstile' : 'h-captcha',
			esc_attr( wp_unique_id() ),
			esc_attr( $id ),
			esc_attr( $site )
		);
	}

	/**
	 * Whether the provider turned the submission down
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function is_spam( Submission $submission ) {
		$id = self::of( $submission->form() );

		if ( !$id ) {
			return false;
		}

		$token = (string) $submission->raw( self::PROVIDERS[ $id ]['response'] );

		if ( '' === $token ) {
			return true;
		}

		$settings = Spam::settings();
		$response = wp_remote_post( self::PROVIDERS[ $id ]['verify'], [
			'timeout' => 10,
			'body'    => [
				'secret'   => (string) $settings[ $id . '_secret' ],
				'response' => $token,
				'remoteip' => $submission->meta( 'ip' ),
			],
		] );

		// The provider can't be reached: let the message through rather than lose it
		if ( is_wp_error( $response ) ) {
			return false;
		}

		$result = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( empty( $result['success'] ) ) {
			return true;
		}

		return 'recaptcha' === $id && isset( $result['score'] ) && (float) $result['score'] < (float) ( $settings['recaptcha_score'] ?? 0.5 );
	}
}
