<?php

namespace VLT\Reform\Spam;

use VLT\Reform\Admin\Settings;
use VLT\Reform\Forms\Form;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Spam checks, run on every submission before anything else (reform_spam): the honeypot, the time trap and the
 * rate limit (Settings → Spam), WordPress's Disallowed Comment Keys, the form's captcha, Akismet
 */
class Spam {
	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'reform_spam', [ __CLASS__, 'check' ], 10, 2 );
		add_filter( 'reform_hidden_inputs', [ TimeTrap::class, 'input' ], 10, 2 );
		add_filter( 'reform_form_html', [ Honeypot::class, 'html' ], 10, 2 );
		Captcha::init();
	}

	/**
	 * Settings → Spam
	 *
	 * @return array
	 */
	public static function settings() {
		return Settings::get( 'spam' );
	}

	/**
	 * Whether a submission is spam: the first check that says so wins
	 *
	 * @param bool       $spam       Spam so far
	 * @param Submission $submission Submission
	 *
	 * @return bool
	 */
	public static function check( $spam, Submission $submission ) {
		if ( $spam ) {
			return true;
		}

		foreach ( [ Honeypot::class, TimeTrap::class, Disallowed::class, RateLimit::class, Captcha::class, Akismet::class ] as $check ) {
			if ( $check::is_spam( $submission ) ) {
				do_action( 'reform_spam_caught', $check, $submission );

				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a form is checked at all (a theme can turn the checks off for one)
	 *
	 * @param Form $form Form
	 *
	 * @return bool
	 */
	public static function enabled( Form $form ) {
		return (bool) apply_filters( 'reform_spam_checks', true, $form );
	}
}
