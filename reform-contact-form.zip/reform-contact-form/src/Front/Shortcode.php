<?php

namespace VLT\Reform\Front;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * [reform id="a1b2c3d" class="" html_id=""] (the form's hash; its post ID works too); any other attribute fills the field
 * that reads it
 */
class Shortcode {
	const TAG = 'reform';

	/**
	 * Init
	 */
	public static function init() {
		add_shortcode( self::TAG, [ __CLASS__, 'render' ] );
	}

	/**
	 * Render
	 *
	 * @param array|string $atts Attributes
	 *
	 * @return string
	 */
	public static function render( $atts ) {
		$all  = (array) $atts;
		$atts = shortcode_atts( [
			'id'      => 0,
			'class'   => '',
			'html_id' => '',
		], $all, self::TAG );

		// The other attributes fill fields set to "Fill from: Shortcode attribute"
		return Renderer::render( (string) $atts['id'], [
			'class'   => $atts['class'],
			'html_id' => $atts['html_id'],
			'atts'    => array_diff_key( $all, $atts ),
		] );
	}
}
