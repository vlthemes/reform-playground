<?php

namespace VLT\Reform\Front;

use VLT\Reform\Core\IdList;
use VLT\Reform\Fields\FieldRegistry;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reform templates. Any file in templates/ can be overridden at your-theme/reform/{path}.
 *
 *     form/{style}/          response.php, style.css: the form's look (the built-in one also styles its fields)
 *     fields/{type}/{style}/ field.php (+ style.css): around a field's control; fields/{kind}/{style}/ for every
 *                            type of a kind (input: text, email, url, tel, number, date; choices: checkbox, radio)
 *     mail/ preview/ icons/
 *
 * A new folder in your-theme/reform/form/ or fields/{type|kind}/ is a new style, offered in the editor.
 *
 *     add_filter( 'reform_default_styles', '__return_false' );   // drop the plugin's own look
 *     add_filter( 'reform_exclude_styles', fn( $ids, $kind ) => 'form' === $kind ? [ 'default' ] : $ids, 10, 2 );
 */
class StyleManager {
	// The form style that loads no Reform styles: the theme styles the form
	const THEME = 'theme';

	/**
	 * Child theme, parent theme, plugin
	 *
	 * @return array [ [ path, url ], … ]
	 */
	public static function roots() {
		$relative = 'reform/';
		$roots    = [ [ trailingslashit( get_stylesheet_directory() ) . $relative, trailingslashit( get_stylesheet_directory_uri() ) . $relative ] ];

		if ( get_template_directory() !== get_stylesheet_directory() ) {
			$roots[] = [ trailingslashit( get_template_directory() ) . $relative, trailingslashit( get_template_directory_uri() ) . $relative ];
		}

		$roots[] = [ REFORM_PATH . 'templates/', REFORM_URL . 'templates/' ];

		return $roots;
	}

	/**
	 * Locate a file in the templates tree
	 *
	 * @param string $relative Path, e.g. fields/input/default/field.php
	 *
	 * @return array|null [ path, url ]
	 */
	public static function locate_file( $relative ) {
		// No way out of the tree
		if ( !preg_match( '#^[a-z0-9_-]+(?:/[a-z0-9_-]+)*\.(?:php|css|js|svg)$#', $relative ) ) {
			return null;
		}

		$found = null;

		foreach ( self::roots() as [ $path, $url ] ) {
			if ( is_file( $path . $relative ) ) {
				$found = [ $path . $relative, $url . $relative ];
				break;
			}
		}

		// [ path, url ]
		$found = apply_filters( 'reform_template', $found, $relative );

		return is_array( $found ) && !empty( $found[0] ) && is_file( $found[0] ) ? $found : null;
	}

	/**
	 * Render a template
	 *
	 * @param string $relative Path, e.g. mail/html.php
	 * @param array  $vars     Variables
	 *
	 * @return string
	 */
	public static function render_template( $relative, array $vars ) {
		$template = self::locate_file( $relative );

		if ( !$template ) {
			return '';
		}

		$vars = (array) apply_filters( 'reform_template_vars', $vars, $relative );

		ob_start();

		( static function ( $__template, $__vars ) {
			extract( $__vars, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
			include $__template;
		} )( $template[0], $vars );

		return (string) ob_get_clean();
	}

	/**
	 * An icon of templates/icons/, the theme's copy first
	 *
	 * @param string $name  File name without .svg
	 * @param string $class Class added to the <svg>
	 *
	 * @return string SVG markup, hidden from screen readers ('' when there is no such icon)
	 */
	public static function icon( $name, $class = '' ) {
		static $cache = [];

		$key = $name . '|' . $class;

		if ( !isset( $cache[ $key ] ) ) {
			$file = self::locate_file( 'icons/' . sanitize_key( $name ) . '.svg' );
			$svg  = $file ? trim( (string) file_get_contents( $file[0] ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file
			$svg  = preg_replace( '#^.*?(?=<svg[\s>])#s', '', $svg );

			if ( $svg ) {
				$svg = preg_replace( '#^<svg#', '<svg aria-hidden="true" focusable="false"' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ), $svg );
			}

			$cache[ $key ] = (string) apply_filters( 'reform_icon', $svg, $name, $class );
		}

		return $cache[ $key ];
	}

	/**
	 * The styles offered: form styles, or a field type's
	 *
	 * @param string $kind form or fields
	 * @param string $type Field type (fields)
	 *
	 * @return array [ id => label ]
	 */
	public static function styles( $kind = 'form', $type = '' ) {
		$dirs = [ 'form' ];

		if ( 'fields' === $kind ) {
			$field = FieldRegistry::get( $type );
			$dirs  = $field ? array_unique( [ 'fields/' . $field->type(), 'fields/' . $field->kind() ] ) : [];
		}

		$styles = [];

		foreach ( self::roots() as [ $path ] ) {
			foreach ( $dirs as $dir ) {
				foreach ( (array) glob( $path . $dir . '/*', GLOB_ONLYDIR ) as $folder ) {
					$id = sanitize_key( basename( (string) $folder ) );

					if ( $id ) {
						$styles[ $id ] = 'default' === $id ? __( 'Reform style', 'reform-contact-form' ) : ucwords( str_replace( [ '-', '_' ], ' ', $id ) );
					}
				}
			}
		}

		// A form can leave its whole look to the theme: no Reform styles at all
		if ( 'form' === $kind ) {
			$styles[ self::THEME ] = __( 'Inherit from theme', 'reform-contact-form' );
		}

		// Reform's own first, the theme's look second, then the other styles
		$order = [ 'default' => 0, self::THEME => 1 ];

		uksort( $styles, static fn( $a, $b ) => ( $order[ $a ] ?? 2 ) <=> ( $order[ $b ] ?? 2 ) ?: strcmp( $a, $b ) );

		$styles = (array) apply_filters( 'reform_styles', $styles, $kind, $type );

		return IdList::apply(
			$styles,
			(array) apply_filters( 'reform_include_styles', [], $kind, $type ),
			(array) apply_filters( 'reform_exclude_styles', [], $kind, $type )
		);
	}

	/**
	 * The template of a field: the type's own style, the kind's, then their defaults
	 *
	 * @param string $type  Field type
	 * @param string $style Style
	 *
	 * @return string|null Path relative to the templates tree
	 */
	public static function field_template( $type, $style ) {
		$field = FieldRegistry::get( $type );

		if ( !$field ) {
			return null;
		}

		$style = sanitize_key( $style ) ?: 'default';

		foreach ( array_unique( [ $style, 'default' ] ) as $id ) {
			foreach ( array_unique( [ $field->type(), $field->kind() ] ) as $dir ) {
				$relative = 'fields/' . $dir . '/' . $id . '/field.php';

				if ( self::locate_file( $relative ) ) {
					return $relative;
				}
			}
		}

		return null;
	}

	/**
	 * A file of a form style, the default style's when it has none
	 *
	 * @param string $style Style
	 * @param string $file  File name
	 *
	 * @return string Path relative to the templates tree
	 */
	public static function form_file( $style, $file ) {
		$relative = 'form/' . ( sanitize_key( $style ) ?: 'default' ) . '/' . $file;

		return self::locate_file( $relative ) ? $relative : 'form/default/' . $file;
	}

	/**
	 * Enqueue the style.css (and script.js) of a style folder
	 *
	 * @param string $dir  Folder relative to the templates tree, e.g. form/default
	 * @param string $kind form or fields
	 */
	public static function enqueue( $dir, $kind ) {
		$handle = 'reform-' . str_replace( '/', '-', $dir );
		$style  = self::locate_file( $dir . '/style.css' );
		$script = self::locate_file( $dir . '/script.js' );

		// The plugin's own look can be turned off; a theme's copy always loads
		if ( $style && ( !self::is_plugin_file( $style[0] ) || self::default_styles( $kind, basename( $dir ) ) ) ) {
			wp_enqueue_style( $handle, $style[1], [ 'reform' ], (string) filemtime( $style[0] ) );
		}

		if ( $script ) {
			wp_enqueue_script( $handle, $script[1], [ 'reform' ], (string) filemtime( $script[0] ), [ 'in_footer' => true, 'strategy' => 'defer' ] );
		}
	}

	/**
	 * Whether the plugin's own look loads (reform_default_styles); a theme returns false to style it all itself
	 *
	 * @param string $kind form or fields
	 * @param string $id   Style ID
	 *
	 * @return bool
	 */
	public static function default_styles( $kind, $id = '' ) {
		return (bool) apply_filters( 'reform_default_styles', !defined( 'REFORM_DEFAULT_STYLES' ) || REFORM_DEFAULT_STYLES, $kind, $id );
	}

	/**
	 * Whether a file is the plugin's own, not a theme's copy
	 *
	 * @param string $path File path
	 *
	 * @return bool
	 */
	private static function is_plugin_file( $path ) {
		return 0 === strpos( wp_normalize_path( $path ), wp_normalize_path( REFORM_PATH ) );
	}
}
