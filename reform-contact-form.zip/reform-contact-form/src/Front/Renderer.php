<?php

namespace VLT\Reform\Front;

use VLT\Reform\Core\Assets;
use VLT\Reform\Core\Messages;
use VLT\Reform\Fields\Field;
use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Forms\Form;
use VLT\Reform\Forms\Template;
use VLT\Reform\Submission\Conditions;
use VLT\Reform\Submission\NoScript;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A form's markup: the wrapper, the <form>, each field's wrapper and control, the groups and the response box
 *
 * These carry what the script and the submission need, so no template can lose them; templates are what goes
 * around each control (fields/) and inside the response box (form/{style}/response.php).
 */
class Renderer {
	/**
	 * Forms rendered on this page
	 *
	 * @var int
	 */
	private static $count = 0;

	/**
	 * Forms rendered on this page, for the admin bar
	 *
	 * @var int[]
	 */
	private static $rendered = [];

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'detect' ], 20 );
		// Before the footer scripts print
		add_action( 'wp_footer', [ __CLASS__, 'admin_bar' ], 5 );
	}

	/**
	 * Admin bar menu of the forms this page shows, linked to their editor
	 */
	public static function admin_bar() {
		if ( !self::$rendered || !is_admin_bar_showing() ) {
			return;
		}

		$items = [];

		foreach ( array_unique( self::$rendered ) as $id ) {
			// No link when the user can't edit the form
			$link = get_edit_post_link( $id, 'raw' );

			if ( $link ) {
				$items[] = [
					'title' => get_the_title( $id ) ?: sprintf( '#%d', $id ),
					'url'   => $link,
				];
			}
		}

		if ( !$items ) {
			return;
		}

		Assets::enqueue( 'reform-admin-bar' );
		Assets::data( 'reform-admin-bar', 'reformAdminBar', [
			'label' => __( 'Contact Form', 'reform-contact-form' ),
			'items' => $items,
		] );
	}

	/**
	 * The page's forms, found in its content, get their assets in <head>; any other loads them when rendered
	 */
	public static function detect() {
		if ( !is_singular() ) {
			return;
		}

		$content = (string) get_post_field( 'post_content', get_queried_object_id() );

		if ( false === strpos( $content, '[reform' ) && false === strpos( $content, '<!-- wp:reform/' ) ) {
			return;
		}

		// [reform id="a1b2c3d"] or id="12"
		preg_match_all( '/\[reform\s[^\]]*\bid=["\']?([a-f0-9]{7}|\d+)/', $content, $matches );

		$ids = $matches[1];

		// A block: its hash, else its post ID
		preg_match_all( '/<!-- wp:reform\/form (\{[^}]*\})/', $content, $blocks );

		foreach ( $blocks[1] as $json ) {
			$attributes = (array) json_decode( $json, true );
			$ids[]      = (string) ( $attributes['hash'] ?? '' ) ?: (string) ( $attributes['id'] ?? '' );
		}

		foreach ( array_filter( $ids ) as $id ) {
			$form = Form::find( $id );

			if ( $form ) {
				self::enqueue( $form );
			}
		}
	}

	/**
	 * What reform.js reads
	 *
	 * @return array
	 */
	public static function script_data() {
		return [
			'restUrl' => esc_url_raw( rest_url( 'reform/v1/' ) ),
		];
	}

	/**
	 * Enqueue a form's script and styles
	 *
	 * @param Form $form Form
	 */
	public static function enqueue( Form $form ) {
		Assets::enqueue( 'reform' );

		// "Theme": the form's look is the theme's, no Reform style loads
		if ( StyleManager::THEME === $form->style() ) {
			do_action( 'reform_enqueue', $form );

			return;
		}

		StyleManager::enqueue( dirname( StyleManager::form_file( $form->style(), 'response.php' ) ), 'form' );

		foreach ( $form->fields() as $field ) {
			$template = StyleManager::field_template( $field['type'], $field['style'] ?: $form->style() );

			if ( $template ) {
				StyleManager::enqueue( dirname( $template ), 'fields' );
			}
		}

		do_action( 'reform_enqueue', $form );
	}

	/**
	 * A form's markup
	 *
	 * @param int|Form $id   Form ID, or the form itself
	 * @param array    $args 'class', 'html_id', 'atts' (the shortcode's attributes, for fields filled from them)
	 *
	 * @return string
	 */
	public static function render( $id, array $args = [] ) {
		$form = $id instanceof Form ? $id : Form::find( $id );

		if ( !$form || 'publish' !== $form->status() ) {
			/* translators: %s: form ID, such as a1b2c3d */
			return current_user_can( 'edit_pages' ) ? '<p class="reform-missing">' . esc_html( sprintf( __( 'ReForm: form %s doesn\'t exist.', 'reform-contact-form' ), $form ? $form->hash() : sanitize_key( (string) $id ) ) ) . '</p>' : '';
		}

		// Logged-in users only: the others get the form's message instead
		if ( !empty( $form->config()['settings']['subscribers_only'] ) && !is_user_logged_in() ) {
			self::enqueue( $form );

			return sprintf( '<div class="reform reform--%s is-locked"><div class="reform-response">%s</div></div>', esc_attr( $form->style() ), self::response( $form, 'locked', Messages::get( $form, 'login_required' ) ) );
		}

		/**
		 * Render arguments of a form, wherever it is shown (a page, a widget, the editor's Preview)
		 *
		 * @param array $args 'class', 'html_id'
		 * @param Form  $form Form
		 */
		$args = (array) apply_filters( 'reform_render_args', $args, $form );

		self::$count++;

		if ( $form->id() && $form === Form::get( $form->id() ) ) {
			self::$rendered[] = $form->id();
		}

		$uid    = sanitize_html_class( (string) ( $args['html_id'] ?? '' ) ) ?: 'reform-' . $form->id() . ( self::$count > 1 ? '-' . self::$count : '' );
		$result = NoScript::result( $form->id(), $uid );
		$fields = [];
		$values = [];
		$ids    = [];
		$autofill = !empty( $form->config()['settings']['autocomplete'] );

		foreach ( $form->fields() as $name => $field ) {
			if ( !$autofill && array_key_exists( 'autocomplete', $field ) ) {
				$field['autocomplete'] = 'off';
			}

			$fields[ $name ] = (array) apply_filters( 'reform_field', $field, $form );
			$values[ $name ] = $result && isset( $result['posted'][ $name ] ) && 'file' !== $field['type'] ? $result['posted'][ $name ] : ( empty( $fields[ $name ]['default_from'] ) ? $fields[ $name ]['default'] : Defaults::value( $fields[ $name ], (array) ( $args['atts'] ?? [] ) ) );
			$ids[ $name ]    = $fields[ $name ]['id'] ?: $uid . '-' . $name;
		}

		$hidden   = Conditions::hidden_groups( $form, $values );
		$errors   = $result['invalid'] ?? [];
		$response = self::response_box( $form, $result );
		$placed   = false;
		$captcha  = false !== strpos( $form->template(), '[[captcha]]' );

		$html = Template::replace( $form->template(), static function ( $token ) use ( $form, $fields, $values, $ids, $errors, $hidden, $response, &$placed, &$captcha ) {
			switch ( $token['kind'] ) {
				case 'field':
					$name = $token['name'];

					if ( !isset( $fields[ $name ] ) ) {
						return '';
					}

					// The captcha goes before the first submit button, unless [[captcha]] places it
					$before = '';

					if ( 'submit' === $fields[ $name ]['type'] && !$captcha ) {
						$captcha = true;
						$before  = (string) apply_filters( 'reform_token_captcha', '', $form );
					}

					return $before . self::field( $form, $fields[ $name ], [
						'id'       => $ids[ $name ],
						'value'    => $values[ $name ],
						'values'   => $values,
						'ids'      => $ids,
						'invalid'  => isset( $errors[ $name ] ),
						'message'  => $errors[ $name ] ?? '',
						'error_id' => $ids[ $name ] . '-error',
						'form'     => $form,
					] );

				case 'group':
					return sprintf( '<div class="reform-group" data-reform-group="%s"%s>', esc_attr( $token['name'] ), in_array( $token['name'], $hidden, true ) ? ' hidden inert' : '' );

				case 'end':
					return '</div>';

				case 'reserved':
					if ( 'response' === $token['name'] ) {
						$placed = true;

						return $response;
					}

					return (string) apply_filters( 'reform_token_' . $token['name'], '', $form );
			}

			return '';
		} );

		if ( !$placed ) {
			$html .= $response;
		}

		$html = (string) apply_filters( 'reform_form_html', $html, $form );

		$has_file = in_array( 'file', wp_list_pluck( $fields, 'type' ), true );
		$status   = $result['status'] ?? '';
		$action   = remove_query_arg( NoScript::QUERY_VAR );

		$attrs = (array) apply_filters( 'reform_form_attributes', [
			'class'        => 'reform__form',
			'method'       => 'post',
			'action'       => $action . '#' . $uid,
			'enctype'      => $has_file ? 'multipart/form-data' : null,
			'novalidate'   => true,
			'autocomplete' => $autofill ? null : 'off',
			'data-reform'  => $form->id(),
			'data-nonce'   => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : null,
		], $form );

		$hidden_inputs = [
			'_reform_form' => $form->id(),
			'_reform_uid'  => $uid,
			'_reform_post' => (int) get_queried_object_id(),
		];

		$inputs = '';

		foreach ( (array) apply_filters( 'reform_hidden_inputs', $hidden_inputs, $form ) as $name => $value ) {
			$inputs .= sprintf( '<input type="hidden" name="%s" value="%s">', esc_attr( $name ), esc_attr( (string) $value ) );
		}

		$classes = array_filter( [
			'reform',
			'reform--' . $form->style(),
			$form->config()['settings']['class'],
			sanitize_text_field( (string) ( $args['class'] ?? '' ) ),
			$status ? 'is-' . $status : '',
		] );

		self::enqueue( $form );

		return sprintf(
			'<div class="%s" id="%s"><form%s><div class="reform__hidden" hidden>%s</div>%s</form><script type="application/json" class="reform__config">%s</script></div>',
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( $uid ),
			Field::html_attributes( $attrs ),
			$inputs,
			$html,
			wp_json_encode( self::script_config( $form ), JSON_HEX_TAG | JSON_HEX_AMP )
		);
	}

	/**
	 * A field: its wrapper, its template, its control and error
	 *
	 * @param Form  $form  Form
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return string
	 */
	private static function field( Form $form, array $field, array $ctx ) {
		$type = FieldRegistry::get( $field['type'] );

		if ( !$type ) {
			return '';
		}

		$control = (string) apply_filters( 'reform_field_control', $type->control( $field, $ctx ), $field, $form );
		$error   = sprintf(
			'<span class="reform-error" id="%s" data-reform-error%s>%s</span>',
			esc_attr( $ctx['error_id'] ),
			$ctx['invalid'] ? '' : ' hidden',
			esc_html( $ctx['message'] )
		);

		$template = StyleManager::field_template( $field['type'], $field['style'] ?: $form->style() );
		$inner    = $template
			? StyleManager::render_template( $template, [
				'field'   => $field,
				'control' => $control,
				'choices' => $type->choices( $field, $ctx ),
				'error'   => $error,
				'form'    => $form,
			] )
			: $control . $error;

		$attrs = array_merge( [
			'class'             => 'reform-field reform-field--' . $field['type'] . ( $ctx['invalid'] ? ' is-invalid' : '' ),
			'data-reform-field' => $field['name'],
			'data-reform-type'  => $field['type'],
		], $type->wrapper_attributes( $field ) );

		return '<span' . Field::html_attributes( $attrs ) . '>' . $inner . '</span>';
	}

	/**
	 * The response box, with a result when the page shows one (a submission without the script)
	 *
	 * @param Form       $form   Form
	 * @param array|null $result Result
	 *
	 * @return string
	 */
	private static function response_box( Form $form, $result ) {
		return sprintf(
			'<div class="reform-response" data-reform-response role="status" aria-live="polite" aria-atomic="true">%s</div>',
			$result ? self::response( $form, $result['status'], $result['message'] ) : ''
		);
	}

	/**
	 * What the response box shows (form/{style}/response.php)
	 *
	 * @param Form   $form    Form
	 * @param string $status  success, invalid, failed, spam, aborted
	 * @param string $message Message
	 *
	 * @return string
	 */
	public static function response( Form $form, $status, $message ) {
		return StyleManager::render_template( StyleManager::form_file( $form->style(), 'response.php' ), [
			'status'  => $status,
			'message' => $message,
			'form'    => $form,
		] );
	}

	/**
	 * What reform.js needs of a form: its groups' conditions and its messages
	 *
	 * @param Form $form Form
	 *
	 * @return array
	 */
	private static function script_config( Form $form ) {
		$ancestry = Template::ancestry( $form->template() );
		$groups   = [];

		foreach ( $ancestry['groups'] as $name => $parents ) {
			$groups[ $name ] = ( $form->groups()[ $name ] ?? [ 'action' => 'show', 'match' => 'all', 'rules' => [] ] ) + [ 'parents' => $parents ];
		}

		return (array) apply_filters( 'reform_script_config', [
			'groups'   => (object) $groups,
			'messages' => Messages::for_form( $form ),
			'redirect' => $form->config()['settings']['redirect'],
		], $form );
	}
}
