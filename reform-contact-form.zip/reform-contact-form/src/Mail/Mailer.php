<?php

namespace VLT\Reform\Mail;

use VLT\Reform\Front\StyleManager;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends a submission's mails: Mail, then Mail 2 when it is on and Mail went
 */
class Mailer {
	/**
	 * Send the mails
	 *
	 * @param Submission $submission Submission
	 *
	 * @return bool Whether Mail went
	 */
	public static function send_all( Submission $submission ) {
		// The form's "Don't send mail" setting, or REFORM_DISABLE_MAIL for every form: the entry is still saved
		$skip = !empty( $submission->form()->config()['settings']['skip_mail'] ) || ( defined( 'REFORM_DISABLE_MAIL' ) && REFORM_DISABLE_MAIL );

		if ( apply_filters( 'reform_skip_mail', $skip, $submission ) ) {
			return true;
		}

		$sent = self::send( $submission, 'mail' );

		if ( $sent && !empty( $submission->form()->config()['mail_2']['active'] ) ) {
			self::send( $submission, 'mail_2' );
		}

		return $sent;
	}

	/**
	 * Send one mail
	 *
	 * @param Submission $submission Submission
	 * @param string     $which      mail or mail_2
	 *
	 * @return bool
	 */
	public static function send( Submission $submission, $which ) {
		$mail = (array) $submission->form()->config()[ $which ];
		$html = !empty( $mail['html'] );
		$line = static fn( $text ) => trim( str_replace( [ "\r", "\n" ], ' ', MailTags::replace( (string) $text, $submission ) ) );

		$components = [
			'to'          => $line( $mail['to'] ),
			'from'        => $line( $mail['from'] ),
			'subject'     => $line( $mail['subject'] ),
			'body'        => MailTags::replace( (string) $mail['body'], $submission, $html ),
			// One header a line; a value can't add lines
			'headers'     => array_values( array_filter( array_map( $line, preg_split( '/\R/', (string) $mail['headers'] ) ), static fn( $header ) => (bool) preg_match( '/^[A-Za-z][\w-]*:\s*\S/', $header ) ) ),
			'attachments' => self::attachments( (string) $mail['attachments'], $submission ),
			'html'        => $html,
		];

		if ( $html ) {
			$components['body'] = self::html( wpautop( $components['body'] ), $components['subject'], $submission );
		}

		// REFORM_MAIL_TO: every mail to one address (a staging site), no copies to anyone else
		if ( defined( 'REFORM_MAIL_TO' ) && is_email( REFORM_MAIL_TO ) ) {
			$components['to']      = REFORM_MAIL_TO;
			$components['headers'] = array_values( array_filter( $components['headers'], static fn( $header ) => !preg_match( '/^(cc|bcc)\s*:/i', $header ) ) );
		}

		$components = (array) apply_filters( 'reform_mail', $components, $which, $submission );

		if ( '' === $components['to'] ) {
			return false;
		}

		$headers = $components['headers'];

		if ( '' !== $components['from'] ) {
			array_unshift( $headers, 'From: ' . $components['from'] );
		}

		if ( $components['html'] ) {
			$headers[] = 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' );
		}

		return (bool) wp_mail( $components['to'], $components['subject'], $components['body'], $headers, $components['attachments'] );
	}

	/**
	 * The files of the tags listed in Attachments
	 *
	 * @param string     $text       Attachments setting
	 * @param Submission $submission Submission
	 *
	 * @return string[] Paths
	 */
	private static function attachments( $text, Submission $submission ) {
		preg_match_all( '/\[([a-zA-Z][\w-]*)\]/', $text, $matches );

		$paths = [];

		foreach ( $matches[1] as $name ) {
			$field = $submission->form()->field( $name );

			if ( $field && 'file' === $field['type'] ) {
				foreach ( (array) $submission->posted( $name ) as $file ) {
					if ( !empty( $file['path'] ) && is_readable( $file['path'] ) ) {
						$paths[] = $file['path'];
					}
				}
			}
		}

		return $paths;
	}

	/**
	 * An HTML body in the mail template (mail/html.php)
	 *
	 * @param string     $body       Body
	 * @param string     $subject    Subject
	 * @param Submission $submission Submission
	 *
	 * @return string
	 */
	private static function html( $body, $subject, Submission $submission ) {
		return StyleManager::render_template( 'mail/html.php', [
			'body'       => $body,
			'subject'    => $subject,
			'submission' => $submission,
		] ) ?: $body;
	}
}
