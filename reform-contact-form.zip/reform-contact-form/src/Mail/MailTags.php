<?php

namespace VLT\Reform\Mail;

use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mail tags: a form's values and the site's details in a mail
 *
 *     [your_name]                         a field (option labels for select, checkbox and radio)
 *     [_raw_your_radio]                   the option values themselves
 *     [_site_title], [_date], [_url]…     special tags (special())
 *     [group:details] … [/group:details]  printed only when the group was shown
 */
class MailTags {
	/**
	 * Replace the tags of a text
	 *
	 * @param string     $text       Text
	 * @param Submission $submission Submission
	 * @param bool       $html       Escape values for HTML
	 *
	 * @return string
	 */
	public static function replace( $text, Submission $submission, $html = false ) {
		$hidden = $submission->hidden_groups();

		$text = (string) preg_replace_callback(
			'/\[group:([a-zA-Z][\w-]*)\](.*?)\[\/group:\1\]/s',
			static fn( $m ) => in_array( $m[1], $hidden, true ) ? '' : $m[2],
			(string) $text
		);

		return (string) preg_replace_callback( '/\[(_raw_)?([a-zA-Z_][\w-]*)\]/', static function ( $m ) use ( $submission, $html ) {
			$value = self::value( $m[2], '' !== $m[1], $submission );

			if ( null === $value ) {
				return $m[0];
			}

			return $html ? nl2br( esc_html( $value ) ) : $value;
		}, $text );
	}

	/**
	 * A tag's value; null for a tag that isn't known
	 *
	 * @param string     $name       Tag name
	 * @param bool       $raw        The [_raw_…] form
	 * @param Submission $submission Submission
	 *
	 * @return string|null
	 */
	public static function value( $name, $raw, Submission $submission ) {
		$field = $submission->form()->field( $name );
		$value = null;

		if ( $field ) {
			$type  = FieldRegistry::get( $field['type'] );
			$value = $type && $type->submits() ? $type->mail_value( $submission->posted( $name ), $field, $raw ) : null;
		} elseif ( !$raw && 0 === strpos( $name, '_' ) ) {
			$value = self::special( $name, $submission );
		}

		$value = apply_filters( 'reform_mail_tag', $value, $name, $raw, $submission );

		return null === $value ? null : (string) $value;
	}

	/**
	 * The special tags' names, for the editor
	 *
	 * @return string[]
	 */
	public static function specials() {
		// An add-on's own tags (filled through reform_mail_tag), so the editor doesn't flag them
		return (array) apply_filters( 'reform_special_mail_tags', [ '_site_title', '_site_description', '_site_url', '_site_admin_email', '_date', '_time', '_remote_ip', '_user_agent', '_url', '_post_id', '_post_name', '_post_title', '_post_url', '_post_author', '_post_author_email', '_user_login', '_user_email', '_user_display_name', '_user_first_name', '_user_last_name', '_form_id', '_form_title' ] );
	}

	/**
	 * A special tag's value
	 *
	 * @param string     $name       Tag name
	 * @param Submission $submission Submission
	 *
	 * @return string|null
	 */
	private static function special( $name, Submission $submission ) {
		$post = $submission->meta( 'post_id' ) ? get_post( $submission->meta( 'post_id' ) ) : null;
		$user = $submission->meta( 'user_id' ) ? get_userdata( $submission->meta( 'user_id' ) ) : null;

		switch ( $name ) {
			case '_site_title':
				return wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
			case '_site_description':
				return wp_specialchars_decode( get_bloginfo( 'description' ), ENT_QUOTES );
			case '_site_url':
				return home_url( '/' );
			case '_site_admin_email':
				return (string) get_option( 'admin_email' );
			case '_date':
				return wp_date( (string) get_option( 'date_format' ), $submission->meta( 'time' ) );
			case '_time':
				return wp_date( (string) get_option( 'time_format' ), $submission->meta( 'time' ) );
			case '_remote_ip':
				return $submission->meta( 'ip' );
			case '_user_agent':
				return $submission->meta( 'user_agent' );
			case '_url':
				return $submission->meta( 'url' );
			case '_post_id':
				return $post ? (string) $post->ID : '';
			case '_post_name':
				return $post ? $post->post_name : '';
			case '_post_title':
				return $post ? wp_specialchars_decode( get_the_title( $post ), ENT_QUOTES ) : '';
			case '_post_url':
				return $post ? (string) get_permalink( $post ) : '';
			case '_post_author':
				return $post ? get_the_author_meta( 'display_name', $post->post_author ) : '';
			case '_post_author_email':
				return $post ? get_the_author_meta( 'user_email', $post->post_author ) : '';
			case '_user_login':
				return $user ? $user->user_login : '';
			case '_user_email':
				return $user ? $user->user_email : '';
			case '_user_display_name':
				return $user ? $user->display_name : '';
			case '_user_first_name':
				return $user ? $user->first_name : '';
			case '_user_last_name':
				return $user ? $user->last_name : '';
			case '_form_id':
				return (string) $submission->form()->id();
			case '_form_title':
				return $submission->form()->title();
		}

		return null;
	}
}
