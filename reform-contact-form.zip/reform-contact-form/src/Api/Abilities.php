<?php

namespace VLT\Reform\Api;

use VLT\Reform\Admin\Admin;
use VLT\Reform\Core\Config;
use VLT\Reform\Core\PostType;
use VLT\Reform\Entries\Entries;
use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Forms\Form;
use VLT\Reform\Forms\Starter;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abilities for AI assistants (WordPress 6.9+ Abilities API)
 *
 *     reform/get-options   field types and their settings, operators, the starter form
 *     reform/list-forms    forms with their shortcode
 *     reform/get-form      one form: template and settings
 *     reform/create-form   a new form, from the starter unless a template is given
 *     reform/update-form   changes to a form
 *     reform/list-entries  messages a form received
 *
 * Settings go through Config::sanitize(); the user's capabilities decide what's allowed.
 */
class Abilities {
	const CATEGORY = 'reform';

	/**
	 * Init, where WordPress has the Abilities API
	 */
	public static function init() {
		if ( !function_exists( 'wp_register_ability' ) ) {
			return;
		}

		add_action( 'wp_abilities_api_categories_init', [ __CLASS__, 'category' ] );
		add_action( 'wp_abilities_api_init', [ __CLASS__, 'register' ] );
	}

	/**
	 * The abilities' category
	 */
	public static function category() {
		if ( function_exists( 'wp_register_ability_category' ) ) {
			wp_register_ability_category( self::CATEGORY, [
				'label'       => __( 'Reform', 'reform-contact-form' ),
				'description' => __( 'Contact forms made with Reform and the messages they received.', 'reform-contact-form' ),
			] );
		}
	}

	/**
	 * Register the abilities
	 */
	public static function register() {
		$can  = static fn() => current_user_can( Admin::CAPABILITY );
		$form = [
			'type'       => 'object',
			'properties' => [
				'id'        => [ 'type' => 'integer' ],
				'title'     => [ 'type' => 'string' ],
				'shortcode' => [ 'type' => 'string' ],
				'edit_url'  => [ 'type' => 'string' ],
				'template'  => [ 'type' => 'string' ],
				'config'    => [ 'type' => 'object' ],
			],
		];
		$template_help = __( 'The form as HTML with a [[name]] token per field and [[group:name]] … [[/group]] around conditional parts. Each token needs a field of that name in config.fields.', 'reform-contact-form' );
		$config_help   = __( 'Settings, the shape of reform/get-form\'s config: fields (by name, each with a type), groups, mail, mail_2, messages, settings. Give only what changes; unknown keys are dropped.', 'reform-contact-form' );

		self::add( 'get-options', [
			'label'               => __( 'Get Reform options', 'reform-contact-form' ),
			'description'         => __( 'Lists the field types with their settings and defaults, the operators of group conditions, and the starter form, to build valid forms for reform/create-form.', 'reform-contact-form' ),
			'output_schema'       => [ 'type' => 'object' ],
			'execute_callback'    => [ __CLASS__, 'options' ],
			'permission_callback' => $can,
		], true );

		self::add( 'list-forms', [
			'label'               => __( 'List forms', 'reform-contact-form' ),
			'description'         => __( 'Lists the contact forms with their shortcode.', 'reform-contact-form' ),
			// Optional input: called without any, it lists every form
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [ 'search' => [ 'type' => 'string', 'description' => __( 'Words in the title.', 'reform-contact-form' ) ] ],
				'default'    => [],
			],
			'output_schema'       => [ 'type' => 'array', 'items' => $form ],
			'execute_callback'    => [ __CLASS__, 'list_forms' ],
			'permission_callback' => $can,
		], true );

		self::add( 'get-form', [
			'label'               => __( 'Get a form', 'reform-contact-form' ),
			'description'         => __( 'Gets one form: its template, fields, mails, messages and settings.', 'reform-contact-form' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [ 'id' => [ 'type' => 'integer' ] ],
				'required'   => [ 'id' ],
			],
			'output_schema'       => $form,
			'execute_callback'    => [ __CLASS__, 'get_form' ],
			'permission_callback' => static fn( $input ) => current_user_can( 'edit_post', (int) ( $input['id'] ?? 0 ) ),
		], true );

		self::add( 'create-form', [
			'label'               => __( 'Create a form', 'reform-contact-form' ),
			'description'         => __( 'Creates a contact form and returns its shortcode to put on a page. Without a template it starts from the starter form (name, email, subject, message).', 'reform-contact-form' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'title'    => [ 'type' => 'string' ],
					'template' => [ 'type' => 'string', 'description' => $template_help ],
					'config'   => [ 'type' => 'object', 'description' => $config_help ],
				],
			],
			'output_schema'       => $form,
			'execute_callback'    => [ __CLASS__, 'create_form' ],
			'permission_callback' => $can,
		] );

		self::add( 'update-form', [
			'label'               => __( 'Update a form', 'reform-contact-form' ),
			'description'         => __( 'Changes a form: its title, template, and settings merged into the saved ones (lists are replaced as a whole).', 'reform-contact-form' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'id'       => [ 'type' => 'integer' ],
					'title'    => [ 'type' => 'string' ],
					'template' => [ 'type' => 'string', 'description' => $template_help ],
					'config'   => [ 'type' => 'object', 'description' => $config_help ],
				],
				'required'   => [ 'id' ],
			],
			'output_schema'       => $form,
			'execute_callback'    => [ __CLASS__, 'update_form' ],
			'permission_callback' => static fn( $input ) => current_user_can( 'edit_post', (int) ( $input['id'] ?? 0 ) ),
		], false, true );

		self::add( 'list-entries', [
			'label'               => __( 'List entries', 'reform-contact-form' ),
			'description'         => __( 'Lists the messages a form received, newest first, with their values.', 'reform-contact-form' ),
			'input_schema'        => [
				'type'       => 'object',
				'properties' => [
					'form'   => [ 'type' => 'integer', 'description' => __( 'Form ID; all forms when left out.', 'reform-contact-form' ) ],
					'number' => [ 'type' => 'integer', 'default' => 20, 'maximum' => 100 ],
				],
				'default'    => [],
			],
			'output_schema'       => [ 'type' => 'array' ],
			'execute_callback'    => [ __CLASS__, 'list_entries' ],
			'permission_callback' => $can,
		], true );
	}

	/**
	 * Register one ability
	 *
	 * @param string $name       Name without the category
	 * @param array  $args       Arguments
	 * @param bool   $readonly   It changes nothing
	 * @param bool   $idempotent Running it again with the same input changes nothing more
	 */
	private static function add( $name, array $args, $readonly = false, $idempotent = false ) {
		wp_register_ability( self::CATEGORY . '/' . $name, $args + [
			'category' => self::CATEGORY,
			'meta'     => [
				'annotations' => [
					'readonly'    => $readonly,
					'destructive' => false,
					'idempotent'  => $readonly || $idempotent,
				],
				'public'      => true,
			],
		] );
	}

	/**
	 * reform/get-options
	 *
	 * @return array
	 */
	public static function options() {
		$types = [];

		foreach ( FieldRegistry::all() as $id => $type ) {
			$types[ $id ] = [
				'label'    => $type->label(),
				'defaults' => $type->defaults(),
				'settings' => $type->schema(),
			];
		}

		return [
			'field_types' => $types,
			'operators'   => Config::OPERATORS,
			'defaults'    => Config::defaults(),
			'starter'     => Starter::get(),
		];
	}

	/**
	 * reform/list-forms
	 *
	 * @param array|null $input Input
	 *
	 * @return array
	 */
	public static function list_forms( $input = null ) {
		$posts = get_posts( [
			'post_type'      => PostType::NAME,
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			's'              => (string) ( $input['search'] ?? '' ),
		] );

		return array_map( static fn( $post ) => self::form( Form::get( $post->ID ), false ), $posts );
	}

	/**
	 * reform/get-form
	 *
	 * @param array $input Input
	 *
	 * @return array|\WP_Error
	 */
	public static function get_form( $input ) {
		$form = Form::get( (int) ( $input['id'] ?? 0 ) );

		return $form ? self::form( $form, true ) : self::not_found();
	}

	/**
	 * reform/create-form
	 *
	 * @param array $input Input
	 *
	 * @return array|\WP_Error
	 */
	public static function create_form( $input ) {
		$id = Starter::create( sanitize_text_field( (string) ( $input['title'] ?? '' ) ) );

		if ( is_wp_error( $id ) ) {
			return $id;
		}

		return self::update_form( [ 'id' => $id ] + (array) $input );
	}

	/**
	 * reform/update-form
	 *
	 * @param array $input Input
	 *
	 * @return array|\WP_Error
	 */
	public static function update_form( $input ) {
		$id = (int) ( $input['id'] ?? 0 );

		if ( !Form::get( $id ) ) {
			return self::not_found();
		}

		$post = [ 'ID' => $id ];

		if ( isset( $input['title'] ) ) {
			$post['post_title'] = sanitize_text_field( (string) $input['title'] );
		}

		if ( isset( $input['template'] ) ) {
			$post['post_content'] = (string) $input['template'];
		}

		if ( count( $post ) > 1 ) {
			wp_update_post( wp_slash( $post ) );
		}

		if ( isset( $input['config'] ) && is_array( $input['config'] ) ) {
			Config::save( $id, Config::merge( Config::get( $id ), $input['config'] ) );
		}

		clean_post_cache( $id );
		Form::forget( $id );

		return self::form( Form::get( $id ), true );
	}

	/**
	 * reform/list-entries
	 *
	 * @param array|null $input Input
	 *
	 * @return array
	 */
	public static function list_entries( $input = null ) {
		$posts = get_posts( [
			'post_type'      => Entries::POST_TYPE,
			'post_status'    => 'publish',
			'post_parent'    => (int) ( $input['form'] ?? 0 ) ?: '',
			'posts_per_page' => min( 100, max( 1, (int) ( $input['number'] ?? 20 ) ) ),
		] );

		return array_map( static fn( $post ) => [
			'id'     => $post->ID,
			'form'   => (int) $post->post_parent,
			'date'   => get_post_time( 'c', true, $post ),
			'unread' => (bool) get_post_meta( $post->ID, '_reform_unread', true ),
			'fields' => wp_list_pluck( Entries::data( $post->ID ), 'value' ),
		], $posts );
	}

	/**
	 * A form as the abilities give it
	 *
	 * @param Form $form        Form
	 * @param bool $with_config With its template and settings
	 *
	 * @return array
	 */
	private static function form( Form $form, $with_config ) {
		$data = [
			'id'        => $form->id(),
			'title'     => $form->title(),
			'shortcode' => $form->shortcode(),
			'edit_url'  => Admin::edit_url( $form->id() ),
		];

		return $with_config ? $data + [ 'template' => $form->template(), 'config' => $form->config() ] : $data;
	}

	/**
	 * No such form
	 *
	 * @return \WP_Error
	 */
	private static function not_found() {
		return new \WP_Error( 'reform_no_form', __( 'This form doesn\'t exist.', 'reform-contact-form' ), [ 'status' => 404 ] );
	}
}
