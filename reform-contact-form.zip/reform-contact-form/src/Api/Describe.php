<?php

namespace VLT\Reform\Api;

use VLT\Reform\Admin\Admin;
use VLT\Reform\Core\Config;
use VLT\Reform\Forms\Template;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * "Describe your form": a form's markup and settings from a sentence, written by the AI connected to WordPress
 * (7.0+)
 *
 *     POST reform/v1/describe { prompt, template, config }  →  { template, config, summary }
 *
 * The settings go through Config::sanitize(), so only the plugin's own values get in; the markup is saved as any
 * form's (through kses for users without unfiltered_html).
 */
class Describe {
	/**
	 * Init
	 */
	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'route' ] );
	}

	/**
	 * Whether the site has an AI model that writes text
	 *
	 * @return bool
	 */
	public static function available() {
		return function_exists( 'wp_ai_client_prompt' ) && true === wp_ai_client_prompt()->is_supported_for_text_generation();
	}

	/**
	 * Register the route
	 */
	public static function route() {
		register_rest_route( Rest::NS, '/describe', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'describe' ],
			'permission_callback' => static fn() => current_user_can( Admin::CAPABILITY ),
			'args'                => [
				'prompt'   => [ 'type' => 'string', 'required' => true, 'minLength' => 3, 'maxLength' => 1500 ],
				'template' => [ 'type' => 'string', 'default' => '' ],
				'config'   => [ 'type' => 'object', 'required' => true ],
			],
		] );
	}

	/**
	 * The form for a description
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function describe( \WP_REST_Request $request ) {
		if ( !self::available() ) {
			return new \WP_Error( 'reform_ai_unavailable', __( 'Connect an AI service to WordPress to describe a form.', 'reform-contact-form' ), [ 'status' => 503 ] );
		}

		$template = (string) $request['template'];
		$config   = Config::sanitize( (array) $request['config'] );
		$answer   = wp_ai_client_prompt( sanitize_textarea_field( $request['prompt'] ) )
			->using_system_instruction( self::instruction( $template, $config ) )
			->using_temperature( 0.2 )
			->as_json_response()
			->generate_text();

		if ( is_wp_error( $answer ) ) {
			return $answer;
		}

		$result = self::apply( $template, $config, (string) $answer );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * The model's answer over the current form
	 *
	 * @param string $template Current markup
	 * @param array  $config   Current settings
	 * @param string $answer   The model's answer: { "summary", "template", "config" }, maybe in a code fence
	 *
	 * @return array|\WP_Error [ template, config, summary ]
	 */
	public static function apply( $template, array $config, $answer ) {
		$answer = trim( (string) preg_replace( '/^```(?:json)?|```$/m', '', trim( (string) $answer ) ) );
		$data   = json_decode( $answer, true );

		// Some models write a line before the JSON: take the outermost object
		if ( !is_array( $data ) && preg_match( '/\{.*\}/s', $answer, $match ) ) {
			$data = json_decode( $match[0], true );
		}

		if ( !is_array( $data ) || ( !isset( $data['template'] ) && !is_array( $data['config'] ?? null ) ) ) {
			return new \WP_Error( 'reform_ai_answer', __( 'The answer could not be read. Try again, or describe the form differently.', 'reform-contact-form' ), [ 'status' => 502 ] );
		}

		$template = is_string( $data['template'] ?? null ) && '' !== trim( $data['template'] ) ? $data['template'] : $template;
		$config   = Config::merge( $config, is_array( $data['config'] ?? null ) ? $data['config'] : [] );

		// Only the fields and groups the markup places
		$placed           = Template::ancestry( $template );
		$config['fields'] = array_intersect_key( (array) $config['fields'], array_flip( Template::fields( $template ) ) );
		$config['groups'] = array_intersect_key( (array) $config['groups'], $placed['groups'] );

		return [
			'template' => $template,
			'config'   => Config::sanitize( $config ),
			'summary'  => sanitize_text_field( (string) ( $data['summary'] ?? '' ) ),
		];
	}

	/**
	 * What the model is told: its job, the answer's form, the field types and the current form
	 *
	 * @param string $template Current markup
	 * @param array  $config   Current settings
	 *
	 * @return string
	 */
	private static function instruction( $template, array $config ) {
		$json = static fn( $value ) => (string) wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		return implode( "\n\n", [
			'You build or change one contact form of the WordPress plugin ReForm from what the user asks.',
			'Answer with one JSON object only: {"summary": "one short sentence on what you did, in the language of the request", "template": "the whole form markup", "config": {only the settings to change}}.',
			'The template is HTML with a [[name]] token where each field goes and [[group:name]] … [[/group]] around a part shown on a condition. Write labels in the language of the request. Follow the markup of the current template; for a new one use plain markup without classes: <label>Label * [[name]]</label>, a <fieldset> with a <legend> for radio buttons and checkboxes, and [[submit]] last. Field names: lowercase letters, digits and _, starting with a letter.',
			'config.fields has one entry per token, keyed by its name, with a "type" from the field types below and that type\'s settings. Options are [{"value", "label"}]. A group\'s condition goes in config.groups[name]: {"action": "show"|"hide", "match": "all"|"any", "rules": [{"field", "op", "value"}]}. Update config.mail.body (and subject when it helps) so the mail lists every field as [name]. Keep everything the user did not ask to change.',
			'Field types, operators and defaults: ' . $json( Abilities::options() ),
			'Current template: ' . $json( $template ),
			'Current settings: ' . $json( $config ),
		] );
	}
}
