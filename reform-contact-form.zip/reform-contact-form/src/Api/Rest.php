<?php

namespace VLT\Reform\Api;

use VLT\Reform\Core\Config;
use VLT\Reform\Core\PostType;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's requests (reform/v1)
 *
 *     POST   forms/{id}/submit   a visitor sends a form (public)
 *     POST   forms/{id}          the editor saves a form
 *     DELETE forms/{id}          the editor moves a form to the trash
 */
class Rest {
	const NS = 'reform/v1';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	/**
	 * Routes
	 */
	public static function routes() {
		register_rest_route( self::NS, '/forms/(?P<id>\d+)/submit', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'submit' ],
			'permission_callback' => '__return_true',
			'args'                => [ 'id' => [ 'type' => 'integer', 'required' => true ] ],
		] );

		register_rest_route( self::NS, '/forms/(?P<id>\d+)', [
			[
				'methods'             => 'POST',
				'callback'            => [ __CLASS__, 'save' ],
				'permission_callback' => [ __CLASS__, 'can_edit' ],
				'args'                => [
					'title'       => [ 'type' => 'string', 'default' => '' ],
					'description' => [ 'type' => 'string', 'default' => '' ],
					'template'    => [ 'type' => 'string', 'required' => true ],
					'config'      => [ 'type' => 'object', 'required' => true ],
					'status'      => [ 'type' => 'string', 'enum' => [ 'publish', 'draft' ], 'default' => 'publish' ],
				],
			],
			[
				'methods'             => 'DELETE',
				'callback'            => [ __CLASS__, 'trash' ],
				'permission_callback' => [ __CLASS__, 'can_delete' ],
			],
		] );
	}

	/**
	 * Whether the user may edit this form
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return bool
	 */
	public static function can_edit( \WP_REST_Request $request ) {
		return PostType::NAME === get_post_type( (int) $request['id'] ) && current_user_can( 'edit_post', (int) $request['id'] );
	}

	/**
	 * Whether the user may trash this form
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return bool
	 */
	public static function can_delete( \WP_REST_Request $request ) {
		return PostType::NAME === get_post_type( (int) $request['id'] ) && current_user_can( 'delete_post', (int) $request['id'] );
	}

	/**
	 * The editor saves a form
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function save( \WP_REST_Request $request ) {
		$id = (int) $request['id'];

		/**
		 * What the editor sends, before it is saved: a WP_Error stops the save and is shown in the editor
		 *
		 * @param array $form 'title', 'description', 'template', 'status', 'config'
		 * @param int   $id   Form ID
		 */
		$form = apply_filters( 'reform_save_form', [
			'title'       => (string) $request['title'],
			'description' => (string) $request['description'],
			'template'    => (string) $request['template'],
			'status'      => 'draft' === $request['status'] ? 'draft' : 'publish',
			'config'      => (array) $request['config'],
		], $id );

		if ( is_wp_error( $form ) ) {
			return $form;
		}

		$result = wp_update_post( wp_slash( [
			'ID'           => $id,
			'post_title'   => sanitize_text_field( (string) $form['title'] ),
			'post_excerpt' => sanitize_text_field( (string) $form['description'] ),
			// Users without unfiltered_html get it through kses, as any post
			'post_content' => (string) $form['template'],
			// A draft isn't shown on the site
			'post_status'  => 'draft' === $form['status'] ? 'draft' : 'publish',
		] ), true );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		Config::save( $id, (array) $form['config'] );

		do_action( 'reform_saved_form', $id );

		$config = Config::get( $id );

		foreach ( [ 'fields', 'groups', 'messages' ] as $key ) {
			$config[ $key ] = (object) $config[ $key ];
		}

		return rest_ensure_response( [
			'status'   => get_post_status( $id ),
			'template' => get_post_field( 'post_content', $id ),
			'config'   => $config,
		] );
	}

	/**
	 * The editor moves a form to the trash
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response
	 */
	public static function trash( \WP_REST_Request $request ) {
		return rest_ensure_response( [ 'trashed' => (bool) wp_trash_post( (int) $request['id'] ) ] );
	}

	/**
	 * A visitor sends a form
	 *
	 * @param \WP_REST_Request $request Request
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function submit( \WP_REST_Request $request ) {
		$form = Form::get( (int) $request['id'] );

		if ( !$form || 'publish' !== get_post_status( $form->id() ) ) {
			return new \WP_Error( 'reform_no_form', __( 'This form doesn\'t exist.', 'reform-contact-form' ), [ 'status' => 404 ] );
		}

		$result = ( new Submission( $form, $request->get_body_params(), $request->get_file_params() ) )->run();

		$invalid = [];

		foreach ( $result['invalid'] as $name => $message ) {
			$invalid[] = [ 'field' => $name, 'message' => $message ];
		}

		$response = [
			'status'   => $result['status'],
			'message'  => $result['message'],
			'html'     => Renderer::response( $form, $result['status'], $result['message'] ),
			'invalid'  => $invalid,
			'data'     => (object) $result['data'],
			'redirect' => 'success' === $result['status'] ? $form->config()['settings']['redirect'] : '',
		];

		return rest_ensure_response( (array) apply_filters( 'reform_response', $response, $result, $form ) );
	}
}
