<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A file upload; Submission\Uploads receives and checks the files, the value is their list
 */
class File extends Field {
	public function type() {
		return 'file';
	}

	public function label() {
		return __( 'File', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'Lets visitors attach files. Put [your_file] in the mail\'s Attachments to get them by mail.', 'reform-contact-form' );
	}

	protected function own_defaults() {
		return [
			'accept'   => 'jpg, jpeg, png, gif, webp, pdf, doc, docx, txt',
			'max_size' => '2',
			'multiple' => false,
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['accept']   = implode( ', ', self::extensions( $clean ) );
		$clean['max_size'] = is_numeric( $clean['max_size'] ) && $clean['max_size'] > 0 ? (string) (float) $clean['max_size'] : '2';

		return $clean;
	}

	/**
	 * Allowed extensions
	 *
	 * @param array $field Field
	 *
	 * @return string[] Lowercase, no dots
	 */
	public static function extensions( array $field ) {
		$list = preg_split( '/[\s,|]+/', strtolower( (string) $field['accept'] ), -1, PREG_SPLIT_NO_EMPTY );

		return array_values( array_unique( array_filter( array_map( static fn( $ext ) => preg_replace( '/[^a-z0-9]/', '', $ext ), $list ) ) ) );
	}

	/**
	 * Largest size allowed, in bytes
	 *
	 * @param array $field Field
	 *
	 * @return int
	 */
	public static function max_bytes( array $field ) {
		return (int) min( (float) $field['max_size'] * MB_IN_BYTES, wp_max_upload_size() );
	}

	public function messages() {
		return [
			'upload_failed'            => [ 'label' => __( 'Upload failed', 'reform-contact-form' ), 'default' => __( 'The file couldn\'t be uploaded. Please try again.', 'reform-contact-form' ) ],
			'upload_file_type_invalid' => [ 'label' => __( 'File type not allowed', 'reform-contact-form' ), 'default' => __( 'This type of file isn\'t allowed.', 'reform-contact-form' ) ],
			'upload_file_too_large'    => [ 'label' => __( 'File too large', 'reform-contact-form' ), 'default' => __( 'This file is too large.', 'reform-contact-form' ) ],
		];
	}

	public function control( array $field, array $ctx ) {
		$attrs = array_merge( $this->attributes( $field, $ctx ), [
			'type'                 => 'file',
			'name'                 => $field['multiple'] ? $field['name'] . '[]' : $field['name'],
			'multiple'             => $field['multiple'],
			'accept'               => implode( ',', array_map( static fn( $ext ) => '.' . $ext, self::extensions( $field ) ) ),
			'data-reform-max-size' => self::max_bytes( $field ),
		] );

		return '<input' . self::html_attributes( $attrs ) . '>';
	}

	// Submission\Uploads passes the files received
	public function value( $raw, array $field ) {
		return is_array( $raw ) ? $raw : [];
	}

	public function validate( $value, array $field, Submission $submission ) {
		return $submission->upload_error( $field['name'] ) ?: parent::validate( $value, $field, $submission );
	}

	public function mail_value( $value, array $field, $raw = false ) {
		return implode( ', ', wp_list_pluck( (array) $value, 'name' ) );
	}

	public function editor_schema() {
		return [
			'accept'   => [ 'type' => 'text', 'label' => __( 'Allowed types', 'reform-contact-form' ), 'help' => __( 'Extensions, separated by commas.', 'reform-contact-form' ) ],
			'max_size' => [ 'type' => 'number', 'label' => __( 'Max size (MB)', 'reform-contact-form' ), 'help' => __( 'The largest file allowed. Your server may set a lower limit, and that one wins.', 'reform-contact-form' ) ],
			'multiple' => [ 'type' => 'toggle', 'label' => __( 'Several files', 'reform-contact-form' ), 'help' => __( 'Visitors can pick more than one file at once.', 'reform-contact-form' ) ],
		];
	}
}
