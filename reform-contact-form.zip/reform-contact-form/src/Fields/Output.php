<?php

namespace VLT\Reform\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A mirror of another field's value, as text, updated as the visitor types; never sent
 */
class Output extends Field {
	public function type() {
		return 'output';
	}

	public function label() {
		return __( 'Output', 'reform-contact-form' );
	}

	public function menu() {
		return 'more';
	}

	public function summary() {
		return __( 'Shows what visitors type in another field, as they type', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'Repeats another field as visitors type. For example, pick the name field and the format "Thanks, {value}!".', 'reform-contact-form' );
	}

	public function submits() {
		return false;
	}

	protected function own_defaults() {
		return [
			'source' => '',
			'format' => '{value}',
			'empty'  => '',
		];
	}

	public function control( array $field, array $ctx ) {
		$source = $field['source'];
		$value  = $ctx['values'][ $source ] ?? '';
		$value  = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
		$text   = '' === $value ? $field['empty'] : str_replace( '{value}', $value, $field['format'] ?: '{value}' );

		$attrs = [
			'id'                 => $ctx['id'],
			'class'              => trim( 'reform-output ' . $field['class'] ),
			'for'                => $ctx['ids'][ $source ] ?? null,
			'aria-live'          => 'polite',
			'data-reform-output' => $source,
			'data-format'        => $field['format'] ?: '{value}',
			'data-empty'         => $field['empty'],
		];

		return '<output' . self::html_attributes( $attrs ) . '>' . esc_html( $text ) . '</output>';
	}

	public function editor_schema() {
		return [
			'source' => [ 'type' => 'field', 'label' => __( 'Mirror of', 'reform-contact-form' ), 'help' => __( 'The field whose value shows here as visitors type or pick. For options, their labels show.', 'reform-contact-form' ) ],
			'format' => [ 'type' => 'text', 'label' => __( 'Format', 'reform-contact-form' ), 'help' => __( '{value} is replaced with the field\'s value.', 'reform-contact-form' ) ],
			'empty'  => [ 'type' => 'text', 'label' => __( 'Text when empty', 'reform-contact-form' ), 'help' => __( 'Shown until that field has a value. Empty: nothing shows.', 'reform-contact-form' ) ],
		];
	}
}
