<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One line of text; the base of email, URL, tel, number and date
 */
class Text extends Field {
	public function type() {
		return 'text';
	}

	public function label() {
		return __( 'Text', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'One line, such as a name or a subject. For example, with Fill from set to URL parameter, a link ending in ?subject=Pricing opens the form with the subject filled in.', 'reform-contact-form' );
	}

	public function kind() {
		return 'input';
	}

	/**
	 * The input's type attribute
	 *
	 * @return string
	 */
	protected function input_type() {
		return 'text';
	}

	protected function own_defaults() {
		return [
			'minlength'    => 0,
			'maxlength'    => 0,
			'autocomplete' => '',
		];
	}

	/**
	 * Attributes of this type: limits, pattern
	 *
	 * @param array $field Field
	 *
	 * @return array
	 */
	protected function input_attributes( array $field ) {
		return [
			'minlength' => $field['minlength'] ?: null,
			'maxlength' => $field['maxlength'] ?: null,
		];
	}

	public function control( array $field, array $ctx ) {
		$attrs = array_merge( $this->attributes( $field, $ctx ), [
			'type'         => $this->input_type(),
			'value'        => is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '',
			'placeholder'  => $field['placeholder'],
			'autocomplete' => $field['autocomplete'] ?? '',
		], $this->input_attributes( $field ) );

		return '<input' . self::html_attributes( $attrs ) . '>';
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = parent::validate( $value, $field, $submission );

		if ( $error || self::is_empty( $value ) ) {
			return $error;
		}

		$length = mb_strlen( (string) $value );

		if ( !empty( $field['maxlength'] ) && $length > $field['maxlength'] ) {
			return 'too_long';
		}

		if ( !empty( $field['minlength'] ) && $length < $field['minlength'] ) {
			return 'too_short';
		}

		return '';
	}

	public function editor_schema() {
		return [
			'placeholder'  => [ 'type' => 'text', 'label' => __( 'Placeholder', 'reform-contact-form' ), 'help' => __( 'A hint shown in the empty field. It goes away as soon as visitors type.', 'reform-contact-form' ) ],
			'default'      => [ 'type' => 'text', 'label' => __( 'Default value', 'reform-contact-form' ), 'help' => __( 'Text already in the field when the page opens. Visitors can change it.', 'reform-contact-form' ) ],
			'minlength'    => [ 'type' => 'number', 'label' => __( 'Min length', 'reform-contact-form' ), 'help' => __( 'The fewest characters visitors must type. Empty: no limit.', 'reform-contact-form' ) ],
			'maxlength'    => [ 'type' => 'number', 'label' => __( 'Max length', 'reform-contact-form' ), 'help' => __( 'The most characters visitors can type. Empty: no limit.', 'reform-contact-form' ) ],
			'autocomplete' => [ 'type' => 'text', 'label' => __( 'Autocomplete', 'reform-contact-form' ), 'help' => __( 'A browser hint such as name, email or tel.', 'reform-contact-form' ) ],
		];
	}
}
