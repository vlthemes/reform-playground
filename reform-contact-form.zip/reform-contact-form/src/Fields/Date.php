<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A date (YYYY-MM-DD), with optional limits; the default and the limits can be "today" or "today+7", worked out
 * in the site's time zone when the form is shown and checked
 */
class Date extends Text {
	public function type() {
		return 'date';
	}

	public function label() {
		return __( 'Date', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'A date picker. Min and max limit the days visitors can pick.', 'reform-contact-form' );
	}

	protected function input_type() {
		return 'date';
	}

	protected function own_defaults() {
		return [
			'min'          => '',
			'max'          => '',
			'autocomplete' => '',
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		foreach ( [ 'default', 'min', 'max' ] as $key ) {
			$clean[ $key ] = self::is_date( $clean[ $key ] ) || self::is_relative( $clean[ $key ] ) ? $clean[ $key ] : '';
		}

		return $clean;
	}

	protected function input_attributes( array $field ) {
		return [
			'min' => self::resolve( $field['min'] ),
			'max' => self::resolve( $field['max'] ),
		];
	}

	public function control( array $field, array $ctx ) {
		// The default "today" as the date it is now; a posted value is already a date
		$ctx['value'] = self::resolve( is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '' );

		return parent::control( $field, $ctx );
	}

	public function messages() {
		return [
			'invalid_date'   => [ 'label' => __( 'Date isn\'t valid', 'reform-contact-form' ), 'default' => __( 'Please enter a valid date.', 'reform-contact-form' ) ],
			'date_too_early' => [ 'label' => __( 'Date too early', 'reform-contact-form' ), 'default' => __( 'This date is too early.', 'reform-contact-form' ) ],
			'date_too_late'  => [ 'label' => __( 'Date too late', 'reform-contact-form' ), 'default' => __( 'This date is too late.', 'reform-contact-form' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = Field::validate( $value, $field, $submission );

		if ( $error || '' === $value ) {
			return $error;
		}

		if ( !self::is_date( $value ) ) {
			return 'invalid_date';
		}

		$min = self::resolve( $field['min'] );
		$max = self::resolve( $field['max'] );

		// YYYY-MM-DD compares as text
		if ( '' !== $min && $value < $min ) {
			return 'date_too_early';
		}

		if ( '' !== $max && $value > $max ) {
			return 'date_too_late';
		}

		return '';
	}

	public function editor_schema() {
		return [
			'default' => [ 'type' => 'date', 'label' => __( 'Default value', 'reform-contact-form' ), 'empty' => __( 'Empty', 'reform-contact-form' ), 'help' => __( 'The date already picked when the page opens.', 'reform-contact-form' ) ],
			'min'     => [ 'type' => 'date', 'label' => __( 'Earliest', 'reform-contact-form' ), 'empty' => __( 'No limit', 'reform-contact-form' ), 'help' => __( 'The first date visitors can pick. "Today" keeps them from picking a past date.', 'reform-contact-form' ) ],
			'max'     => [ 'type' => 'date', 'label' => __( 'Latest', 'reform-contact-form' ), 'empty' => __( 'No limit', 'reform-contact-form' ), 'help' => __( 'The last date visitors can pick, such as 30 days from today for bookings.', 'reform-contact-form' ) ],
		];
	}

	/**
	 * Whether a value is a real date in YYYY-MM-DD
	 *
	 * @param string $value Value
	 *
	 * @return bool
	 */
	private static function is_date( $value ) {
		return (bool) preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $value, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	}

	/**
	 * Whether a value is "today" or days from it ("today+7", "today-1")
	 *
	 * @param string $value Value
	 *
	 * @return bool
	 */
	private static function is_relative( $value ) {
		return (bool) preg_match( '/^today([+-]\d{1,4})?$/', (string) $value );
	}

	/**
	 * A setting as a date: "today+7" as the date it is in the site's time zone, others as they are
	 *
	 * @param string $value Value
	 *
	 * @return string
	 */
	public static function resolve( $value ) {
		if ( !self::is_relative( $value ) ) {
			return (string) $value;
		}

		$days = (int) substr( (string) $value, 5 );

		return ( new \DateTimeImmutable( 'today', wp_timezone() ) )->modify( sprintf( '%+d days', $days ) )->format( 'Y-m-d' );
	}
}
