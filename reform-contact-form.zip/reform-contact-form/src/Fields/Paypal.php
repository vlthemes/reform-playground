<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Payments\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A payment through PayPal, with PayPal's own buttons in the form
 */
class Paypal extends Payment {
	public function type() {
		return 'paypal';
	}

	public function label() {
		return __( 'PayPal payment', 'reform-contact-form' );
	}

	public function summary() {
		return __( 'Visitors pay with PayPal before the message goes', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'Visitors pay with PayPal or a card before the message goes. Set the amount, or take it from a field such as a select of plans. Keys go in Settings → Payments.', 'reform-contact-form' );
	}

	protected function client( array $field ) {
		return [
			'data-key' => (string) ( Payments::settings()['paypal_client'] ?? '' ),
		];
	}
}
