<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A number, with optional limits and step
 */
class Number extends Text {
	public function type() {
		return 'number';
	}

	public function label() {
		return __( 'Number', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'A number, with an optional min, max and step. For example, min 1 and max 10 for "How many guests?".', 'reform-contact-form' );
	}

	protected function input_type() {
		return 'number';
	}

	protected function own_defaults() {
		return [
			'min'          => '',
			'max'          => '',
			'step'         => '',
			'autocomplete' => '',
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		foreach ( [ 'min', 'max', 'step' ] as $key ) {
			$clean[ $key ] = is_numeric( $clean[ $key ] ) ? $clean[ $key ] : '';
		}

		return $clean;
	}

	protected function input_attributes( array $field ) {
		return [
			'min'  => $field['min'],
			'max'  => $field['max'],
			'step' => $field['step'] ?: 'any',
		];
	}

	public function messages() {
		return [
			'invalid_number'   => [ 'label' => __( 'Not a number', 'reform-contact-form' ), 'default' => __( 'Please enter a number.', 'reform-contact-form' ) ],
			'number_too_small' => [ 'label' => __( 'Number too small', 'reform-contact-form' ), 'default' => __( 'This number is too small.', 'reform-contact-form' ) ],
			'number_too_large' => [ 'label' => __( 'Number too large', 'reform-contact-form' ), 'default' => __( 'This number is too large.', 'reform-contact-form' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = Field::validate( $value, $field, $submission );

		if ( $error || '' === $value ) {
			return $error;
		}

		if ( !is_numeric( $value ) ) {
			return 'invalid_number';
		}

		if ( '' !== $field['min'] && (float) $value < (float) $field['min'] ) {
			return 'number_too_small';
		}

		if ( '' !== $field['max'] && (float) $value > (float) $field['max'] ) {
			return 'number_too_large';
		}

		return '';
	}

	public function editor_schema() {
		return [
			'placeholder' => [ 'type' => 'text', 'label' => __( 'Placeholder', 'reform-contact-form' ), 'help' => __( 'A hint shown in the empty field.', 'reform-contact-form' ) ],
			'default'     => [ 'type' => 'text', 'label' => __( 'Default value', 'reform-contact-form' ), 'help' => __( 'The number already in the field when the page opens.', 'reform-contact-form' ) ],
			'min'         => [ 'type' => 'number', 'label' => __( 'Min', 'reform-contact-form' ), 'help' => __( 'The smallest number allowed. Empty: no limit.', 'reform-contact-form' ) ],
			'max'         => [ 'type' => 'number', 'label' => __( 'Max', 'reform-contact-form' ), 'help' => __( 'The largest number allowed. Empty: no limit.', 'reform-contact-form' ) ],
			'step'        => [ 'type' => 'number', 'label' => __( 'Step', 'reform-contact-form' ), 'help' => __( 'How much the arrows add or take away, and which numbers are allowed: 5 allows 0, 5, 10… Empty: any number.', 'reform-contact-form' ) ],
		];
	}
}
