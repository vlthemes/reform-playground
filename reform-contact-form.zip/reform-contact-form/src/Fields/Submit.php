<?php

namespace VLT\Reform\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The submit button: a <button>, or a link (<a>) when the design needs one; reform.js sends the form for the link
 */
class Submit extends Field {
	public function type() {
		return 'submit';
	}

	public function label() {
		return __( 'Submit', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'The send button. The reply shows where [[response]] is, or after the form.', 'reform-contact-form' );
	}

	public function submits() {
		return false;
	}

	protected function own_defaults() {
		return [
			'label' => __( 'Send', 'reform-contact-form' ),
			'tag'   => 'button',
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['tag'] = 'a' === $clean['tag'] ? 'a' : 'button';

		return $clean;
	}

	public function control( array $field, array $ctx ) {
		$attrs = $this->attributes( $field, $ctx );
		$label = '<span class="reform-submit__label">' . esc_html( $field['label'] ?: __( 'Send', 'reform-contact-form' ) ) . '</span>';

		unset( $attrs['name'], $attrs['required'], $attrs['aria-invalid'], $attrs['aria-describedby'] );

		if ( 'a' === $field['tag'] ) {
			return '<a href="#" role="button"' . self::html_attributes( $attrs + [ 'data-reform-submit' => true ] ) . '>' . $label . '</a>';
		}

		return '<button type="submit"' . self::html_attributes( $attrs ) . '>' . $label . '</button>';
	}

	public function editor_schema() {
		return [
			'label' => [ 'type' => 'text', 'label' => __( 'Label', 'reform-contact-form' ), 'help' => __( 'The text on the button.', 'reform-contact-form' ) ],
			'tag'   => [
				'type'    => 'select',
				'label'   => __( 'Element', 'reform-contact-form' ),
				'help'    => __( 'A link sends the form only with JavaScript on. Use it when your design needs an <a>.', 'reform-contact-form' ),
				'options' => [
					'button' => __( 'Button', 'reform-contact-form' ),
					'a'      => __( 'Link', 'reform-contact-form' ),
				],
			],
		];
	}
}
