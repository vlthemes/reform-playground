<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Front\Defaults;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A field type: its settings, its control, how a posted value is read, checked and mailed
 *
 * The control (the input itself, with its name, id, ARIA and validation attributes) is printed here, so no template
 * can lose it; templates/fields/{kind}/{style}/field.php is what goes around it.
 */
abstract class Field {
	/**
	 * Type ID
	 *
	 * @return string
	 */
	abstract public function type();

	/**
	 * Name shown in the editor
	 *
	 * @return string
	 */
	abstract public function label();

	/**
	 * The control's markup
	 *
	 * @param array $field Field settings, with 'name'
	 * @param array $ctx   'id', 'value', 'invalid', 'error_id', 'ids' (name => control ID), 'form'
	 *
	 * @return string
	 */
	abstract public function control( array $field, array $ctx );

	/**
	 * A short tip with an example, shown at the bottom of the editor while the field is selected
	 *
	 * @return string
	 */
	public function tip() {
		return '';
	}

	/**
	 * Icon of the editor's chip and button: a built-in icon's name, or the d of a 24×24 stroke path
	 *
	 * @return string
	 */
	public function icon() {
		return $this->type();
	}

	/**
	 * Where its button goes in the editor: 'main' (the row of field buttons) or 'more' (the More menu after them)
	 *
	 * @return string
	 */
	public function menu() {
		return 'main';
	}

	/**
	 * One line on what it does: under its name in the More menu, and its button's title
	 *
	 * @return string
	 */
	public function summary() {
		return '';
	}

	/**
	 * Template folder shared with similar types (templates/fields/{kind}/), after the type's own
	 *
	 * @return string
	 */
	public function kind() {
		return $this->type();
	}

	/**
	 * Whether the field sends a value
	 *
	 * @return bool
	 */
	public function submits() {
		return true;
	}

	/**
	 * Settings of this type only
	 *
	 * @return array
	 */
	protected function own_defaults() {
		return [];
	}

	/**
	 * Whether the starting value can come from the visit (the URL, the user…): types with a default value setting
	 *
	 * @return bool
	 */
	public function dynamic_default() {
		return isset( $this->editor_schema()['default'] );
	}

	/**
	 * Every setting's default; reform_field_defaults adds settings to any type
	 *
	 * @return array
	 */
	public function defaults() {
		$defaults = [
			'type'        => $this->type(),
			'required'    => false,
			'default'     => '',
			'placeholder' => '',
			'style'       => '',
			'class'       => '',
			'id'          => '',
			'attrs'       => [],
		] + $this->own_defaults();

		if ( $this->dynamic_default() ) {
			$defaults += [ 'default_from' => '', 'default_key' => '' ];
		}

		return (array) apply_filters( 'reform_field_defaults', $defaults, $this->type(), $this ) + $defaults;
	}

	/**
	 * Clean settings; unknown keys are dropped
	 *
	 * @param array $field Settings
	 *
	 * @return array
	 */
	public function sanitize( array $field ) {
		$field += $this->defaults();
		$clean  = [];

		foreach ( $this->defaults() as $key => $default ) {
			$value = $field[ $key ];

			if ( is_bool( $default ) ) {
				$clean[ $key ] = !empty( $value ) && 'false' !== $value;
			} elseif ( is_int( $default ) ) {
				$clean[ $key ] = max( 0, (int) $value );
			} elseif ( is_string( $default ) ) {
				$clean[ $key ] = sanitize_text_field( is_scalar( $value ) ? (string) $value : '' );
			} else {
				$clean[ $key ] = is_array( $value ) ? $value : $default;
			}
		}

		$clean['type']  = $this->type();
		$clean['style'] = sanitize_key( $clean['style'] );
		$clean['class'] = implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', $clean['class'], -1, PREG_SPLIT_NO_EMPTY ) ) );
		$clean['id']    = sanitize_html_class( $clean['id'] );
		$clean['attrs'] = self::sanitize_attrs( $clean['attrs'] );

		if ( isset( $clean['default_from'] ) && !array_key_exists( $clean['default_from'], Defaults::sources() ) ) {
			$clean['default_from'] = '';
		}

		// Plain values of added settings are cleaned above; arrays are the filter's to clean
		return (array) apply_filters( 'reform_field_sanitize', $this->sanitize_own( $clean, $field ), $field, $this->type(), $this );
	}

	/**
	 * Clean what this type adds beyond the plain values
	 *
	 * @param array $clean Settings cleaned so far
	 * @param array $field Settings as given
	 *
	 * @return array
	 */
	protected function sanitize_own( array $clean, array $field ) {
		return $clean;
	}

	/**
	 * Messages this type adds to the Messages tab
	 *
	 * @return array [ key => [ 'label' => string, 'default' => string ] ]
	 */
	public function messages() {
		return [];
	}

	/**
	 * Attributes every control has: name, id, class, ARIA, required, custom ones
	 *
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return array
	 */
	protected function attributes( array $field, array $ctx ) {
		$attrs = [];

		foreach ( $field['attrs'] as $attr ) {
			$attrs[ $attr['name'] ] = $attr['value'];
		}

		return array_merge( $attrs, [
			'name'             => $field['name'],
			'id'               => $ctx['id'],
			'class'            => trim( 'reform-control reform-control--' . $this->type() . ' ' . $field['class'] ),
			'required'         => $field['required'],
			'aria-invalid'     => $ctx['invalid'] ? 'true' : null,
			'aria-describedby' => $ctx['invalid'] ? $ctx['error_id'] : null,
		] );
	}

	/**
	 * Attributes of the field's wrapper the script reads
	 *
	 * @param array $field Field
	 *
	 * @return array
	 */
	public function wrapper_attributes( array $field ) {
		return [];
	}

	/**
	 * Choices of select, checkbox and radio, for templates that print their own
	 *
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return array [ [ 'value', 'label', 'id', 'checked', 'control' ], … ]
	 */
	public function choices( array $field, array $ctx ) {
		return [];
	}

	/**
	 * The posted value, clean
	 *
	 * @param mixed $raw   Posted value (unslashed)
	 * @param array $field Field
	 *
	 * @return mixed
	 */
	public function value( $raw, array $field ) {
		return is_scalar( $raw ) ? sanitize_text_field( (string) $raw ) : '';
	}

	/**
	 * Check a value
	 *
	 * @param mixed      $value      Clean value
	 * @param array      $field      Field
	 * @param Submission $submission Submission
	 *
	 * @return string Message key, '' when valid
	 */
	public function validate( $value, array $field, Submission $submission ) {
		return $field['required'] && self::is_empty( $value ) ? 'required' : '';
	}

	/**
	 * The value as a mail tag prints it
	 *
	 * @param mixed $value Clean value
	 * @param array $field Field
	 * @param bool  $raw   The values themselves ([_raw_name]), not their labels
	 *
	 * @return string
	 */
	public function mail_value( $value, array $field, $raw = false ) {
		return is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : (string) $value;
	}

	/**
	 * The editor's sidebar controls of this type, after the shared ones
	 *
	 * @return array [ key => [ 'type' => toggle|text|textarea|number|select|options|pairs|field|date, 'label' => string, … ] ]
	 */
	public function editor_schema() {
		return [];
	}

	/**
	 * The sidebar controls the editor shows; reform_field_schema adds controls to any type
	 *
	 * @return array
	 */
	final public function schema() {
		$schema = $this->editor_schema();

		// Where the default value may come from, right after it
		if ( $this->dynamic_default() ) {
			$at     = array_search( 'default', array_keys( $schema ), true ) + 1;
			$schema = array_slice( $schema, 0, $at, true ) + [
				'default_from' => [ 'type' => 'select', 'label' => __( 'Fill from', 'reform-contact-form' ), 'options' => Defaults::sources(), 'help' => __( 'Fills the field when the page opens: from a link such as ?name=Ann, the shortcode ([reform id="…" name="Ann"]), the page or the logged-in user. The value above is used when that is empty. On a cached page everyone gets the same value, so leave URL and user values to pages that aren\'t cached.', 'reform-contact-form' ) ],
				'default_key'  => [ 'type' => 'text', 'label' => __( 'Name to read', 'reform-contact-form' ), 'when' => [ 'default_from' => Defaults::NAMED ], 'help' => __( 'The URL parameter, posted field, shortcode attribute or custom field to read. Empty: this field\'s name.', 'reform-contact-form' ) ],
			] + array_slice( $schema, $at, null, true );
		}

		return (array) apply_filters( 'reform_field_schema', $schema, $this->type(), $this );
	}

	/**
	 * Whether a value is empty
	 *
	 * @param mixed $value Value
	 *
	 * @return bool
	 */
	public static function is_empty( $value ) {
		return is_array( $value ) ? !array_filter( $value, static fn( $item ) => '' !== (string) $item ) : '' === trim( (string) $value );
	}

	/**
	 * Attributes as HTML: true prints the name alone, false and null leave it out
	 *
	 * @param array $attrs Attributes
	 *
	 * @return string
	 */
	public static function html_attributes( array $attrs ) {
		$html = '';

		foreach ( $attrs as $name => $value ) {
			if ( null === $value || false === $value || '' === $value && 'value' !== $name ) {
				continue;
			}

			$html .= true === $value ? ' ' . $name : sprintf( ' %s="%s"', $name, esc_attr( (string) $value ) );
		}

		return $html;
	}

	/**
	 * Clean custom attributes: no event handlers, none the control sets itself
	 *
	 * @param mixed $attrs [ [ 'name', 'value' ], … ]
	 *
	 * @return array
	 */
	private static function sanitize_attrs( $attrs ) {
		$clean = [];

		foreach ( (array) $attrs as $attr ) {
			$name = strtolower( trim( (string) ( $attr['name'] ?? '' ) ) );

			if ( preg_match( '/^[a-z_:][a-z0-9_:.-]*$/', $name ) && 0 !== strpos( $name, 'on' ) && !in_array( $name, [ 'name', 'id', 'type', 'value', 'class', 'form', 'style' ], true ) ) {
				$clean[] = [ 'name' => $name, 'value' => sanitize_text_field( (string) ( $attr['value'] ?? '' ) ) ];
			}
		}

		return $clean;
	}
}
