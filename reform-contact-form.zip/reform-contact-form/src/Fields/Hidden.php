<?php

namespace VLT\Reform\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A value sent with the form, not shown
 */
class Hidden extends Field {
	public function type() {
		return 'hidden';
	}

	public function label() {
		return __( 'Hidden', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'Sent with the message, never shown. For example, fill it from the URL parameter utm_source to see where visitors came from.', 'reform-contact-form' );
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['required'] = false;

		return $clean;
	}

	public function control( array $field, array $ctx ) {
		return '<input' . self::html_attributes( [
			'type'  => 'hidden',
			'name'  => $field['name'],
			'id'    => $ctx['id'],
			'value' => is_scalar( $ctx['value'] ) ? (string) $ctx['value'] : '',
		] ) . '>';
	}

	public function editor_schema() {
		return [
			'default' => [ 'type' => 'text', 'label' => __( 'Value', 'reform-contact-form' ), 'help' => __( 'Sent with every message without being shown, such as a campaign name. It goes into mails and entries like any field.', 'reform-contact-form' ) ],
		];
	}
}
