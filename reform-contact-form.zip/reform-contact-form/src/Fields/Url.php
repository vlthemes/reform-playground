<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A web address
 */
class Url extends Text {
	public function type() {
		return 'url';
	}

	public function label() {
		return __( 'URL', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'A web address. Visitors have to start it with http:// or https://.', 'reform-contact-form' );
	}

	protected function input_type() {
		return 'url';
	}

	public function messages() {
		return [
			'invalid_url' => [ 'label' => __( 'Web address isn\'t valid', 'reform-contact-form' ), 'default' => __( 'Please enter a valid web address, starting with https://.', 'reform-contact-form' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		return parent::validate( $value, $field, $submission ) ?: ( '' !== $value && !preg_match( '#^[a-z][a-z0-9+.-]*://[^\s/?.#][^\s]*$#i', $value ) ? 'invalid_url' : '' );
	}
}
