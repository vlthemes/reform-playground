<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A telephone number
 */
class Tel extends Text {
	// Digits and the signs numbers are written with; the same pattern checks it in the browser (escaped for the v flag)
	const PATTERN = '[0-9\(\)#&+*=.\/ \-]{3,}';

	public function type() {
		return 'tel';
	}

	public function label() {
		return __( 'Tel', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'A phone number. Phones open the number keypad for it.', 'reform-contact-form' );
	}

	protected function input_type() {
		return 'tel';
	}

	protected function input_attributes( array $field ) {
		return parent::input_attributes( $field ) + [ 'pattern' => self::PATTERN ];
	}

	public function messages() {
		return [
			'invalid_tel' => [ 'label' => __( 'Phone number isn\'t valid', 'reform-contact-form' ), 'default' => __( 'Please enter a valid phone number.', 'reform-contact-form' ) ],
		];
	}

	public function validate( $value, array $field, Submission $submission ) {
		return parent::validate( $value, $field, $submission ) ?: ( '' !== $value && !preg_match( '/^' . self::PATTERN . '$/', $value ) ? 'invalid_tel' : '' );
	}
}
