<?php

namespace VLT\Reform\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The field types; more through reform_field_types
 *
 *     add_filter( 'reform_field_types', fn( $types ) => $types + [ 'rating' => new My_Rating_Field() ] );
 */
class FieldRegistry {
	const BUILT_IN = [
		Text::class,
		Email::class,
		Url::class,
		Tel::class,
		Number::class,
		Date::class,
		Textarea::class,
		Select::class,
		Checkbox::class,
		Radio::class,
		Acceptance::class,
		Quiz::class,
		File::class,
		Hidden::class,
		Submit::class,
		Output::class,
		Count::class,
	];

	/**
	 * Types, built once
	 *
	 * @var Field[]|null
	 */
	private static $types = null;

	/**
	 * Every type
	 *
	 * @return Field[] [ id => type ]
	 */
	public static function all() {
		if ( null === self::$types ) {
			$types = [];

			foreach ( self::BUILT_IN as $class ) {
				$type                    = new $class();
				$types[ $type->type() ] = $type;
			}

			self::$types = array_filter( (array) apply_filters( 'reform_field_types', $types ), static fn( $type ) => $type instanceof Field );
		}

		return self::$types;
	}

	/**
	 * One type
	 *
	 * @param string $id Type ID
	 *
	 * @return Field|null
	 */
	public static function get( $id ) {
		return self::all()[ $id ] ?? null;
	}
}
