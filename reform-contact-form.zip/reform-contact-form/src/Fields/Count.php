<?php

namespace VLT\Reform\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * How many characters another field has, updated as the visitor types; never sent
 */
class Count extends Field {
	public function type() {
		return 'count';
	}

	public function label() {
		return __( 'Count', 'reform-contact-form' );
	}

	public function menu() {
		return 'more';
	}

	public function summary() {
		return __( 'Counts the characters visitors type in another field', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'Counts the characters in another field. For example, pick the message, give it a max length of 500 and use the format "{left} characters left".', 'reform-contact-form' );
	}

	public function submits() {
		return false;
	}

	protected function own_defaults() {
		return [
			'source' => '',
			'format' => '{count}',
		];
	}

	/**
	 * The text for a number of characters: {count}, {left} (to the max length) and {max}
	 *
	 * @param string $format Format
	 * @param int    $count  Characters typed
	 * @param int    $max    Max length, 0 for none
	 *
	 * @return string
	 */
	public static function text( $format, $count, $max ) {
		return strtr( $format ?: '{count}', [
			'{count}' => $count,
			'{left}'  => $max ? $max - $count : '',
			'{max}'   => $max ?: '',
		] );
	}

	public function control( array $field, array $ctx ) {
		$source = $field['source'];
		$limits = $ctx['form']->fields()[ $source ] ?? [];
		$max    = (int) ( $limits['maxlength'] ?? 0 );
		$min    = (int) ( $limits['minlength'] ?? 0 );
		$value  = $ctx['values'][ $source ] ?? '';
		$count  = is_scalar( $value ) ? mb_strlen( (string) $value ) : 0;
		$state  = $max && $count > $max ? ' is-over' : ( $min && $count && $count < $min ? ' is-under' : '' );

		$attrs = [
			'id'                => $ctx['id'],
			'class'             => trim( 'reform-count' . $state . ' ' . $field['class'] ),
			'for'               => $ctx['ids'][ $source ] ?? null,
			'data-reform-count' => $source,
			'data-format'       => $field['format'] ?: '{count}',
			'data-max'          => $max ?: null,
			'data-min'          => $min ?: null,
		];

		return '<output' . self::html_attributes( $attrs ) . '>' . esc_html( self::text( $field['format'], $count, $max ) ) . '</output>';
	}

	public function editor_schema() {
		return [
			'source' => [ 'type' => 'field', 'label' => __( 'Count of', 'reform-contact-form' ), 'help' => __( 'The field whose characters are counted as visitors type, usually a textarea.', 'reform-contact-form' ) ],
			'format' => [ 'type' => 'text', 'label' => __( 'Format', 'reform-contact-form' ), 'help' => __( '{count} is the characters typed, {left} how many more fit and {max} that field\'s max length. For example: {left} characters left.', 'reform-contact-form' ) ],
		];
	}
}
