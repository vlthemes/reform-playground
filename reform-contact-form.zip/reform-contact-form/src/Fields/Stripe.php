<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Payments\Payments;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A card payment through Stripe, in the form (Stripe's Payment Element)
 */
class Stripe extends Payment {
	public function type() {
		return 'stripe';
	}

	public function label() {
		return __( 'Stripe payment', 'reform-contact-form' );
	}

	public function summary() {
		return __( 'Visitors pay by card before the message goes', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'Visitors pay by card before the message goes. Set the amount, or take it from a field such as a select of plans. Keys go in Settings → Payments.', 'reform-contact-form' );
	}

	protected function own_defaults() {
		return parent::own_defaults() + [
			'pay_label' => __( 'Pay {amount}', 'reform-contact-form' ),
		];
	}

	protected function client( array $field ) {
		return [
			'data-key'   => (string) ( Payments::settings()['stripe_key'] ?? '' ),
			'data-label' => $field['pay_label'],
		];
	}

	public function editor_schema() {
		return parent::editor_schema() + [
			'pay_label' => [ 'type' => 'text', 'label' => __( 'Pay button', 'reform-contact-form' ), 'help' => __( 'The button under the card fields. {amount} is replaced with the amount.', 'reform-contact-form' ) ],
		];
	}
}
