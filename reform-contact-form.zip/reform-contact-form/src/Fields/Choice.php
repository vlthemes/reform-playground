<?php

namespace VLT\Reform\Fields;

use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A field of options: the base of select, checkbox and radio
 *
 * Options are [ [ 'value', 'label' ], … ]; the editor writes them as "value : Label" lines.
 */
abstract class Choice extends Field {
	/**
	 * Whether several options can be picked
	 *
	 * @param array $field Field
	 *
	 * @return bool
	 */
	abstract protected function multiple( array $field );

	protected function own_defaults() {
		return [
			'options' => [
				[ 'value' => 'val1', 'label' => __( 'Option 1', 'reform-contact-form' ) ],
				[ 'value' => 'val2', 'label' => __( 'Option 2', 'reform-contact-form' ) ],
				[ 'value' => 'val3', 'label' => __( 'Option 3', 'reform-contact-form' ) ],
			],
		];
	}

	protected function sanitize_own( array $clean, array $field ) {
		$clean['options'] = self::parse_options( $field['options'] ?? [] );

		return $clean;
	}

	/**
	 * Options from a list or from "value : Label" lines (a line without " : " is both)
	 *
	 * @param array|string $options Options
	 *
	 * @return array
	 */
	public static function parse_options( $options ) {
		if ( is_string( $options ) ) {
			$options = array_map( static function ( $line ) {
				$parts = array_map( 'trim', explode( ' : ', $line, 2 ) );

				return [ 'value' => $parts[0], 'label' => $parts[1] ?? $parts[0] ];
			}, preg_split( '/\R/', $options, -1, PREG_SPLIT_NO_EMPTY ) );
		}

		$clean = [];

		foreach ( (array) $options as $option ) {
			$value = sanitize_text_field( (string) ( $option['value'] ?? '' ) );
			$label = sanitize_text_field( (string) ( $option['label'] ?? '' ) );

			if ( '' !== $value || '' !== $label ) {
				$clean[] = [ 'value' => '' !== $value ? $value : $label, 'label' => '' !== $label ? $label : $value ];
			}
		}

		return $clean;
	}

	public function messages() {
		return [
			'invalid_choice' => [ 'label' => __( 'Option not on the list', 'reform-contact-form' ), 'default' => __( 'Please pick one of the options.', 'reform-contact-form' ) ],
		];
	}

	/**
	 * The values picked: the posted ones, else the default ("val1, val2")
	 *
	 * @param array $field Field
	 * @param array $ctx   Context
	 *
	 * @return string[]
	 */
	protected function selected( array $field, array $ctx ) {
		$value = $ctx['value'];

		if ( !is_array( $value ) ) {
			$value = '' === (string) $value ? [] : array_map( 'trim', explode( ',', (string) $value ) );
		}

		return array_map( 'strval', $value );
	}

	public function value( $raw, array $field ) {
		$values = array_values( array_filter( array_map( static fn( $item ) => is_scalar( $item ) ? sanitize_text_field( (string) $item ) : '', (array) $raw ), 'strlen' ) );

		return $this->multiple( $field ) ? $values : (string) ( $values[0] ?? '' );
	}

	public function validate( $value, array $field, Submission $submission ) {
		$error = parent::validate( $value, $field, $submission );

		if ( $error ) {
			return $error;
		}

		$offered = array_column( $field['options'], 'value' );

		foreach ( (array) $value as $item ) {
			if ( '' !== $item && !in_array( $item, $offered, true ) ) {
				return 'invalid_choice';
			}
		}

		return '';
	}

	public function mail_value( $value, array $field, $raw = false ) {
		$labels = array_column( $field['options'], 'label', 'value' );
		$items  = array_map( static fn( $item ) => $raw ? $item : ( $labels[ $item ] ?? $item ), (array) $value );

		return implode( ', ', $items );
	}

	public function editor_schema() {
		return [
			'options' => [ 'type' => 'options', 'label' => __( 'Options (value : Label)', 'reform-contact-form' ), 'help' => __( 'One option per line. The value goes into [_raw_name] and conditions, the label is what visitors see and what [name] prints. A line without " : " uses the same text for both.', 'reform-contact-form' ) ],
			'default' => [ 'type' => 'text', 'label' => __( 'Default value', 'reform-contact-form' ), 'help' => __( 'The value picked first; several separated by commas.', 'reform-contact-form' ) ],
		];
	}

	/**
	 * Checkbox and radio choices, each an input with its label
	 *
	 * @param array  $field Field
	 * @param array  $ctx   Context
	 * @param string $input checkbox or radio
	 *
	 * @return array
	 */
	protected function inputs( array $field, array $ctx, $input ) {
		$selected = $this->selected( $field, $ctx );
		$base     = $this->attributes( $field, $ctx );
		$choices  = [];

		foreach ( $field['options'] as $i => $option ) {
			$id    = $ctx['id'] . '-' . $i;
			$attrs = array_merge( $base, [
				'type'     => $input,
				'name'     => 'checkbox' === $input ? $field['name'] . '[]' : $field['name'],
				'id'       => $id,
				'value'    => $option['value'],
				'checked'  => in_array( (string) $option['value'], $selected, true ),
				'required' => $this->input_required( $field ),
			] );
			$input_html = '<input' . self::html_attributes( $attrs ) . '>';
			$first      = !empty( $field['label_first'] );

			if ( !empty( $field['label_wrap'] ) ) {
				$label   = '<span class="reform-choice__label">' . esc_html( $option['label'] ) . '</span>';
				$control = '<label class="reform-choice">' . ( $first ? $label . $input_html : $input_html . $label ) . '</label>';
			} else {
				$label   = '<label class="reform-choice__label" for="' . esc_attr( $id ) . '">' . esc_html( $option['label'] ) . '</label>';
				$control = '<span class="reform-choice">' . ( $first ? $label . $input_html : $input_html . $label ) . '</span>';
			}

			$choices[] = [
				'value'   => $option['value'],
				'label'   => $option['label'],
				'id'      => $id,
				'checked' => $attrs['checked'],
				'input'   => $input_html,
				'control' => $control,
			];
		}

		return $choices;
	}

	/**
	 * Whether each input carries required (the browser checks a radio group or a single checkbox itself)
	 *
	 * @param array $field Field
	 *
	 * @return bool
	 */
	protected function input_required( array $field ) {
		return $field['required'];
	}
}
