<?php

namespace VLT\Reform\Fields;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Radio buttons: one option
 */
class Radio extends Choice {
	public function type() {
		return 'radio';
	}

	public function label() {
		return __( 'Radio', 'reform-contact-form' );
	}

	public function tip() {
		return __( 'One of several options. Wrap part of the form in a group to show it only when a certain option is picked.', 'reform-contact-form' );
	}

	public function kind() {
		return 'choices';
	}

	protected function multiple( array $field ) {
		return false;
	}

	protected function own_defaults() {
		return parent::own_defaults() + [
			'label_wrap'  => true,
			'label_first' => false,
			'allow_null'  => false,
		];
	}

	// Without "allow null", the first option is picked when nothing else is
	protected function selected( array $field, array $ctx ) {
		$selected = parent::selected( $field, $ctx );

		if ( !$selected && empty( $field['allow_null'] ) && $field['options'] ) {
			$selected = [ (string) $field['options'][0]['value'] ];
		}

		return $selected;
	}

	public function choices( array $field, array $ctx ) {
		return $this->inputs( $field, $ctx, 'radio' );
	}

	public function control( array $field, array $ctx ) {
		return '<span class="reform-choices" role="radiogroup">' . implode( '', array_column( $this->choices( $field, $ctx ), 'control' ) ) . '</span>';
	}

	public function editor_schema() {
		return parent::editor_schema() + [
			'label_wrap'  => [ 'type' => 'toggle', 'label' => __( 'Wrap each item with a label element', 'reform-contact-form' ), 'help' => __( 'On: each option sits inside its <label>. Off: the <label> comes next to the input. Both can be clicked; pick what your CSS expects.', 'reform-contact-form' ) ],
			'label_first' => [ 'type' => 'toggle', 'label' => __( 'Label before the button', 'reform-contact-form' ), 'help' => __( 'Puts each option\'s text before its button instead of after it.', 'reform-contact-form' ) ],
			'allow_null'  => [ 'type' => 'toggle', 'label' => __( 'Allow none picked', 'reform-contact-form' ), 'help' => __( 'Off: the first option is picked to begin with.', 'reform-contact-form' ) ],
		];
	}
}
