<?php

namespace VLT\Reform\Core;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Narrows a list keyed by ID with the include / exclude lists of the reform_include_* and reform_exclude_* filters
 *
 * The lists hold IDs; * matches any part of one.
 */
class IdList {
	/**
	 * Apply include and exclude lists
	 *
	 * @param array $items   [ id => item ]
	 * @param array $include IDs to keep, in this order ([] = all, in their own order)
	 * @param array $exclude IDs to drop
	 *
	 * @return array
	 */
	public static function apply( array $items, array $include = [], array $exclude = [] ) {
		if ( $include ) {
			$kept = [];

			foreach ( $include as $pattern ) {
				foreach ( $items as $id => $item ) {
					if ( !isset( $kept[ $id ] ) && self::matches( $id, [ $pattern ] ) ) {
						$kept[ $id ] = $item;
					}
				}
			}

			$items = $kept;
		}

		return $exclude ? array_filter( $items, static function ( $id ) use ( $exclude ) {
			return !self::matches( $id, $exclude );
		}, ARRAY_FILTER_USE_KEY ) : $items;
	}

	/**
	 * Whether an ID matches one of the patterns
	 *
	 * @param string|int $id       ID
	 * @param array      $patterns IDs, * as a wildcard
	 *
	 * @return bool
	 */
	public static function matches( $id, array $patterns ) {
		foreach ( $patterns as $pattern ) {
			if ( fnmatch( (string) $pattern, (string) $id ) ) {
				return true;
			}
		}

		return false;
	}
}
