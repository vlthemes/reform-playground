<?php

namespace VLT\Reform\Core;

use VLT\Reform\Admin\Settings;
use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Forms\Form;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The messages a form shows: the general ones and those of its field types
 *
 * A message is the form's own (its Messages tab), else the site's (Settings → Messages), else the built-in text.
 */
class Messages {
	/**
	 * The messages every form has
	 *
	 * @return array [ key => [ 'label' => string, 'default' => string ] ]
	 */
	public static function general() {
		return [
			'success'   => [ 'label' => __( 'Message sent', 'reform-contact-form' ), 'default' => __( 'Thanks, your message has been sent.', 'reform-contact-form' ) ],
			'failed'    => [ 'label' => __( 'Message not sent', 'reform-contact-form' ), 'default' => __( 'Your message couldn\'t be sent. Please try again later.', 'reform-contact-form' ) ],
			'invalid'   => [ 'label' => __( 'Fields need fixing', 'reform-contact-form' ), 'default' => __( 'Some fields need a second look. Please check them and try again.', 'reform-contact-form' ) ],
			'spam'      => [ 'label' => __( 'Looks like spam', 'reform-contact-form' ), 'default' => __( 'Your message couldn\'t be sent. Please try again later.', 'reform-contact-form' ) ],
			'required'  => [ 'label' => __( 'Required field left empty', 'reform-contact-form' ), 'default' => __( 'Please fill in this field.', 'reform-contact-form' ) ],
			'too_long'  => [ 'label' => __( 'Too long', 'reform-contact-form' ), 'default' => __( 'This is longer than allowed.', 'reform-contact-form' ) ],
			'too_short' => [ 'label' => __( 'Too short', 'reform-contact-form' ), 'default' => __( 'This is shorter than needed.', 'reform-contact-form' ) ],
		];
	}

	/**
	 * Messages of the form's settings, listed while that setting is on
	 *
	 * @return array [ setting => [ key => [ 'label', 'default' ] ] ]
	 */
	public static function of_settings() {
		return [
			'subscribers_only' => [
				'login_required' => [ 'label' => __( 'Visitor not logged in', 'reform-contact-form' ), 'default' => __( 'Please log in to use this form.', 'reform-contact-form' ) ],
			],
		];
	}

	/**
	 * Every message: the general ones, then each field type's
	 *
	 * @param string[]|null $types Only these field types (null: all)
	 *
	 * @return array [ key => [ 'label' => string, 'default' => string ] ]
	 */
	public static function all( $types = null ) {
		static $cache = [];

		$key = null === $types ? '*' : implode( ',', $types );

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$messages = self::general();

		// The settings' messages are listed for a form only while their setting is on (for_form())
		if ( null === $types ) {
			foreach ( self::of_settings() as $setting_messages ) {
				$messages += $setting_messages;
			}
		}

		foreach ( FieldRegistry::all() as $id => $type ) {
			if ( null === $types || in_array( $id, $types, true ) ) {
				$messages += $type->messages();
			}
		}

		$cache[ $key ] = (array) apply_filters( 'reform_messages', $messages, $types );

		return $cache[ $key ];
	}

	/**
	 * The messages of a form: the general ones and those of the field types it uses
	 *
	 * @param Form $form Form
	 *
	 * @return array [ key => text ]
	 */
	public static function for_form( Form $form ) {
		$types = array_values( array_unique( wp_list_pluck( $form->fields(), 'type' ) ) );
		$saved = (array) $form->config()['messages'];
		$texts = [];

		$keys = array_keys( self::all( $types ) );

		foreach ( self::of_settings() as $setting => $setting_messages ) {
			if ( !empty( $form->config()['settings'][ $setting ] ) ) {
				$keys = array_merge( $keys, array_keys( $setting_messages ) );
			}
		}

		foreach ( $keys as $key ) {
			$texts[ $key ] = isset( $saved[ $key ] ) && '' !== $saved[ $key ] ? $saved[ $key ] : self::default( $key );
		}

		return $texts;
	}

	/**
	 * One message of a form
	 *
	 * @param Form   $form Form
	 * @param string $key  Key
	 *
	 * @return string
	 */
	public static function get( Form $form, $key ) {
		$saved = (array) $form->config()['messages'];

		return (string) apply_filters( 'reform_message', $saved[ $key ] ?? self::default( $key ), $key, $form );
	}

	/**
	 * Default text of a message
	 *
	 * @param string $key Key
	 *
	 * @return string
	 */
	public static function default( $key ) {
		$site = self::site();

		return isset( $site[ $key ] ) && '' !== $site[ $key ] ? (string) $site[ $key ] : self::built_in( $key );
	}

	/**
	 * The text a message ships with
	 *
	 * @param string $key Key
	 *
	 * @return string
	 */
	public static function built_in( $key ) {
		return (string) ( self::all()[ $key ]['default'] ?? '' );
	}

	/**
	 * The site's own texts (Settings → Messages), read once
	 *
	 * @return array [ key => text ]
	 */
	private static function site() {
		static $site = null;

		if ( null === $site ) {
			$saved = get_option( Settings::OPTION, [] );
			$site  = is_array( $saved['messages'] ?? null ) ? array_map( 'strval', $saved['messages'] ) : [];
		}

		return $site;
	}

	/**
	 * The fields of Settings → Messages: every message, in groups (general, then each field type's)
	 *
	 * @return array [ 'groups' => [ id => [ 'title' ] ], 'fields' => [ key => field ] ]
	 */
	public static function settings_fields() {
		$groups = [ 'general' => [ 'title' => __( 'Every form', 'reform-contact-form' ) ] ];
		$fields = [];
		$add    = static function ( $group, array $messages ) use ( &$fields ) {
			foreach ( $messages as $key => $message ) {
				if ( !isset( $fields[ $key ] ) ) {
					$fields[ $key ] = [
						'type'        => 'text',
						'group'       => $group,
						'label'       => $message['label'],
						'default'     => $message['default'],
						'placeholder' => $message['default'],
					];
				}
			}
		};

		$add( 'general', self::general() );

		foreach ( FieldRegistry::all() as $id => $type ) {
			$own = array_diff_key( $type->messages(), $fields );

			if ( $own ) {
				$groups[ $id ] = [ 'title' => $type->label() ];
				$add( $id, $own );
			}
		}

		foreach ( self::of_settings() as $setting => $messages ) {
			$groups[ $setting ] = [ 'title' => __( 'Logged-in users only', 'reform-contact-form' ) ];
			$add( $setting, $messages );
		}

		return [ 'groups' => $groups, 'fields' => $fields ];
	}
}
