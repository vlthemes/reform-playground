<?php

namespace VLT\Reform\Core;

use VLT\Reform\Admin\Admin;
use VLT\Reform\Admin\Preview;
use VLT\Reform\Admin\ReviewNotice;
use VLT\Reform\Admin\Transfer;
use VLT\Reform\Api\Abilities;
use VLT\Reform\Api\Describe;
use VLT\Reform\Api\Rest;
use VLT\Reform\Entries\Entries;
use VLT\Reform\Front\Renderer;
use VLT\Reform\Front\Shortcode;
use VLT\Reform\Integrations\Block;
use VLT\Reform\Integrations\Elementor;
use VLT\Reform\Integrations\Cf7;
use VLT\Reform\Integrations\Ocdi;
use VLT\Reform\Integrations\Webhooks;
use VLT\Reform\Integrations\Widget;
use VLT\Reform\Integrations\WPBakery;
use VLT\Reform\Spam\Spam;
use VLT\Reform\Submission\NoScript;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Starts the parts
 */
class Reform {
	/**
	 * Instance
	 *
	 * @var Reform|null
	 */
	private static $instance = null;

	/**
	 * Instance
	 *
	 * @return Reform
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		PostType::register();
		Entries::init();
		Spam::init();
		Webhooks::init();
		Block::init();
		Elementor\Integration::init();
		WPBakery\Integration::init();
		Widget::init();
		Cf7::init();
		Transfer::init();
		Ocdi::init();
		Abilities::init();
		Describe::init();
		Shortcode::init();
		Renderer::init();
		Rest::init();
		NoScript::init();
		Preview::init();

		// Asked once, after the first message: listens on the front end, shows in the admin
		ReviewNotice::init();

		// Edit links of forms open the editor, from the admin bar too
		add_filter( 'get_edit_post_link', [ Admin::class, 'edit_link' ], 10, 2 );

		if ( is_admin() ) {
			Admin::init();
		}

		do_action( 'reform_init' );
	}
}
