<?php

namespace VLT\Reform\Core;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The form post type: the template in post_content, the rest in _reform_config
 */
class PostType {
	const NAME = 'reform_form';

	/**
	 * Register
	 */
	public static function register() {
		register_post_type( self::NAME, [
			'labels'          => [
				'name'               => __( 'Contact Forms', 'reform-contact-form' ),
				'singular_name'      => __( 'Contact Form', 'reform-contact-form' ),
				'add_new'            => __( 'Add New Form', 'reform-contact-form' ),
				'add_new_item'       => __( 'Add New Form', 'reform-contact-form' ),
				'edit_item'          => __( 'Edit Form', 'reform-contact-form' ),
				'search_items'       => __( 'Search Forms', 'reform-contact-form' ),
				'not_found'          => __( 'No forms yet. Add one and it starts with name, email, subject and message fields.', 'reform-contact-form' ),
				'not_found_in_trash' => __( 'No forms in the trash.', 'reform-contact-form' ),
			],
			'public'          => false,
			// WordPress's list screen; the Contact Form menu links to it and editing opens Reform's editor (Admin)
			'show_ui'         => true,
			'show_in_menu'    => false,
			'show_in_rest'    => false,
			'rewrite'         => false,
			'query_var'       => false,
			'can_export'      => true,
			'capability_type' => 'page',
			'map_meta_cap'    => true,
			'supports'        => [ 'title', 'editor', 'revisions' ],
		] );
	}
}
