<?php

namespace VLT\Reform\Forms;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Beautify HTML on the server: the same formatter as the editor's Beautify button (assets/src/editor/beautify.js),
 * for markup Reform writes itself. Block elements and [[group:…]] … [[/group]] each on their lines with their content
 * indented, unless it's inline and fits on one line. Inline content too long for a line breaks only where it already
 * has spaces, so the page looks the same; an empty line stays (one at most); <pre>, <textarea>, <script> and <style>
 * as written. Change both together.
 */
class Beautify {
	const WIDTH = 100;
	const BLOCK = [ 'address', 'article', 'aside', 'blockquote', 'details', 'dialog', 'dd', 'div', 'dl', 'dt', 'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hgroup', 'hr', 'legend', 'li', 'main', 'nav', 'ol', 'optgroup', 'option', 'p', 'pre', 'script', 'section', 'style', 'summary', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'tr', 'ul' ];
	// Inline elements whose content can start and end on lines of its own
	const BOX   = [ 'button', 'select' ];
	const VOID  = [ 'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr' ];
	const RAW   = [ 'pre', 'textarea', 'script', 'style' ];
	const TOKEN = '/<!--[\s\S]*?-->|<\/?[a-zA-Z][^>"\']*(?:(?:"[^"]*"|\'[^\']*\')[^>"\']*)*>|\[\[\/?group(?::[^\]]*)?\]\]/';

	/**
	 * Indent a form's markup
	 *
	 * @param string $html   Markup
	 * @param int    $spaces Spaces per level
	 *
	 * @return string
	 */
	public static function html( $html, $spaces = 2 ) {
		$out      = [];
		$blank    = false;
		$block    = null;
		$wrap     = null;
		$children = null;

		$push = static function ( $depth, $line ) use ( &$out, &$blank, $spaces ) {
			if ( $blank && $out ) {
				$out[] = '';
			}

			$blank = false;
			$out[] = str_repeat( ' ', $spaces * $depth ) . $line;
		};

		$fits = static fn( $depth, $line ) => $spaces * $depth + mb_strlen( $line, 'UTF-8' ) <= self::WIDTH;

		$children = static function ( array $nodes, $depth ) use ( &$blank, &$block, &$wrap, $push, $fits ) {
			// Inline nodes with no space between them: they stay on one line
			$line    = [];
			$started = false;

			$flush = static function () use ( &$line, &$started, &$wrap, $push, $fits, $depth ) {
				$text = trim( implode( '', array_map( [ __CLASS__, 'flat' ], $line ) ) );

				if ( '' !== $text ) {
					if ( 1 === count( $line ) && !is_string( $line[0] ) && !$fits( $depth, $text ) && self::opens( $line[0] ) ) {
						$wrap( $line[0], $depth );
					} else {
						$push( $depth, $text );
					}

					$started = true;
				}

				$line = [];
			};

			// A space: the line can break there; two line breaks in it keep an empty line
			$space = static function ( $str ) use ( &$blank, &$started, $flush ) {
				$flush();
				$blank = $blank || ( $started && substr_count( $str, "\n" ) > 1 );
			};

			foreach ( $nodes as $node ) {
				if ( is_string( $node ) ) {
					foreach ( preg_split( '/(\s*\n\s*)/', $node, -1, PREG_SPLIT_DELIM_CAPTURE ) as $i => $part ) {
						if ( $i % 2 ) {
							$space( $part );
							continue;
						}

						preg_match( '/^(\s*)([\s\S]*?)(\s*)\z/', $part, $m );

						if ( '' !== $m[1] ) {
							$space( $m[1] );
						}

						if ( '' !== $m[2] ) {
							$line[] = $m[2];
						}

						if ( '' !== $m[3] ) {
							$space( $m[3] );
						}
					}
				} elseif ( self::inline( $node ) ) {
					$line[] = $node;
				} else {
					$flush();
					$block( $node, $depth );
					$started = true;
				}
			}

			$flush();
		};

		$wrap = static function ( $node, $depth ) use ( &$blank, &$children, $push ) {
			$push( $depth, $node->open );
			$children( $node->children, $depth + 1 );
			$blank = false;

			if ( '' !== $node->close ) {
				$push( $depth, $node->close );
			}
		};

		$block = static function ( $node, $depth ) use ( $wrap, $push, $fits ) {
			if ( isset( $node->comment ) ) {
				$push( $depth, trim( $node->comment ) );
			} elseif ( isset( $node->raw ) ) {
				$push( $depth, $node->open . $node->raw . $node->close );
			} else {
				$line = $node->open . trim( implode( '', array_map( [ __CLASS__, 'flat' ], $node->children ) ) ) . $node->close;

				// Inline only and short: one line
				if ( 'group' !== $node->name && self::all_inline( $node->children ) && $fits( $depth, $line ) ) {
					$push( $depth, $line );
				} else {
					$wrap( $node, $depth );
				}
			}
		};

		$children( self::parse( (string) $html )->children, 0 );

		return implode( "\n", $out );
	}

	/**
	 * The markup as a tree: objects { open, name, close, children } for elements and groups, strings for text
	 *
	 * @param string $html Markup
	 *
	 * @return object
	 */
	private static function parse( $html ) {
		$root  = (object) [ 'name' => '', 'children' => [] ];
		$stack = [ $root ];
		$lower = strtolower( $html );
		$at    = 0;

		$text = static function ( $parent, $str ) {
			if ( '' !== $str ) {
				$parent->children[] = $str;
			}
		};

		while ( preg_match( self::TOKEN, $html, $match, PREG_OFFSET_CAPTURE, $at ) ) {
			[ $token, $index ] = $match[0];
			$parent            = end( $stack );

			$text( $parent, (string) substr( $html, $at, $index - $at ) );
			$at = $index + strlen( $token );

			if ( 0 === strpos( $token, '<!--' ) ) {
				$parent->children[] = (object) [ 'comment' => $token ];
				continue;
			}

			$group   = 0 === strpos( $token, '[[' );
			$closing = 0 === strpos( $token, '</' ) || 0 === strpos( $token, '[[/' );
			$name    = 'group';

			if ( !$group ) {
				preg_match( '/^<\/?([a-zA-Z][\w-]*)/', $token, $tag );
				$name = strtolower( $tag[1] );
			}

			if ( $closing ) {
				// Back to the element it closes; a stray closing tag stays where it is
				for ( $open = count( $stack ) - 1; $open > 0 && $stack[ $open ]->name !== $name; $open-- );

				if ( $open > 0 ) {
					$stack = array_slice( $stack, 0, $open + 1 );
					array_pop( $stack )->close = $token;
				} else {
					$text( $parent, $token );
				}

				continue;
			}

			$node = (object) [ 'open' => $token, 'name' => $name, 'close' => '', 'children' => [] ];

			$parent->children[] = $node;

			if ( in_array( $name, self::RAW, true ) ) {
				// Its content as written, up to its closing tag
				$end  = strpos( $lower, '</' . $name, $at );
				$gt   = false === $end ? false : strpos( $html, '>', $end );
				$stop = false === $gt ? strlen( $html ) : $gt + 1;

				$node->raw   = (string) substr( $html, $at, ( false === $end ? strlen( $html ) : $end ) - $at );
				$node->close = false === $end ? '' : (string) substr( $html, $end, $stop - $end );
				$at          = $stop;
			} elseif ( !in_array( $name, self::VOID, true ) && '/>' !== substr( $token, -2 ) ) {
				$stack[] = $node;
			}
		}

		$text( end( $stack ), (string) substr( $html, $at ) );

		return $root;
	}

	/**
	 * Whether a node stays in the text's flow
	 *
	 * @param string|object $node Node
	 *
	 * @return bool
	 */
	private static function inline( $node ) {
		return is_string( $node ) || ( !empty( $node->name ) && 'group' !== $node->name && !in_array( $node->name, self::BLOCK, true ) && self::all_inline( $node->children ) );
	}

	/**
	 * Whether all the nodes are inline
	 *
	 * @param array $nodes Nodes
	 *
	 * @return bool
	 */
	private static function all_inline( array $nodes ) {
		foreach ( $nodes as $node ) {
			if ( !self::inline( $node ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Whether an inline element's content can go on lines of its own: a box, or spaces at both its ends already
	 *
	 * @param object $node Element
	 *
	 * @return bool
	 */
	private static function opens( $node ) {
		$first = $node->children[0] ?? null;
		$last  = $node->children ? $node->children[ count( $node->children ) - 1 ] : null;

		return in_array( $node->name, self::BOX, true ) || ( is_string( $first ) && preg_match( '/^\s/', $first ) && is_string( $last ) && preg_match( '/\s\z/', $last ) );
	}

	/**
	 * An inline node on one line, its spaces collapsed
	 *
	 * @param string|object $node Node
	 *
	 * @return string
	 */
	private static function flat( $node ) {
		if ( is_string( $node ) ) {
			return (string) preg_replace( '/\s+/', ' ', $node );
		}

		return $node->open . ( $node->raw ?? implode( '', array_map( [ __CLASS__, 'flat' ], $node->children ) ) ) . $node->close;
	}
}
