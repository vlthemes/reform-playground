<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\Assets;
use VLT\Reform\Forms\Form;
use VLT\Reform\Front\Renderer;
use VLT\Reform\Front\StyleManager;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The editor's Visual view: the unsaved form on a front-end page, with the theme's styles but no header or footer
 *
 * The editor posts the form into an iframe; nothing is sent from it.
 */
class Preview {
	const QUERY_VAR = 'reform-preview';

	const NONCE = 'reform-preview';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'template_redirect', [ __CLASS__, 'render' ], 0 );
	}

	/**
	 * Address of the preview
	 *
	 * @return string
	 */
	public static function url() {
		return add_query_arg( self::QUERY_VAR, '1', home_url( '/' ) );
	}

	/**
	 * Print the preview page
	 */
	public static function render() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the nonce is checked below
		if ( empty( $_GET[ self::QUERY_VAR ] ) ) {
			return;
		}

		if ( !current_user_can( Admin::CAPABILITY ) || !isset( $_POST['_wpnonce'] ) || !wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), self::NONCE ) ) {
			wp_die( esc_html__( 'This view has expired. Reload the editor.', 'reform-contact-form' ), '', [ 'response' => 403 ] );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Form::make() sanitizes it
		$data = json_decode( wp_unslash( (string) ( $_POST['data'] ?? '' ) ), true );
		$data = is_array( $data ) ? $data : [];
		$form = Form::make( (int) ( $data['id'] ?? 0 ), (string) ( $data['title'] ?? '' ), (string) ( $data['template'] ?? '' ), (array) ( $data['config'] ?? [] ) );

		show_admin_bar( false );
		add_filter( 'reform_form_attributes', static fn( $attrs ) => $attrs + [ 'data-reform-preview' => __( 'All good. Forms aren\'t sent from the preview.', 'reform-contact-form' ) ] );

		// Rendered before wp_head() so its assets land in <head>
		$html = Renderer::render( $form );

		Assets::enqueue( 'reform-preview' );

		echo StyleManager::render_template( 'preview/page.php', [ 'html' => $html, 'form' => $form ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered template, escaped inside
		exit;
	}
}
