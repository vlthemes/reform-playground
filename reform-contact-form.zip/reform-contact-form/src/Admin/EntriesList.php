<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\PostType;
use VLT\Reform\Entries\Entries;
use VLT\Reform\Entries\Export;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form → Entries: WordPress's list of entries, with their email and form, a form filter, unread ones in bold
 * and a CSV export
 */
class EntriesList {
	const LIST_PAGE = 'edit.php?post_type=' . Entries::POST_TYPE;

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'manage_' . Entries::POST_TYPE . '_posts_columns', [ __CLASS__, 'columns' ] );
		add_action( 'manage_' . Entries::POST_TYPE . '_posts_custom_column', [ __CLASS__, 'column' ], 10, 2 );
		add_filter( 'post_row_actions', [ __CLASS__, 'row_actions' ], 10, 2 );
		add_filter( 'post_class', [ __CLASS__, 'row_class' ], 10, 3 );
		add_action( 'restrict_manage_posts', [ __CLASS__, 'filter' ] );
		add_action( 'pre_get_posts', [ __CLASS__, 'query' ] );
		add_filter( 'bulk_actions-edit-' . Entries::POST_TYPE, [ __CLASS__, 'bulk_actions' ] );
		add_filter( 'views_edit-' . Entries::POST_TYPE, [ __CLASS__, 'views' ] );
	}

	/**
	 * The menu entry, with the unread count
	 */
	public static function menu() {
		$unread = Entries::unread();
		$label  = __( 'Entries', 'reform-contact-form' ) . ( $unread ? ' <span class="awaiting-mod count-' . $unread . '"><span class="pending-count">' . number_format_i18n( $unread ) . '</span></span>' : '' );

		add_submenu_page( Admin::LIST_PAGE, __( 'Entries', 'reform-contact-form' ), $label, Admin::CAPABILITY, self::LIST_PAGE );
	}

	/**
	 * Columns: the entry, its email, its form, the date
	 *
	 * @param array $columns Columns
	 *
	 * @return array
	 */
	public static function columns( $columns ) {
		return [
			'cb'           => $columns['cb'] ?? '',
			'title'        => __( 'Entry', 'reform-contact-form' ),
			'reform_email' => __( 'Email', 'reform-contact-form' ),
			'reform_form'  => __( 'Form', 'reform-contact-form' ),
			'date'         => $columns['date'] ?? __( 'Date', 'reform-contact-form' ),
		];
	}

	/**
	 * A column's cell
	 *
	 * @param string $column  Column
	 * @param int    $post_id Entry ID
	 */
	public static function column( $column, $post_id ) {
		if ( 'reform_email' === $column ) {
			$email = Entries::email( Entries::data( $post_id ) );

			echo $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '<span aria-hidden="true">—</span>';

			if ( get_post_meta( $post_id, '_reform_mail_failed', true ) ) {
				echo '<span class="reform-entry-flag">' . esc_html__( 'Mail not sent', 'reform-contact-form' ) . '</span>';
			}
		} elseif ( 'reform_form' === $column ) {
			$form = (int) wp_get_post_parent_id( $post_id );

			if ( PostType::NAME === get_post_type( $form ) ) {
				printf( '<a href="%s">%s</a>', esc_url( add_query_arg( 'reform_form', $form, admin_url( self::LIST_PAGE ) ) ), esc_html( get_the_title( $form ) ) );
			} else {
				echo '<span class="reform-entry-flag">' . esc_html__( 'Form deleted', 'reform-contact-form' ) . '</span>';
			}
		}
	}

	/**
	 * An entry's row: View and Trash
	 *
	 * @param array    $actions Actions
	 * @param \WP_Post $post    Post
	 *
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( Entries::POST_TYPE !== $post->post_type ) {
			return $actions;
		}

		$keep = array_intersect_key( $actions, array_flip( [ 'trash', 'untrash', 'delete' ] ) );

		return 'trash' === $post->post_status ? $keep : [ 'view' => '<a href="' . esc_url( EntryView::url( $post->ID ) ) . '">' . esc_html__( 'View', 'reform-contact-form' ) . '</a>' ] + $keep;
	}

	/**
	 * Unread rows stand out
	 *
	 * @param array $classes Classes
	 * @param array $class   Extra classes asked for
	 * @param int   $post_id Post ID
	 *
	 * @return array
	 */
	public static function row_class( $classes, $class, $post_id ) {
		if ( is_admin() && Entries::POST_TYPE === get_post_type( $post_id ) && get_post_meta( $post_id, '_reform_unread', true ) ) {
			$classes[] = 'reform-unread';
		}

		return $classes;
	}

	/**
	 * The form filter and the export button over the list
	 *
	 * @param string $post_type Post type of the list
	 */
	public static function filter( $post_type ) {
		if ( Entries::POST_TYPE !== $post_type ) {
			return;
		}

		$current = absint( $_GET['reform_form'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a list filter
		$forms   = get_posts( [ 'post_type' => PostType::NAME, 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ] );
		?>
		<label class="screen-reader-text" for="reform-entries-form"><?php esc_html_e( 'Filter by form', 'reform-contact-form' ); ?></label>
		<select name="reform_form" id="reform-entries-form">
			<option value="0"><?php esc_html_e( 'All forms', 'reform-contact-form' ); ?></option>
			<?php foreach ( $forms as $form ) : ?>
				<option value="<?php echo esc_attr( $form->ID ); ?>" <?php selected( $current, $form->ID ); ?>><?php echo esc_html( $form->post_title ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php
		add_action( 'manage_posts_extra_tablenav', static function ( $which ) use ( $current ) {
			if ( 'top' === $which ) {
				printf( '<a class="button" href="%s">%s</a>', esc_url( Export::url( $current ) ), esc_html__( 'Export CSV', 'reform-contact-form' ) );
			}
		} );
	}

	/**
	 * The list of one form's entries
	 *
	 * @param \WP_Query $query Query
	 */
	public static function query( $query ) {
		if ( !is_admin() || !$query->is_main_query() || Entries::POST_TYPE !== $query->get( 'post_type' ) ) {
			return;
		}

		$form = absint( $_GET['reform_form'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a list filter

		if ( $form ) {
			$query->set( 'post_parent', $form );
		}
	}

	/**
	 * Bulk actions: no Edit (entries aren't edited)
	 *
	 * @param array $actions Actions
	 *
	 * @return array
	 */
	public static function bulk_actions( $actions ) {
		unset( $actions['edit'] );

		return $actions;
	}

	/**
	 * Views: no "Mine" (visitors send entries)
	 *
	 * @param array $views Views
	 *
	 * @return array
	 */
	public static function views( $views ) {
		unset( $views['mine'] );

		return $views;
	}
}
