<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\PostType;
use VLT\Reform\Entries\Entries;
use VLT\Reform\Submission\Submission;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A wordpress.org review, asked once per site: after a form's first real message, on the Contact
 * Forms and Entries lists. Either answer ends it.
 */
class ReviewNotice {
	/**
	 * '' = not yet, 'due' = ask, 'done' = asked
	 */
	const OPTION = 'reform_review';
	const ACTION = 'reform_review';
	const URL    = 'https://wordpress.org/support/plugin/reform-contact-form/reviews/#new-post';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'reform_submitted', [ __CLASS__, 'submitted' ] );
		add_action( 'admin_notices', [ __CLASS__, 'render' ] );
		add_action( 'admin_post_' . self::ACTION, [ __CLASS__, 'handle' ] );
	}

	/**
	 * A message that went through (not a test): due
	 *
	 * @param Submission $submission Submission
	 */
	public static function submitted( Submission $submission ) {
		if ( !get_option( self::OPTION ) && 'success' === $submission->status() && !$submission->is_demo() ) {
			update_option( self::OPTION, 'due', false );
		}
	}

	/**
	 * The notice, on the lists of forms and entries
	 */
	public static function render() {
		$screen = get_current_screen();

		if ( 'due' !== get_option( self::OPTION ) || !current_user_can( Admin::CAPABILITY ) || !$screen || 'edit' !== $screen->base
			|| !in_array( $screen->post_type, [ PostType::NAME, Entries::POST_TYPE ], true ) ) {
			return;
		}

		$link = static fn( $answer ) => wp_nonce_url( add_query_arg( [ 'action' => self::ACTION, 'answer' => $answer ], admin_url( 'admin-post.php' ) ), self::ACTION );
		?>
		<div class="notice notice-info reform-review">
			<span class="reform-review__logo" aria-hidden="true"><?php echo Admin::icon( 'logo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?></span>
			<div class="reform-review__body">
				<span class="reform-review__stars" aria-hidden="true"><?php echo str_repeat( '<span class="dashicons dashicons-star-filled"></span>', 5 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed markup ?></span>
				<p><strong><?php esc_html_e( 'Your form got its first message!', 'reform-contact-form' ); ?></strong></p>
				<p><?php esc_html_e( 'If ReForm helps you, a review on WordPress.org helps others find it. It takes a minute.', 'reform-contact-form' ); ?></p>
				<p class="reform-review__actions">
					<a class="button button-primary" href="<?php echo esc_url( $link( 'review' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Leave a review', 'reform-contact-form' ); ?></a>
					<a class="button" href="<?php echo esc_url( $link( 'no' ) ); ?>"><?php esc_html_e( 'No, thanks', 'reform-contact-form' ); ?></a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * An answer: either one ends it; "Leave a review" goes on to the review form
	 */
	public static function handle() {
		check_admin_referer( self::ACTION );

		if ( !current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'Sorry, you can\'t do that.', 'reform-contact-form' ), 403 );
		}

		update_option( self::OPTION, 'done', false );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- checked above
		if ( 'review' === sanitize_key( wp_unslash( $_GET['answer'] ?? '' ) ) ) {
			wp_redirect( self::URL ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- wordpress.org
			exit;
		}

		wp_safe_redirect( wp_get_referer() ?: Admin::url() );
		exit;
	}
}
