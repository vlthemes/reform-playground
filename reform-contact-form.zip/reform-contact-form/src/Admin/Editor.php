<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\Messages;
use VLT\Reform\Fields\FieldRegistry;
use VLT\Reform\Forms\Form;
use VLT\Reform\Forms\Places;
use VLT\Reform\Front\StyleManager;
use VLT\Reform\Mail\MailTags;
use VLT\Reform\Spam\Captcha;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The form editor: a React app (assets/src/editor) on Contact Form → Contact Forms → a form
 */
class Editor {
	// Types whose "required" is their own business, not a setting
	const NO_REQUIRED = [ 'hidden', 'submit', 'output', 'count', 'acceptance', 'quiz', 'stripe', 'paypal' ];

	/**
	 * The screen: the app mounts here
	 *
	 * @param Form $form Form
	 */
	public static function render( Form $form ) {
		?>
		<div class="wrap reform-editor-wrap">
			<h1 class="screen-reader-text"><?php echo esc_html( $form->title() ); ?></h1>
			<hr class="wp-header-end">
			<div id="reform-editor"><p class="reform-editor-loading"><?php esc_html_e( 'Loading the editor…', 'reform-contact-form' ); ?></p></div>
		</div>
		<?php
	}

	/**
	 * Every message with its label and the text it has when the form doesn't change it (the site's, else the built-in)
	 *
	 * @return array [ key => [ 'label', 'default' ] ]
	 */
	private static function messages() {
		$messages = Messages::all();

		foreach ( $messages as $key => $message ) {
			$messages[ $key ]['default'] = Messages::default( $key );
		}

		return $messages;
	}

	/**
	 * The captchas Settings → Spam runs on every form, with their logos
	 *
	 * @return array [ id => [ 'label', 'logo' ] ]
	 */
	private static function captchas() {
		$captchas = [];

		foreach ( Captcha::available() as $id => $label ) {
			$captchas[ $id ] = [ 'label' => $label, 'logo' => Captcha::logo( $id ) ];
		}

		return $captchas;
	}

	/**
	 * What the app reads (window.reformEditor)
	 *
	 * @param Form $form Form
	 *
	 * @return array
	 */
	public static function script_data( Form $form ) {
		$types = [];

		foreach ( FieldRegistry::all() as $id => $type ) {
			$types[] = [
				'type'     => $id,
				'label'    => $type->label(),
				'tip'      => $type->tip(),
				'icon'     => $type->icon(),
				/**
				 * Where a type's button goes in the editor: 'main' (the row of field buttons) or 'more' (the More menu)
				 *
				 * @param string $menu Menu
				 * @param string $id   Type
				 * @param Field  $type Type
				 */
				'menu'     => 'more' === apply_filters( 'reform_field_menu', $type->menu(), $id, $type ) ? 'more' : 'main',
				'summary'  => $type->summary(),
				'defaults' => $type->defaults(),
				'schema'   => (object) $type->schema(),
				'required' => !in_array( $id, self::NO_REQUIRED, true ),
				'submits'  => $type->submits(),
				'styles'   => (object) StyleManager::styles( 'fields', $id ),
				'messages' => array_keys( $type->messages() ),
			];
		}

		$config = $form->config();

		foreach ( [ 'fields', 'groups', 'messages' ] as $key ) {
			$config[ $key ] = (object) $config[ $key ];
		}

		return (array) apply_filters( 'reform_editor_data', [
			'form'         => [
				'id'          => $form->id(),
				'hash'        => $form->hash(),
				'title'       => $form->title(),
				'description' => $form->description(),
				'status'      => $form->status(),
				'template'    => $form->template(),
				'config'      => $config,
			],
			'types'        => $types,
			'formStyles'   => (object) StyleManager::styles( 'form' ),
			'messages'     => (object) self::messages(),
			'general'      => array_keys( Messages::general() ),
			'settingMessages' => array_map( 'array_keys', Messages::of_settings() ),
			'specialTags'  => MailTags::specials(),
			'listUrl'      => Admin::url(),
			'settingsUrl'  => Settings::url(),
			// Webhooks send messages off the site: administrators only (Config::save() keeps them for the others)
			'canWebhooks'  => current_user_can( 'manage_options' ),
			// Where WordPress connects AI services (7.0+), for those who may change it
			'connectorsUrl' => current_user_can( 'manage_options' ) && file_exists( ABSPATH . 'wp-admin/options-connectors.php' ) ? admin_url( 'options-connectors.php' ) : '',
			// Set in wp-config.php: on for every form, the form's own toggle can't turn them off
			'testMode'     => defined( 'REFORM_TEST_MODE' ) && REFORM_TEST_MODE,
			'mailOff'      => defined( 'REFORM_DISABLE_MAIL' ) && REFORM_DISABLE_MAIL,
			'previewUrl'   => Preview::url(),
			'previewNonce' => wp_create_nonce( Preview::NONCE ),
			'logo'         => Admin::icon( 'logo' ),
			'captchas'     => (object) self::captchas(),
			'places'       => (object) Places::editor(),
			'docsUrl'      => Settings::docs_url(),
			'aiAvailable'  => \VLT\Reform\Api\Describe::available(),
		], $form );
	}
}
