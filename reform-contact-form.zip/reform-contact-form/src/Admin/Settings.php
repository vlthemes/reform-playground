<?php

namespace VLT\Reform\Admin;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's settings (Contact Form → Settings), stored in one option
 *
 * Values: Settings::get( 'section' ). More sections: reform_settings_sections; more tabs: reform_settings_tabs.
 */
class Settings {
	const OPTION = 'reform_settings';
	const PAGE   = 'reform-settings';

	/**
	 * The page
	 *
	 * @var SettingsPage|null
	 */
	private static $page = null;

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 31 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'docs_link' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( REFORM_FILE ), [ __CLASS__, 'action_links' ] );
		self::page();
	}

	/**
	 * Documentation after Settings in the Contact Form menu
	 */
	public static function menu() {
		// A full URL as the slug: WordPress prints it as the link
		add_submenu_page( Admin::LIST_PAGE, __( 'Documentation', 'reform-contact-form' ), __( 'Documentation', 'reform-contact-form' ), Admin::CAPABILITY, self::docs_url() );
	}

	/**
	 * The Documentation menu link opens in a new tab
	 */
	public static function docs_link() {
		// The menu prints the URL without its trailing slash
		wp_add_inline_script( 'common', 'document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll("#adminmenu a[href^=\'' . esc_js( untrailingslashit( self::docs_url() ) ) . '\']").forEach(function(a){a.target="_blank";a.rel="noopener";});});' );
	}

	/**
	 * Settings and Docs in the plugin's row of the Plugins screen
	 *
	 * @param array $links Action links
	 *
	 * @return array
	 */
	public static function action_links( array $links ) {
		return [
			'reform-settings' => '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Settings', 'reform-contact-form' ) . '</a>',
			'reform-docs'     => '<a href="' . esc_url( self::docs_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Docs', 'reform-contact-form' ) . '</a>',
		] + $links;
	}

	/**
	 * The documentation
	 *
	 * @return string
	 */
	public static function docs_url() {
		return (string) apply_filters( 'reform_docs_url', 'https://vlthemes.me/docs/reform/' );
	}

	/**
	 * The settings page
	 *
	 * @return SettingsPage
	 */
	public static function page() {
		if ( null === self::$page ) {
			self::$page = new SettingsPage( [
				'option'      => self::OPTION,
				'page'        => self::PAGE,
				'parent'      => Admin::LIST_PAGE,
				'title'       => __( 'ReForm Settings', 'reform-contact-form' ),
				'menu_title'  => __( 'Settings', 'reform-contact-form' ),
				'name'        => 'ReForm',
				'version'     => REFORM_VERSION,
				'icon'        => Admin::icon( 'logo' ),
				'sections'    => [ __CLASS__, 'sections' ],
				'tabs_filter' => 'reform_settings_tabs',
				'validate'    => [ __CLASS__, 'validate' ],
				'docs_url'    => self::docs_url(),
				'support_url' => (string) apply_filters( 'reform_support_url', 'https://wordpress.org/support/plugin/reform-contact-form/' ),
			] );
		}

		return self::$page;
	}

	/**
	 * Sections and their fields
	 *
	 * @return array
	 */
	public static function sections() {
		$keys = static fn( $group ) => [
			$group . '_site'   => [ 'type' => 'text', 'group' => $group, 'label' => __( 'Site key', 'reform-contact-form' ), 'default' => '' ],
			$group . '_secret' => [ 'type' => 'secret', 'group' => $group, 'label' => __( 'Secret key', 'reform-contact-form' ), 'default' => '' ],
			$group . '_use'    => [ 'type' => 'select', 'group' => $group, 'label' => __( 'Use on', 'reform-contact-form' ), 'options' => [ 'all' => __( 'Every form', 'reform-contact-form' ), 'off' => __( 'No form', 'reform-contact-form' ) ], 'default' => 'all' ],
		];

		// A link in a description or help, the others' sites in a new tab
		$link = static fn( $url, $text, $own = false ) => '<a href="' . esc_url( $url ) . '"' . ( $own ? '' : ' target="_blank" rel="noopener"' ) . '>' . esc_html( $text ) . '</a>';

		return (array) apply_filters( 'reform_settings_sections', [
			'spam'    => [
				'tab'         => __( 'Spam', 'reform-contact-form' ),
				'icon'        => 'shield',
				'title'       => __( 'Spam', 'reform-contact-form' ),
				'description' => __( 'Checks every form runs before a message is sent. Visitors see none of these first ones. A captcha below runs on every form once its keys are saved; a form can skip them in its Advanced tab.', 'reform-contact-form' ),
				'groups'      => [
					// phpcs:ignore PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- a link to the Cloudflare dashboard, nothing loads from it
					'turnstile' => [ 'icon' => Admin::icon( 'captcha-turnstile' ), 'status' => \VLT\Reform\Spam\Captcha::status( 'turnstile' ), 'title' => 'Cloudflare Turnstile', /* translators: %s: link to the Cloudflare dashboard */ 'description' => sprintf( __( 'Free and private, usually without a puzzle. Get keys in your %s, under Turnstile.', 'reform-contact-form' ), $link( 'https://dash.cloudflare.com/?to=/:account/turnstile', __( 'Cloudflare dashboard', 'reform-contact-form' ) ) ) ],
					'hcaptcha'  => [ 'icon' => Admin::icon( 'captcha-hcaptcha' ), 'status' => \VLT\Reform\Spam\Captcha::status( 'hcaptcha' ), 'title' => 'hCaptcha', /* translators: %s: link to dashboard.hcaptcha.com */ 'description' => sprintf( __( 'Get keys at %s.', 'reform-contact-form' ), $link( 'https://dashboard.hcaptcha.com/', 'dashboard.hcaptcha.com' ) ) ],
					'recaptcha' => [ 'icon' => Admin::icon( 'captcha-recaptcha' ), 'status' => \VLT\Reform\Spam\Captcha::status( 'recaptcha' ), 'title' => 'Google reCAPTCHA v3', /* translators: %s: link to google.com/recaptcha/admin */ 'description' => sprintf( __( 'Invisible: it scores each visitor. Get v3 keys at %s.', 'reform-contact-form' ), $link( 'https://www.google.com/recaptcha/admin', 'google.com/recaptcha/admin' ) ) ],
				],
				'fields'      => [
					'honeypot'   => [
						'type'    => 'toggle',
						'label'   => __( 'Honeypot', 'reform-contact-form' ),
						'default' => true,
						'help'    => __( 'Adds a field people never see. Bots fill it in and get caught.', 'reform-contact-form' ),
					],
					'min_time'   => [
						'type'    => 'number',
						'label'   => __( 'Least time to fill a form', 'reform-contact-form' ),
						'unit'    => __( 'seconds', 'reform-contact-form' ),
						'min'     => 0,
						'max'     => 60,
						'default' => 3,
						'help'    => __( 'Forms sent faster than this are treated as spam: people need a few seconds. 0 turns it off.', 'reform-contact-form' ),
					],
					'rate_limit' => [
						'type'    => 'number',
						'label'   => __( 'Messages per visitor', 'reform-contact-form' ),
						'unit'    => __( 'in 10 minutes', 'reform-contact-form' ),
						'min'     => 0,
						'max'     => 100,
						'default' => 10,
						'help'    => __( 'More from the same IP address in 10 minutes are treated as spam. 0 turns it off.', 'reform-contact-form' ),
					],
					'disallowed' => [
						'type'    => 'toggle',
						'label'   => __( 'Use the Disallowed Comment Keys', 'reform-contact-form' ),
						'default' => true,
						/* translators: %s: link to Settings → Discussion */
						'help'    => sprintf( __( 'Messages with a word, email, IP address or browser from the list in %s are treated as spam, as comments are.', 'reform-contact-form' ), $link( admin_url( 'options-discussion.php#disallowed_keys' ), __( 'Settings → Discussion', 'reform-contact-form' ), true ) ),
					],
					'akismet'    => [
						'type'    => 'toggle',
						'label'   => __( 'Check with Akismet', 'reform-contact-form' ),
						'default' => false,
						'help'    => \VLT\Reform\Spam\Akismet::available() ? __( 'Akismet looks at the name, email and message as it does with comments.', 'reform-contact-form' ) : /* translators: %s: link to install Akismet, or to its key screen */ sprintf( __( 'Needs the %s, active and set up with its key.', 'reform-contact-form' ), $link( class_exists( 'Akismet' ) ? admin_url( 'options-general.php?page=akismet-key-config' ) : admin_url( 'plugin-install.php?s=akismet&tab=search&type=term' ), __( 'Akismet plugin', 'reform-contact-form' ), true ) ),
					],
				] + $keys( 'turnstile' ) + $keys( 'hcaptcha' ) + $keys( 'recaptcha' ) + [
					'recaptcha_score' => [
						'type'    => 'select',
						'group'   => 'recaptcha',
						'label'   => __( 'Lowest score let through', 'reform-contact-form' ),
						'options' => [ '0.3' => __( '0.3: lenient', 'reform-contact-form' ), '0.5' => __( '0.5: balanced', 'reform-contact-form' ), '0.7' => __( '0.7: strict', 'reform-contact-form' ) ],
						'default' => '0.5',
						'help'    => __( 'reCAPTCHA scores visitors from 0 (a bot) to 1 (a person).', 'reform-contact-form' ),
					],
					'recaptcha_badge' => [
						'type'    => 'select',
						'group'   => 'recaptcha',
						'label'   => __( 'Badge', 'reform-contact-form' ),
						'options' => [ 'show' => __( 'In the page corner', 'reform-contact-form' ), 'hide' => __( 'Hidden, a line of text instead', 'reform-contact-form' ) ],
						'default' => 'show',
						'help'    => __( 'Google lets you hide its badge if the form says the site is protected by reCAPTCHA. That line goes before the send button.', 'reform-contact-form' ),
					],
				],
			],
			'messages' => [
				'tab'         => __( 'Messages', 'reform-contact-form' ),
				'icon'        => 'format-chat',
				'title'       => __( 'Messages', 'reform-contact-form' ),
				'description' => __( 'What visitors read after sending, or when a field needs fixing, in every form. A form can still change any of them in its Messages tab. Leave one empty to use the text ReForm comes with.', 'reform-contact-form' ),
				'columns'     => 2,
			] + \VLT\Reform\Core\Messages::settings_fields(),
			'entries' => [
				'tab'         => __( 'Entries', 'reform-contact-form' ),
				'icon'        => 'email-alt',
				'title'       => __( 'Entries', 'reform-contact-form' ),
				'description' => __( 'ReForm keeps a copy of every message in Contact Form → Entries. Each form can turn this off in its Advanced tab.', 'reform-contact-form' ),
				'fields'      => [
					'retention'   => [
						'type'    => 'number',
						'label'   => __( 'Keep entries for', 'reform-contact-form' ),
						'unit'    => __( 'days', 'reform-contact-form' ),
						'min'     => 0,
						'max'     => 3650,
						'default' => 0,
						'help'    => __( 'Older entries are deleted once a day. 0 keeps them until you delete them.', 'reform-contact-form' ),
					],
					'visitor_ip'  => [
						'type'    => 'select',
						'label'   => __( 'Visitor\'s IP address and browser', 'reform-contact-form' ),
						'options' => [
							'short' => __( 'Shortened IP and the browser', 'reform-contact-form' ),
							'full'  => __( 'Full IP and the browser', 'reform-contact-form' ),
							'none'  => __( 'Don\'t save them', 'reform-contact-form' ),
						],
						'default' => 'short',
						'help'    => __( 'What entries and webhooks keep of each visit. Shortened: the last part of the IP is dropped (192.168.1.0), which is usually enough under the GDPR. Spam checks use the full IP either way and don\'t keep it.', 'reform-contact-form' ),
					],
					'delete_data' => [
						'type'    => 'toggle',
						'label'   => __( 'Remove everything when the plugin is deleted', 'reform-contact-form' ),
						'default' => false,
						'help'    => __( 'Forms, entries and settings go when you delete ReForm from the Plugins screen. Off: they stay, ready if you install it again.', 'reform-contact-form' ),
					],
				],
			],
		] );
	}

	/**
	 * Messages left as Reform ships them are stored empty, so a better text in an update reaches them
	 *
	 * @param array $clean Clean values of every section
	 *
	 * @return array
	 */
	public static function validate( array $clean ) {
		foreach ( (array) ( $clean['messages'] ?? [] ) as $key => $text ) {
			if ( \VLT\Reform\Core\Messages::built_in( $key ) === $text ) {
				$clean['messages'][ $key ] = '';
			}
		}

		return $clean;
	}

	/**
	 * Values of a section
	 *
	 * @param string $section Section
	 *
	 * @return array
	 */
	public static function get( $section ) {
		return self::page()->get( $section );
	}

	/**
	 * The settings screen
	 *
	 * @return string
	 */
	public static function url() {
		return admin_url( 'admin.php?page=' . self::PAGE );
	}
}
