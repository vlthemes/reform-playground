<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\Config;
use VLT\Reform\Core\PostType;
use VLT\Reform\Forms\Form;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings → Export & import: every form in one JSON file, and that file (or one form's code from its Advanced tab)
 * read back on this or another site
 *
 * A form keeps its hash when this site doesn't have it yet, so [reform id="…"] on the moved pages still finds it.
 */
class Transfer {
	const EXPORT = 'reform_export';
	const IMPORT = 'reform_import';

	/**
	 * Init
	 */
	public static function init() {
		add_filter( 'reform_settings_tabs', [ __CLASS__, 'tab' ] );
		add_action( 'admin_post_' . self::EXPORT, [ __CLASS__, 'export' ] );
		add_action( 'admin_post_' . self::IMPORT, [ __CLASS__, 'import_request' ] );
		// A theme's demo import: do_action( 'reform_import_forms', $file_or_url_or_json, $replace )
		add_action( 'reform_import_forms', [ __CLASS__, 'import_source' ], 10, 2 );
	}

	/**
	 * Import from a file path, a URL, JSON or the decoded data
	 *
	 * @param string|array $source  Where the forms are
	 * @param bool         $replace Overwrite forms with the same hash
	 *
	 * @return int[] [ added, replaced ]
	 */
	public static function import_source( $source, $replace = false ) {
		if ( is_string( $source ) ) {
			$source = trim( $source );

			if ( preg_match( '#^https?://#', $source ) ) {
				$response = wp_safe_remote_get( $source, [ 'timeout' => 20 ] );
				$source   = is_wp_error( $response ) ? '' : wp_remote_retrieve_body( $response );
			} elseif ( '' !== $source && '{' !== $source[0] && is_readable( $source ) ) {
				$source = (string) file_get_contents( $source ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file the theme names
			}

			$source = json_decode( $source, true );
		}

		return is_array( $source ) ? self::import( $source, (bool) $replace ) : [ 0, 0 ];
	}

	/**
	 * The tab
	 *
	 * @param array $tabs Tabs
	 *
	 * @return array
	 */
	public static function tab( array $tabs ) {
		return $tabs + [
			'transfer' => [
				'label'  => __( 'Export & import', 'reform-contact-form' ),
				'icon'   => 'database-export',
				'render' => [ __CLASS__, 'render' ],
			],
		];
	}

	/**
	 * The tab: export and import side by side
	 */
	public static function render() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the result of the import just done
		$done   = isset( $_GET['reform-transfer'] ) ? array_map( 'absint', explode( '-', sanitize_text_field( wp_unslash( $_GET['reform-transfer'] ) ) ) ) + [ 0, 0 ] : null;
		$failed = isset( $_GET['reform-transfer-error'] );
		// phpcs:enable
		$ids    = self::ids();
		$drafts = count( array_filter( $ids, static fn( $id ) => 'draft' === get_post_status( $id ) ) );
		?>
		<div class="vlt-settings-page__head">
			<h2><?php esc_html_e( 'Export & import', 'reform-contact-form' ); ?></h2>
			<p><?php esc_html_e( 'Move your forms to another site, or keep a copy. Entries stay where they are.', 'reform-contact-form' ); ?></p>
		</div>

		<?php if ( $failed ) : ?>
			<p class="reform-import__done is-error"><?php esc_html_e( 'That file has no Reform forms in it. Pick a file made with Download forms.', 'reform-contact-form' ); ?></p>
		<?php elseif ( $done ) : ?>
			<p class="reform-import__done">
				<?php
				/* translators: 1: forms added, 2: forms replaced */
				echo esc_html( sprintf( __( 'Done. Added: %1$d, replaced: %2$d.', 'reform-contact-form' ), $done[0], $done[1] ) );
				?>
			</p>
		<?php endif; ?>

		<div class="reform-transfer">
			<form class="reform-transfer__col" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::EXPORT ); ?>">
				<?php wp_nonce_field( self::EXPORT ); ?>
				<span class="reform-transfer__icon dashicons dashicons-download" aria-hidden="true"></span>
				<h3><?php esc_html_e( 'Export', 'reform-contact-form' ); ?></h3>
				<p><?php esc_html_e( 'Every form in one .json file, with its fields, mails, messages and settings.', 'reform-contact-form' ); ?></p>
				<p class="reform-transfer__stat">
					<strong><?php echo esc_html( number_format_i18n( count( $ids ) ) ); ?></strong>
					<span>
						<?php
						/* translators: %d: number of drafts among the forms */
						echo esc_html( $drafts ? sprintf( _n( 'forms, %d of them a draft', 'forms, %d of them drafts', $drafts, 'reform-contact-form' ), $drafts ) : _n( 'form', 'forms', count( $ids ), 'reform-contact-form' ) );
						?>
					</span>
				</p>
				<button type="submit" class="vlt-settings-page__button is-primary" <?php disabled( !$ids ); ?>><?php esc_html_e( 'Download forms', 'reform-contact-form' ); ?></button>
			</form>

			<form class="reform-transfer__col" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::IMPORT ); ?>">
				<?php wp_nonce_field( self::IMPORT ); ?>
				<span class="reform-transfer__icon dashicons dashicons-upload" aria-hidden="true"></span>
				<h3><?php esc_html_e( 'Import', 'reform-contact-form' ); ?></h3>
				<p><?php esc_html_e( 'A file from Export, or one form\'s code saved as .json. Forms keep their shortcode when it is free here.', 'reform-contact-form' ); ?></p>
				<label class="reform-transfer__drop">
					<input type="file" name="reform_file" accept=".json,application/json" required aria-label="<?php esc_attr_e( 'Forms file (.json)', 'reform-contact-form' ); ?>">
				</label>
				<label class="reform-transfer__replace">
					<input type="checkbox" class="vlt-settings-page__switch" name="replace" value="1">
					<span><?php esc_html_e( 'Replace forms with the same shortcode (off: copies with a new one)', 'reform-contact-form' ); ?></span>
				</label>
				<button type="submit" class="vlt-settings-page__button is-primary"><?php esc_html_e( 'Import forms', 'reform-contact-form' ); ?></button>
			</form>
		</div>
		<?php
	}

	/**
	 * Every form's ID, oldest first
	 *
	 * @return int[]
	 */
	private static function ids() {
		return get_posts( [ 'post_type' => PostType::NAME, 'post_status' => [ 'publish', 'draft' ], 'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC' ] );
	}

	/**
	 * Every form, as the file holds them
	 *
	 * @return array
	 */
	public static function data() {
		$forms = [];

		foreach ( self::ids() as $id ) {
			$form = Form::get( $id );

			if ( $form ) {
				// The same shape as one form's code in its Advanced tab
				$forms[] = [
					'reform'      => 1,
					'title'       => $form->title(),
					'description' => $form->description(),
					'status'      => $form->status(),
					'hash'        => $form->hash(),
					'template'    => $form->template(),
					'config'      => $form->config(),
				];
			}
		}

		return [ 'reform' => 1, 'site' => home_url( '/' ), 'date' => gmdate( 'c' ), 'forms' => $forms ];
	}

	/**
	 * Download the file
	 */
	public static function export() {
		check_admin_referer( self::EXPORT );

		if ( !current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You can\'t export forms.', 'reform-contact-form' ) );
		}

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="reform-forms-' . gmdate( 'Y-m-d' ) . '.json"' );

		echo wp_json_encode( self::data(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	/**
	 * The import, from the tab
	 */
	public static function import_request() {
		check_admin_referer( self::IMPORT );

		if ( !current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You can\'t import forms.', 'reform-contact-form' ) );
		}

		$file   = $_FILES['reform_file']['tmp_name'] ?? ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- a temporary path, only read
		$data   = is_uploaded_file( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local upload
		$result = is_array( $data ) ? self::import( $data, !empty( $_POST['replace'] ) ) : null;
		$back   = [ 'page' => Settings::PAGE ];

		if ( $result && array_sum( $result ) ) {
			$back['reform-transfer'] = implode( '-', $result );
		} else {
			$back['reform-transfer-error'] = 1;
		}

		wp_safe_redirect( add_query_arg( $back, admin_url( 'admin.php' ) ) . '#transfer' );
		exit;
	}

	/**
	 * Import forms
	 *
	 * @param array $data    The file: { forms: [ … ] }, or one form's code
	 * @param bool  $replace Overwrite a form with the same hash instead of adding a copy
	 *
	 * @return int[] [ added, replaced ]
	 */
	public static function import( array $data, $replace = false ) {
		$forms  = isset( $data['forms'] ) && is_array( $data['forms'] ) ? $data['forms'] : [ $data ];
		$result = [ 0, 0 ];

		foreach ( $forms as $item ) {
			if ( !is_array( $item ) || 1 !== ( $item['reform'] ?? null ) || !is_string( $item['template'] ?? null ) || !is_array( $item['config'] ?? null ) ) {
				continue;
			}

			$hash     = preg_match( '/^[a-f0-9]{7}$/', (string) ( $item['hash'] ?? '' ) ) ? $item['hash'] : '';
			$existing = $hash ? Form::find( $hash ) : null;
			$post     = [
				'post_type'    => PostType::NAME,
				'post_status'  => 'draft' === ( $item['status'] ?? '' ) ? 'draft' : 'publish',
				'post_title'   => sanitize_text_field( (string) ( $item['title'] ?? '' ) ) ?: __( 'Imported form', 'reform-contact-form' ),
				'post_excerpt' => sanitize_text_field( (string) ( $item['description'] ?? '' ) ),
				// Users without unfiltered_html get it through kses, as the editor's save
				'post_content' => $item['template'],
			];

			if ( $existing && $replace ) {
				$id = wp_update_post( wp_slash( [ 'ID' => $existing->id() ] + $post ), true );
			} else {
				$id = wp_insert_post( wp_slash( $post ), true );
			}

			if ( is_wp_error( $id ) || !$id ) {
				continue;
			}

			// Defaults this site has and the file doesn't keep their values
			Config::save( $id, Config::merge( Config::defaults(), $item['config'] ) );
			Form::forget( $id );

			if ( $hash && !$existing ) {
				update_post_meta( $id, Form::HASH, $hash );
			}

			$result[ $existing && $replace ? 1 : 0 ]++;
		}

		return $result;
	}
}
