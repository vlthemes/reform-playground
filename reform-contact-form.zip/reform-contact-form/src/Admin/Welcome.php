<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\Assets;
use VLT\Reform\Core\PostType;
use VLT\Reform\Entries\Entries;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Welcome page. Opens once after activation, then stays reachable by its address
 * (edit.php?post_type=reform_form&page=reform-welcome) and the plugin's row, without a menu item.
 */
class Welcome {
	const PAGE = 'reform-welcome';

	/**
	 * Set on activation, read on the next admin page
	 */
	const REDIRECT = 'reform_welcome_redirect';

	/**
	 * The page's hook
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Init
	 */
	public static function init() {
		add_action( 'admin_init', [ __CLASS__, 'redirect' ] );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_head', [ __CLASS__, 'hide' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( REFORM_FILE ), [ __CLASS__, 'action_link' ], 20 );
	}

	/**
	 * Activation hook
	 */
	public static function activate() {
		set_transient( self::REDIRECT, 1, MINUTE_IN_SECONDS );
	}

	/**
	 * Page URL
	 *
	 * @return string
	 */
	public static function url() {
		return add_query_arg( 'page', self::PAGE, admin_url( Admin::LIST_PAGE ) );
	}

	/**
	 * The page's hook
	 *
	 * @return string
	 */
	public static function hook() {
		return self::$hook;
	}

	/**
	 * The first admin page after activation goes to the welcome page
	 */
	public static function redirect() {
		if ( !get_transient( self::REDIRECT ) ) {
			return;
		}

		delete_transient( self::REDIRECT );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only checks how the plugin was activated
		if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) || !current_user_can( Admin::CAPABILITY ) ) {
			return;
		}

		wp_safe_redirect( self::url() );
		exit;
	}

	/**
	 * The page, in the Contact Form menu so it gets its title and address (edit.php?post_type=reform_form&page=…)
	 */
	public static function menu() {
		self::$hook = (string) add_submenu_page( Admin::LIST_PAGE, __( 'Welcome to ReForm', 'reform-contact-form' ), __( 'Welcome', 'reform-contact-form' ), Admin::CAPABILITY, self::PAGE, [ __CLASS__, 'page' ] );
	}

	/**
	 * No menu item: removed after the title is read
	 */
	public static function hide() {
		remove_submenu_page( Admin::LIST_PAGE, self::PAGE );
	}

	/**
	 * Settings styles (header, cards) and the page's own
	 *
	 * @param string $hook Admin page hook
	 */
	public static function enqueue( $hook ) {
		if ( self::$hook && self::$hook === $hook ) {
			Assets::enqueue( 'reform-admin-welcome' );
		}
	}

	/**
	 * "Welcome" in the plugin's row of the Plugins screen
	 *
	 * @param array $links Action links
	 *
	 * @return array
	 */
	public static function action_link( array $links ) {
		return $links + [ 'reform-welcome' => '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Welcome', 'reform-contact-form' ) . '</a>' ];
	}

	/**
	 * What the plugin does
	 *
	 * @return array [ [ dashicon, title, text ] ]
	 */
	private static function features() {
		return [
			[ 'editor-code', __( 'Your own markup', 'reform-contact-form' ), __( 'A form is plain HTML. Drag fields into it, and set each one in the sidebar instead of inside a tag.', 'reform-contact-form' ) ],
			[ 'visibility', __( 'See it as visitors will', 'reform-contact-form' ), __( 'Preview shows the unsaved form with your theme\'s styles. Click a field there to edit it.', 'reform-contact-form' ) ],
			[ 'forms', __( '19 field types', 'reform-contact-form' ), __( 'Text, email, phone, dates, choices, files, a quiz, hidden values, a live mirror, a character count and payments. Any field can start filled from the link, the shortcode or the logged-in user.', 'reform-contact-form' ) ],
			[ 'randomize', __( 'Conditions', 'reform-contact-form' ), __( 'Select some code, right-click, make it a group, and show it only when visitors pick or type something.', 'reform-contact-form' ) ],
			[ 'email-alt', __( 'Two mails per form', 'reform-contact-form' ), __( 'One for you, one optional copy for the sender, with mail tags, HTML or plain text, and attachments.', 'reform-contact-form' ) ],
			[ 'archive', __( 'Every message kept', 'reform-contact-form' ), __( 'Entries saves each message, even when the mail fails. Filter by form, export a CSV, delete old ones on a schedule.', 'reform-contact-form' ) ],
			[ 'money-alt', __( 'Take payments', 'reform-contact-form' ), __( 'Add a Stripe or PayPal field and visitors pay inside the form before their message goes. A set amount or one from a field, checked on your server. Your own keys, no fees.', 'reform-contact-form' ) ],
			[ 'shield', __( 'Spam stays out', 'reform-contact-form' ), __( 'A honeypot, a time check, a limit per visitor and your Disallowed Comment Keys on every form, plus Turnstile, hCaptcha, reCAPTCHA or Akismet if you like.', 'reform-contact-form' ) ],
			[ 'admin-appearance', __( 'Made for themes', 'reform-contact-form' ), __( 'Fields and messages are templates your theme can restyle or replace, and CSS variables set the look. Forms read the right way round in right-to-left languages.', 'reform-contact-form' ) ],
			[ 'performance', __( 'Lightweight', 'reform-contact-form' ), __( 'One small script and inline styles, only on pages with a form, with no jQuery. Payment and captcha scripts load only when needed, and forms work with JavaScript off.', 'reform-contact-form' ) ],
			[ 'block-default', __( 'Place it anywhere', 'reform-contact-form' ), __( 'The ReForm Contact Form block, Elementor widget, WPBakery element or classic widget, or a shortcode.', 'reform-contact-form' ) ],
			[ 'rest-api', __( 'Webhooks', 'reform-contact-form' ), __( 'Send each message as JSON to Zapier, Make, n8n or your own code.', 'reform-contact-form' ) ],
			[ 'privacy', __( 'Private and safe', 'reform-contact-form' ), __( 'Visitors\' IPs are shortened, messages can be exported, erased or deleted on a schedule, and a privacy policy text is ready. Webhooks never reach your own network.', 'reform-contact-form' ) ],
			[ 'lightbulb', __( 'Build with AI', 'reform-contact-form' ), __( 'Describe the form you need and your site\'s AI writes it. AI assistants connected to your site can also list, build and change forms and read entries, with your rights.', 'reform-contact-form' ) ],
			[ 'migrate', __( 'Move from Contact Form 7', 'reform-contact-form' ), __( 'Import your CF7 forms with their fields, mails and messages. Mail tags stay the same, and the old shortcodes keep working.', 'reform-contact-form' ) ],
			[ 'admin-tools', __( 'Safe to test', 'reform-contact-form' ), __( 'Test mode checks the fields and sends nothing; "Don\'t send mail" still saves entries. Per form, or for the whole site in wp-config.php.', 'reform-contact-form' ) ],
			[ 'admin-page', __( 'Move to another site', 'reform-contact-form' ), __( 'Export every form to one file in Settings and import it on the other site, or copy one form\'s code from its Advanced tab.', 'reform-contact-form' ) ],
		];
	}

	/**
	 * The page
	 */
	public static function page() {
		$forms   = (int) ( wp_count_posts( PostType::NAME )->publish ?? 0 );
		$entries = (int) ( wp_count_posts( Entries::POST_TYPE )->publish ?? 0 );
		$steps   = [
			[
				'done'   => $forms > 0,
				'title'  => __( 'Make a form', 'reform-contact-form' ),
				'text'   => $forms
					/* translators: %s: number of forms */
					? sprintf( _n( '%s form so far. Open it to drag in fields, write the mails and pick its messages.', '%s forms so far. Open one to drag in fields, write the mails and pick its messages.', $forms, 'reform-contact-form' ), number_format_i18n( $forms ) )
					: __( 'A new form starts with name, email, subject and message fields. Drag in more, or change the markup around them.', 'reform-contact-form' ),
				'action' => $forms ? [ Admin::url(), __( 'Contact Forms', 'reform-contact-form' ) ] : [ Admin::new_url(), __( 'Make a form', 'reform-contact-form' ) ],
			],
			[
				'done'   => false,
				'title'  => __( 'Put it on a page', 'reform-contact-form' ),
				'text'   => __( 'Add the ReForm Contact Form block in the block editor or the Elementor widget, or paste the form\'s shortcode anywhere shortcodes work.', 'reform-contact-form' ),
				'action' => $forms ? [ Admin::url(), __( 'Copy a shortcode', 'reform-contact-form' ) ] : null,
			],
			[
				'done'   => $entries > 0,
				'title'  => __( 'Send yourself a test', 'reform-contact-form' ),
				'text'   => __( 'Fill in the form on your site. If the mail doesn\'t arrive, your site needs a mail setup such as an SMTP plugin; Entries keeps the message either way.', 'reform-contact-form' ),
				'action' => $entries ? [ admin_url( EntriesList::LIST_PAGE ), __( 'Entries', 'reform-contact-form' ) ] : null,
			],
		];
		?>
		<div class="wrap vlt-settings-page vlt-welcome">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Welcome to ReForm', 'reform-contact-form' ); ?></h1>
			<hr class="wp-header-end">

			<?php Settings::page()->header( __( 'welcome', 'reform-contact-form' ) ); ?>

			<div class="vlt-settings-page__panels">
				<section class="vlt-settings-page__card">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'Get started in three steps', 'reform-contact-form' ); ?></h2>
					</div>
					<ol class="vlt-welcome__steps">
						<?php foreach ( $steps as $number => $step ) : ?>
							<li class="vlt-welcome__step<?php echo $step['done'] ? ' is-done' : ''; ?>">
								<span class="vlt-welcome__step-number" aria-hidden="true"><?php echo $step['done'] ? '✓' : (int) ( $number + 1 ); ?></span>
								<div class="vlt-welcome__step-text">
									<strong><?php echo esc_html( $step['title'] ); ?></strong>
									<?php if ( $step['done'] ) : ?>
										<span class="screen-reader-text"><?php esc_html_e( '(done)', 'reform-contact-form' ); ?></span>
									<?php endif; ?>
									<p><?php echo esc_html( $step['text'] ); ?></p>
								</div>
								<?php if ( $step['action'] ) : ?>
									<a class="vlt-settings-page__button" href="<?php echo esc_url( $step['action'][0] ); ?>"><?php echo esc_html( $step['action'][1] ); ?></a>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ol>
				</section>

				<section class="vlt-settings-page__card vlt-welcome__sky">
					<div class="vlt-settings-page__head">
						<h2><?php esc_html_e( 'What you can do', 'reform-contact-form' ); ?></h2>
					</div>
					<ul class="vlt-welcome__features">
						<?php foreach ( self::features() as [ $icon, $title, $text ] ) : ?>
							<li class="vlt-welcome__feature">
								<span class="vlt-welcome__icon dashicons dashicons-<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
								<div>
									<strong><?php echo esc_html( $title ); ?></strong>
									<p><?php echo esc_html( $text ); ?></p>
								</div>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>

				<footer class="vlt-welcome__help">
					<span><?php esc_html_e( 'Need a hand?', 'reform-contact-form' ); ?></span>
					<a href="<?php echo esc_url( Settings::docs_url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Documentation', 'reform-contact-form' ); ?></a>
					<a href="<?php echo esc_url( (string) apply_filters( 'reform_support_url', 'https://wordpress.org/support/plugin/reform-contact-form/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Support', 'reform-contact-form' ); ?></a>
					<a href="<?php echo esc_url( Settings::url() ); ?>"><?php esc_html_e( 'Settings', 'reform-contact-form' ); ?></a>
					<a href="https://wordpress.org/support/plugin/reform-contact-form/reviews/#new-post" target="_blank" rel="noopener"><?php esc_html_e( 'Enjoying ReForm? Leave a review', 'reform-contact-form' ); ?></a>
				</footer>
			</div>
		</div>
		<?php
	}
}
