<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\Assets;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tabbed settings page stored in one option
 *
 * Field types: number, toggle, select, text, secret (shown masked, kept while left as is), textarea, slug, image (an attachment ID picked in the Media Library). Modules add tabs with their own content:
 *
 *     add_filter( '{tabs_filter}', fn( $tabs ) => $tabs + [ 'my' => [ 'label' => 'My', 'icon' => 'admin-generic', 'render' => 'my_render' ] ] );
 */
class SettingsPage {
	// What a field's help and a section's or group's description may hold: links, such as to a WordPress screen
	const HELP_HTML = [ 'a' => [ 'href' => true, 'target' => true, 'rel' => true ] ];

	/**
	 * Page arguments
	 *
	 * @var array
	 */
	private $args;

	/**
	 * Sections cache (labels are translated, so built on first use)
	 *
	 * @var array|null
	 */
	private $sections = null;

	/**
	 * Constructor
	 *
	 * @param array $args {
	 *     @type string          $option      Option name
	 *     @type string          $page        Page slug
	 *     @type string|callable $parent      Parent menu slug, or a callable returning it
	 *     @type string          $title       Page title
	 *     @type string          $menu_title  Menu title
	 *     @type string          $name        Name in the header ("{name} settings")
	 *     @type string          $version     Version badge ('' = none)
	 *     @type string          $icon        SVG of the header logo ('' = none)
	 *     @type callable        $sections    Returns [ section => [ tab, title, description, columns, groups => [ id => [ title,
	 *                                        description, show_if ] ], fields => [ key => field ] ] ]; a field's "group" puts it in
	 *                                        one, a group's "show_if" (a toggle of the section) shows it only while that is on
	 *                                        (a field's own "show_if" does the same for a field outside a group or a toggle),
	 *                                        a slug field's "preview" (an address with %s) shows its value in place
	 *     @type string          $tabs_filter Filter for extra tabs
	 *     @type callable|null   $validate    Post-processes the whole clean value (cross-field rules)
	 *     @type string          $docs_url    Documentation link in the header ('' = none)
	 *     @type string          $support_url Support link in the header ('' = none)
	 *     @type callable|null   $render      Prints the page instead: a dashboard that shows these settings (content())
	 *                                        under its own header
	 *     @type int             $priority    admin_menu priority
	 *     @type string          $capability  Who may see and save the page (default manage_options)
	 * }
	 */
	public function __construct( array $args ) {
		$this->args = $args + [
			'name'        => $args['title'],
			'version'     => '',
			'icon'        => '',
			'validate'    => null,
			'docs_url'    => '',
			'support_url' => '',
			'render'      => null,
			'priority'    => 30,
			'menu_title'  => $args['title'],
			'capability'  => 'manage_options',
		];

		add_action( 'admin_init', [ $this, 'register' ] );
		add_action( 'admin_menu', [ $this, 'menu' ], $this->args['priority'] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
	}

	/**
	 * Page slug
	 *
	 * @return string
	 */
	public function slug() {
		return $this->args['page'];
	}

	/**
	 * Sections and their fields
	 *
	 * @return array
	 */
	public function sections() {
		if ( null !== $this->sections ) {
			return $this->sections;
		}

		$sections = (array) call_user_func( $this->args['sections'] );

		// Modules add sections on init (a filter of the sections callback): don't freeze a list read before them
		if ( did_action( 'wp_loaded' ) ) {
			$this->sections = $sections;
		}

		return $sections;
	}

	/**
	 * Values of a section (saved, or the defaults)
	 *
	 * @param string $section Section
	 *
	 * @return array
	 */
	public function get( $section ) {
		$saved = get_option( $this->args['option'], [] );

		return $this->sanitize( is_array( $saved ) ? $saved : [] )[ $section ] ?? [];
	}

	/**
	 * Validate the whole option
	 *
	 * @param mixed $input Raw
	 *
	 * @return array
	 */
	public function sanitize( $input ) {
		$input = is_array( $input ) ? $input : [];
		$clean = [];
		$saved = null;

		foreach ( $this->sections() as $section => $definition ) {
			// A tab sends only its own section: the others keep their saved values
			if ( !isset( $input[ $section ] ) ) {
				$saved           ??= (array) get_option( $this->args['option'], [] );
				$input[ $section ] = $saved[ $section ] ?? [];
			}

			foreach ( $definition['fields'] as $key => $field ) {
				// A secret comes back as its mask while left alone: the saved one stays
				if ( 'secret' === ( $field['type'] ?? '' ) ) {
					$saved ??= (array) get_option( $this->args['option'], [] );
					$old     = (string) ( $saved[ $section ][ $key ] ?? '' );
					$typed   = trim( (string) ( $input[ $section ][ $key ] ?? '' ) );

					$clean[ $section ][ $key ] = '' !== $old && self::mask( $old ) === $typed ? $old : sanitize_text_field( $typed );
					continue;
				}

				$clean[ $section ][ $key ] = self::clean( $field, $input[ $section ][ $key ] ?? null );
			}
		}

		return $this->args['validate'] ? (array) call_user_func( $this->args['validate'], $clean ) : $clean;
	}

	/**
	 * A secret as shown: as long as the key, its first and last characters around stars (356151***…***51535)
	 *
	 * @param string $secret Secret
	 *
	 * @return string
	 */
	private static function mask( $secret ) {
		$length = strlen( $secret );

		if ( '' === $secret ) {
			return '';
		}

		// As long as the key, its ends shown; a short one shows less of itself
		$shown = $length >= 16 ? [ 6, 5 ] : [ (int) floor( $length / 4 ), (int) floor( $length / 4 ) ];

		return substr( $secret, 0, $shown[0] ) . str_repeat( '*', $length - $shown[0] - $shown[1] ) . ( $shown[1] ? substr( $secret, -$shown[1] ) : '' );
	}

	/**
	 * One field value
	 *
	 * @param array $field Field
	 * @param mixed $value Raw (null = missing)
	 *
	 * @return mixed
	 */
	private static function clean( array $field, $value ) {
		switch ( $field['type'] ?? 'number' ) {
			case 'toggle':
				return null === $value ? (bool) $field['default'] : !empty( $value );

			case 'select':
				return isset( $field['options'][ (string) $value ] ) ? (string) $value : $field['default'];

			case 'slug':
				// A URL part: lowercase, dashes; empty falls back to the default
				return sanitize_title( (string) $value ) ?: $field['default'];

			case 'image':
				// An attachment ID; 0 = none picked
				if ( null === $value ) {
					return (int) $field['default'];
				}

				return wp_attachment_is_image( absint( $value ) ) ? absint( $value ) : 0;

			case 'text':
				return null === $value ? $field['default'] : sanitize_text_field( (string) $value );

			case 'textarea':
				// Plain text, one entry per line: empty lines and spaces around entries dropped
				return null === $value ? $field['default'] : implode( "\n", array_filter( array_map( 'trim', explode( "\n", sanitize_textarea_field( (string) $value ) ) ) ) );

			default:
				return is_numeric( $value ) ? max( $field['min'], min( $field['max'], (int) $value ) ) : $field['default'];
		}
	}

	/**
	 * Register the option
	 */
	public function register() {
		// options.php saves only with manage_options unless the page's group says who else may
		add_filter( 'option_page_capability_' . $this->args['option'] . '_group', fn() => $this->args['capability'] );

		register_setting( $this->args['option'] . '_group', $this->args['option'], [
			'type'              => 'array',
			'sanitize_callback' => [ $this, 'sanitize' ],
			'default'           => [],
		] );
	}

	/**
	 * Menu entry
	 */
	public function menu() {
		$parent = is_callable( $this->args['parent'] ) ? call_user_func( $this->args['parent'] ) : $this->args['parent'];

		add_submenu_page( $parent, $this->args['title'], $this->args['menu_title'], $this->args['capability'], $this->args['page'], [ $this, 'page' ] );
	}

	/**
	 * Assets on the page
	 *
	 * @param string $hook Admin page hook
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( $hook, $this->args['page'] ) ) {
			return;
		}

		Assets::enqueue( 'reform-admin-settings' );
		// The Media Library of image fields
		wp_enqueue_media();
	}

	/**
	 * Tabs: the sections, then the ones modules add
	 *
	 * @return array [ id => [ 'label', 'render' => callable|null ] ], null renders the section's fields
	 */
	public function tabs() {
		$tabs = [];

		foreach ( $this->sections() as $section => $definition ) {
			$tabs[ $section ] = [
				'label'  => $definition['tab'],
				'icon'   => $definition['icon'] ?? '',
				'render' => null,
			];
		}

		// The plugin's own filter, named by the page (reform_settings_tabs)
		foreach ( (array) apply_filters( $this->args['tabs_filter'], [] ) as $id => $tab ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound
			$id = sanitize_key( $id );

			if ( $id && !isset( $tabs[ $id ] ) && !empty( $tab['label'] ) && is_callable( $tab['render'] ?? null ) ) {
				$tabs[ $id ] = [
					'label'  => (string) $tab['label'],
					'icon'   => (string) ( $tab['icon'] ?? '' ),
					'render' => $tab['render'],
				];
			}
		}

		return $tabs;
	}

	/**
	 * Header with the tabs as pills, then the open tab's card
	 */
	public function page() {
		if ( !current_user_can( $this->args['capability'] ) ) {
			return;
		}

		if ( $this->args['render'] ) {
			call_user_func( $this->args['render'] );

			return;
		}

		$tabs  = $this->tabs();
		$first = (string) array_key_first( $tabs );
		?>
		<div class="wrap vlt-settings-page">
			<h1 class="screen-reader-text"><?php echo esc_html( $this->args['title'] ); ?></h1>
			<?php // WordPress notices go here, above the header ?>
			<hr class="wp-header-end">

			<?php $this->header( __( 'settings', 'reform-contact-form' ), $tabs, $first ); ?>

			<?php $this->body( $tabs, $first, false ); ?>
		</div>
		<?php
	}

	/**
	 * The shared header: name, version, links and, given tabs, the tabs
	 *
	 * @param string $suffix  Word after the name
	 * @param array  $tabs    Tabs, as tabs() returns them
	 * @param string $current Tab shown first
	 */
	public function header( $suffix, array $tabs = [], $current = '' ) {
		?>
		<header class="vlt-admin-header">
			<div class="vlt-admin-header__top">
				<div class="vlt-admin-header__brand">
					<?php if ( $this->args['icon'] ) : ?>
						<span class="vlt-admin-header__logo" aria-hidden="true"><?php echo $this->args['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?></span>
					<?php endif; ?>

					<div class="vlt-admin-header__titles">
						<div class="vlt-admin-header__title-row">
							<div class="vlt-admin-header__title" aria-hidden="true">
								<?php echo esc_html( $this->args['name'] ); ?>
								<em><?php echo esc_html( $suffix ); ?></em>
							</div>

							<?php if ( $this->args['version'] ) : ?>
								<span class="vlt-admin-header__version">v<?php echo esc_html( $this->args['version'] ); ?></span>
							<?php endif; ?>
						</div>
						<div class="vlt-admin-header__tagline"><?php esc_html_e( 'Crafted with care by VLThemes', 'reform-contact-form' ); ?></div>
					</div>
				</div>

				<div class="vlt-admin-header__links">
					<?php if ( $this->args['docs_url'] ) : ?>
						<a class="vlt-admin-header__link is-ghost" href="<?php echo esc_url( $this->args['docs_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Documentation', 'reform-contact-form' ); ?></a>
					<?php endif; ?>
					<?php if ( $this->args['support_url'] ) : ?>
						<a class="vlt-admin-header__link is-brand" href="<?php echo esc_url( $this->args['support_url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Get support', 'reform-contact-form' ); ?></a>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( $tabs ) : ?>
				<?php $this->render_tabs( $tabs, $current ); ?>
			<?php endif; ?>
		</header>
		<?php
	}

	/**
	 * The settings without the page around them, for a dashboard page (see "render")
	 */
	public function content() {
		$tabs = $this->tabs();
		?>
		<div class="vlt-settings-page">
			<?php $this->body( $tabs, (string) array_key_first( $tabs ), true ); ?>
		</div>
		<?php
	}

	/**
	 * Notices, tabs, then the cards
	 *
	 * @param array  $tabs     Tabs
	 * @param string $first    Tab open before the script runs
	 * @param bool   $embedded Inside a dashboard page
	 */
	private function body( array $tabs, $first, $embedded ) {
		settings_errors();

		if ( $embedded ) {
			$this->render_tabs( $tabs, $first, 'is-light' );
		}
		?>
		<div class="vlt-settings-page__panels">
			<form method="post" action="options.php" class="vlt-settings-page__card vlt-settings-page__form"<?php echo $tabs[ $first ]['render'] ? ' hidden' : ''; ?>>
				<?php settings_fields( $this->args['option'] . '_group' ); ?>

				<?php foreach ( $this->sections() as $section => $definition ) : ?>
					<?php $this->render_section( $section, $section === $first ); ?>
				<?php endforeach; ?>

				<div class="vlt-settings-page__save">
					<span><?php esc_html_e( 'Changes apply after saving.', 'reform-contact-form' ); ?></span>
					<button type="submit" class="vlt-settings-page__button is-primary"><?php esc_html_e( 'Save changes', 'reform-contact-form' ); ?></button>
				</div>
			</form>

			<?php
			// Module tabs: cards and forms of their own, outside the settings form
			foreach ( $tabs as $id => $tab ) :
				if ( !$tab['render'] ) {
					continue;
				}
				?>
				<section class="vlt-settings-page__panel is-module" id="vlt-settings-panel-<?php echo esc_attr( $id ); ?>" role="tabpanel" aria-labelledby="vlt-settings-tab-<?php echo esc_attr( $id ); ?>" tabindex="0"<?php echo $id !== $first ? ' hidden' : ''; ?>>
					<?php call_user_func( $tab['render'] ); ?>
				</section>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * The tabs as pills (no list for a single tab)
	 *
	 * @param array  $tabs    Tabs
	 * @param string $current Tab open before the script runs
	 * @param string $class   Extra class of the row
	 */
	private function render_tabs( array $tabs, $current, $class = '' ) {
		if ( count( $tabs ) < 2 ) {
			return;
		}
		?>
		<div class="vlt-admin-header__nav <?php echo esc_attr( $class ); ?>" role="tablist" aria-label="<?php esc_attr_e( 'Settings sections', 'reform-contact-form' ); ?>">
			<?php foreach ( $tabs as $id => $tab ) : ?>
				<button
					type="button"
					class="vlt-admin-header__nav-item"
					id="vlt-settings-tab-<?php echo esc_attr( $id ); ?>"
					role="tab"
					aria-controls="vlt-settings-panel-<?php echo esc_attr( $id ); ?>"
					aria-selected="<?php echo $id === $current ? 'true' : 'false'; ?>"
					tabindex="<?php echo $id === $current ? '0' : '-1'; ?>"
					data-vlt-tab="<?php echo esc_attr( $id ); ?>"
				>
					<?php if ( $tab['icon'] ) : ?>
						<span class="dashicons dashicons-<?php echo esc_attr( $tab['icon'] ); ?>" aria-hidden="true"></span>
					<?php endif; ?>
					<?php echo esc_html( $tab['label'] ); ?>
				</button>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * A section: heading, notes, then its fields
	 *
	 * @param string $section Section
	 * @param bool   $open    Shown before the script runs
	 */
	private function render_section( $section, $open ) {
		$definition = $this->sections()[ $section ];
		$values     = $this->get( $section );
		$blocks     = [];

		foreach ( $definition['fields'] as $key => $field ) {
			$type    = $field['type'] ?? 'number';
			$show_if = $field['show_if'] ?? '';
			$block   = in_array( $type, [ 'toggle', 'textarea', 'image' ], true ) ? 'row:' . $key : 'grid:' . ( $field['group'] ?? '' ) . '|' . $show_if;
			$last    = array_key_last( $blocks );

			// A grid continues while the next field belongs to it (same group, shown with the same toggle)
			if ( null === $last || $blocks[ $last ]['id'] !== $block || 0 === strpos( $block, 'row:' ) ) {
				$blocks[] = [ 'id' => $block, 'fields' => [], 'show_if' => $show_if ];
				$last     = array_key_last( $blocks );
			}

			$blocks[ $last ]['fields'][ $key ] = $field;
		}
		?>
		<section class="vlt-settings-page__panel" id="vlt-settings-panel-<?php echo esc_attr( $section ); ?>" role="tabpanel" aria-labelledby="vlt-settings-tab-<?php echo esc_attr( $section ); ?>" tabindex="0"<?php echo $open ? '' : ' hidden'; ?>>
			<div class="vlt-settings-page__head">
				<h2><?php echo esc_html( $definition['title'] ); ?></h2>
				<?php if ( !empty( $definition['description'] ) ) : ?>
					<p><?php echo wp_kses( $definition['description'], self::HELP_HTML ); ?></p>
				<?php endif; ?>
			</div>

			<?php
			// Notes the module adds above the fields (e.g. a conflict it detected)
			foreach ( (array) ( $definition['notices'] ?? [] ) as $notice ) :
				?>
				<p class="vlt-settings-page__note is-<?php echo esc_attr( $notice['type'] ?? 'info' ); ?>"><?php echo esc_html( $notice['text'] ); ?></p>
			<?php endforeach; ?>

			<?php
			foreach ( $blocks as $block ) :
				if ( 0 === strpos( $block['id'], 'row:' ) ) {
					foreach ( $block['fields'] as $key => $field ) {
						$this->render_field( $section, $key, $field, $values );
					}

					continue;
				}

				$group = $definition['groups'][ (string) strstr( substr( $block['id'], 5 ), '|', true ) ] ?? null;
				// "columns": fields per row (default: as many as fit)
				$columns = !empty( $definition['columns'] ) ? ' style="--vlt-settings-columns:' . (int) $definition['columns'] . '"' : '';
				// "show_if": shown while that toggle is on (admin-settings.js follows it as it changes)
				$show_if = $group['show_if'] ?? $block['show_if'];
				?>
				<div class="vlt-settings-page__block"<?php if ( $show_if ) : ?> data-vlt-settings-show-if="vlt-settings-<?php echo esc_attr( $section . '-' . $show_if ); ?>"<?php echo empty( $values[ $show_if ] ) ? ' hidden' : ''; ?><?php endif; ?>>
					<?php if ( $group ) : ?>
						<div class="vlt-settings-page__block-head">
							<h3><?php if ( !empty( $group['icon'] ) ) : ?><span class="vlt-settings-page__block-icon" aria-hidden="true"><?php echo $group['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?></span><?php endif; ?><?php echo esc_html( $group['title'] ); ?><?php if ( !empty( $group['status'] ) ) : ?> <span class="vlt-settings-page__status is-<?php echo esc_attr( $group['status'][1] ?? 'muted' ); ?>"><?php echo esc_html( $group['status'][0] ); ?></span><?php endif; ?></h3>
							<?php if ( !empty( $group['description'] ) ) : ?>
								<p><?php echo wp_kses( $group['description'], self::HELP_HTML ); ?></p>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<div class="vlt-settings-page__grid"<?php echo $columns; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- an int ?>>
						<?php
						foreach ( $block['fields'] as $key => $field ) {
							$this->render_field( $section, $key, $field, $values );
						}
						?>
					</div>

					<?php
					// Example address of a slug field, updated as it is typed (admin-settings.js)
					foreach ( $block['fields'] as $key => $field ) :
						if ( !empty( $field['preview'] ) ) :
							[ $before, $after ] = array_pad( explode( '%s', $field['preview'], 2 ), 2, '' );
							?>
							<p class="vlt-settings-page__preview" data-vlt-settings-preview="vlt-settings-<?php echo esc_attr( $section . '-' . $key ); ?>"><?php echo esc_html( $before ); ?><b><?php echo esc_html( $values[ $key ] ); ?></b><?php echo esc_html( $after ); ?></p>
							<?php
						endif;
					endforeach;
					?>
				</div>
			<?php endforeach; ?>
		</section>
		<?php
	}

	/**
	 * One field: a toggle or textarea row, or a labeled input of a grid
	 *
	 * @param string $section Section
	 * @param string $key     Field key
	 * @param array  $field   Field
	 * @param array  $values  Current values of the section
	 */
	private function render_field( $section, $key, array $field, array $values ) {
		$value = $values[ $key ];
		$id    = 'vlt-settings-' . $section . '-' . $key;
		$name = $this->args['option'] . '[' . $section . '][' . $key . ']';
		$type = $field['type'] ?? 'number';
		$unit = !empty( $field['unit'] ) ? ', ' . $field['unit'] : '';

		if ( 'toggle' === $type ) :
			// "show_if": shown while that toggle is on (admin-settings.js follows it as it changes)
			$show_if = $field['show_if'] ?? '';
			?>
			<div class="vlt-settings-page__row"<?php if ( $show_if ) : ?> data-vlt-settings-show-if="vlt-settings-<?php echo esc_attr( $section . '-' . $show_if ); ?>"<?php echo empty( $values[ $show_if ] ) ? ' hidden' : ''; ?><?php endif; ?>>
				<div class="vlt-settings-page__row-text">
					<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
					<?php if ( !empty( $field['help'] ) ) : ?>
						<p><?php echo wp_kses( $field['help'], self::HELP_HTML ); ?></p>
					<?php endif; ?>
				</div>
				<?php // Unchecked boxes are not sent: the hidden 0 keeps "off" as a saved choice ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="0">
				<input type="checkbox" class="vlt-settings-page__switch" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $value ); ?>>
			</div>
			<?php
			return;
		endif;

		if ( 'image' === $type ) :
			// A picked image of the Media Library (admin-settings.js opens it)
			$image = $value ? wp_get_attachment_image( $value, 'medium' ) : '';
			?>
			<div class="vlt-settings-page__row is-image">
				<div class="vlt-settings-page__row-text">
					<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
					<?php if ( !empty( $field['help'] ) ) : ?>
						<p><?php echo wp_kses( $field['help'], self::HELP_HTML ); ?></p>
					<?php endif; ?>
				</div>
				<div class="vlt-settings-page__image" data-vlt-settings-image data-title="<?php echo esc_attr( $field['label'] ); ?>" data-empty="<?php esc_attr_e( 'No image', 'reform-contact-form' ); ?>">
					<input type="hidden" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
					<button type="button" class="vlt-settings-page__image-preview<?php echo $image ? '' : ' is-empty'; ?>" data-vlt-settings-image-choose aria-label="<?php esc_attr_e( 'Choose image', 'reform-contact-form' ); ?>">
						<?php echo $image ?: '<span>' . esc_html__( 'No image', 'reform-contact-form' ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_get_attachment_image() ?>
					</button>
					<div class="vlt-settings-page__image-actions">
						<button type="button" class="vlt-settings-page__button" data-vlt-settings-image-choose><?php esc_html_e( 'Choose image', 'reform-contact-form' ); ?></button>
						<button type="button" class="vlt-settings-page__button is-link" data-vlt-settings-image-remove<?php echo $image ? '' : ' hidden'; ?>><?php esc_html_e( 'Remove', 'reform-contact-form' ); ?></button>
					</div>
				</div>
			</div>
			<?php
			return;
		endif;
		?>
		<div class="vlt-settings-page__field<?php echo 'textarea' === $type ? ' is-wide' : ''; ?>">
			<label for="<?php echo esc_attr( $id ); ?>">
				<?php if ( !empty( $field['icon'] ) && str_starts_with( $field['icon'], '<svg' ) ) : ?>
					<span class="vlt-settings-page__icon" aria-hidden="true"><?php echo $field['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?></span>
				<?php elseif ( !empty( $field['icon'] ) ) : ?>
					<span class="dashicons dashicons-<?php echo esc_attr( $field['icon'] ); ?>" aria-hidden="true"></span>
				<?php endif; ?>
				<?php echo esc_html( $field['label'] . $unit ); ?>
			</label>

			<?php if ( 'textarea' === $type ) : ?>
				<textarea class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="<?php echo esc_attr( $field['rows'] ?? 4 ); ?>" placeholder="<?php echo esc_attr( $field['placeholder'] ?? '' ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
			<?php elseif ( 'text' === $type ) : ?>
				<input type="text" class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" placeholder="<?php echo esc_attr( $field['placeholder'] ?? '' ); ?>">
			<?php elseif ( 'secret' === $type ) : ?>
				<?php // Its mask, never the key: kept while left as is, replaced when typed over, removed when emptied ?>
				<input type="text" class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( self::mask( (string) $value ) ); ?>" autocomplete="off" spellcheck="false" placeholder="<?php echo esc_attr( $field['placeholder'] ?? '' ); ?>">
			<?php elseif ( 'slug' === $type ) : ?>
				<input type="text" class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" placeholder="<?php echo esc_attr( $field['default'] ); ?>" spellcheck="false">
			<?php elseif ( 'select' === $type ) : ?>
				<select class="vlt-settings-page__input" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>">
					<?php foreach ( $field['options'] as $option => $label ) : ?>
						<option value="<?php echo esc_attr( $option ); ?>" <?php selected( (string) $value, (string) $option ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			<?php else : ?>
				<input
					type="number"
					class="vlt-settings-page__input"
					id="<?php echo esc_attr( $id ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					value="<?php echo esc_attr( $value ); ?>"
					min="<?php echo esc_attr( $field['min'] ); ?>"
					max="<?php echo esc_attr( $field['max'] ); ?>"
					placeholder="<?php echo esc_attr( $field['default'] ); ?>"
				>
			<?php endif; ?>

			<?php if ( !empty( $field['help'] ) ) : ?>
				<p><?php echo wp_kses( $field['help'], self::HELP_HTML ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}
}
