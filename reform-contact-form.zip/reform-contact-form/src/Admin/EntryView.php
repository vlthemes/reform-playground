<?php

namespace VLT\Reform\Admin;

use VLT\Reform\Core\PostType;
use VLT\Reform\Entries\Entries;

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One entry: its values and where it came from (Contact Form → Entries → View); opening it marks it read
 */
class EntryView {
	const PAGE = 'reform-entry';

	/**
	 * Address of an entry
	 *
	 * @param int $id Entry ID
	 *
	 * @return string
	 */
	public static function url( $id ) {
		return admin_url( 'admin.php?page=' . self::PAGE . '&entry=' . (int) $id );
	}

	/**
	 * Opening an entry marks it read
	 */
	public static function open() {
		$id = absint( $_GET['entry'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which entry is open

		if ( $id && Entries::POST_TYPE === get_post_type( $id ) && current_user_can( 'edit_post', $id ) ) {
			Entries::mark_read( $id );
		}
	}

	/**
	 * The screen
	 */
	public static function render() {
		$id   = absint( $_GET['entry'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- which entry to show
		$post = $id ? get_post( $id ) : null;

		if ( !$post || Entries::POST_TYPE !== $post->post_type || !current_user_can( 'edit_post', $id ) ) {
			wp_die( esc_html__( 'This entry doesn\'t exist, or you can\'t see it.', 'reform-contact-form' ) );
		}

		$data = Entries::data( $id );
		$meta = Entries::meta( $id );
		$form = PostType::NAME === get_post_type( $post->post_parent ) ? (int) $post->post_parent : 0;
		$user = $meta['user_id'] ? get_userdata( (int) $meta['user_id'] ) : null;
		?>
		<div class="wrap vlt-settings-page reform-entry">
			<h1 class="screen-reader-text"><?php echo esc_html( get_the_title( $post ) ); ?></h1>
			<hr class="wp-header-end">

			<?php Settings::page()->header( __( 'entry', 'reform-contact-form' ) ); ?>

			<div class="vlt-settings-page__card reform-entry__card">
				<div class="reform-entry__head">
					<div>
						<h2><?php echo esc_html( get_the_title( $post ) ?: __( '(no title)', 'reform-contact-form' ) ); ?></h2>
						<p>
							<?php
							/* translators: 1: date, 2: time */
							echo esc_html( sprintf( __( 'Sent on %1$s at %2$s', 'reform-contact-form' ), get_the_date( '', $post ), get_the_time( '', $post ) ) );
							?>
							<?php if ( get_post_meta( $id, '_reform_mail_failed', true ) ) : ?>
								<span class="reform-entry-flag"><?php esc_html_e( 'The mail for this message could not be sent', 'reform-contact-form' ); ?></span>
							<?php endif; ?>
						</p>
					</div>
					<div class="reform-entry__actions">
						<a class="vlt-settings-page__button" href="<?php echo esc_url( admin_url( EntriesList::LIST_PAGE ) ); ?>"><?php esc_html_e( 'All entries', 'reform-contact-form' ); ?></a>
						<?php if ( current_user_can( 'delete_post', $id ) ) : ?>
							<a class="vlt-settings-page__button is-danger" href="<?php echo esc_url( get_delete_post_link( $id ) ); ?>"><?php esc_html_e( 'Move to trash', 'reform-contact-form' ); ?></a>
						<?php endif; ?>
					</div>
				</div>

				<table class="reform-entry__values">
					<?php foreach ( $data as $name => $item ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( ucfirst( str_replace( [ '_', '-' ], ' ', $name ) ) ); ?> <code>[<?php echo esc_html( $name ); ?>]</code></th>
							<td>
								<?php if ( '' === trim( $item['value'] ) ) : ?>
									<span class="reform-entry__empty"><?php esc_html_e( 'Left empty', 'reform-contact-form' ); ?></span>
								<?php elseif ( 'email' === $item['type'] && is_email( $item['value'] ) ) : ?>
									<a href="mailto:<?php echo esc_attr( $item['value'] ); ?>"><?php echo esc_html( $item['value'] ); ?></a>
								<?php else : ?>
									<?php echo nl2br( esc_html( $item['value'] ) ); ?>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>

				<h3 class="reform-entry__subtitle"><?php esc_html_e( 'Details', 'reform-contact-form' ); ?></h3>
				<table class="reform-entry__values is-details">
					<tr>
						<th scope="row"><?php esc_html_e( 'Form', 'reform-contact-form' ); ?></th>
						<td><?php echo $form ? '<a href="' . esc_url( Admin::edit_url( $form ) ) . '">' . esc_html( get_the_title( $form ) ) . '</a>' : esc_html__( 'Deleted', 'reform-contact-form' ); ?></td>
					</tr>
					<?php if ( $meta['url'] ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'Sent from', 'reform-contact-form' ); ?></th>
							<td><a href="<?php echo esc_url( $meta['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $meta['url'] ); ?></a></td>
						</tr>
					<?php endif; ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'User', 'reform-contact-form' ); ?></th>
						<td><?php echo $user ? esc_html( $user->display_name ) : esc_html__( 'A visitor, not logged in', 'reform-contact-form' ); ?></td>
					</tr>
					<?php if ( $meta['ip'] ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'IP address', 'reform-contact-form' ); ?></th>
							<td><?php echo esc_html( $meta['ip'] ); ?></td>
						</tr>
					<?php endif; ?>
					<?php if ( $meta['user_agent'] ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'Browser', 'reform-contact-form' ); ?></th>
							<td><?php echo esc_html( $meta['user_agent'] ); ?></td>
						</tr>
					<?php endif; ?>
				</table>
			</div>
		</div>
		<?php
	}
}
