<?php
/**
 * The editor's preview: the theme's styles and scripts, no header or footer
 *
 * Variables: $html (the form), $form.
 * Hooks: reform_preview_body_class and reform_preview_classes ( $classes, $form ),
 * reform_preview_before / reform_preview_after ( $form ) around the form (a theme's icon sprite, a card around it).
 *
 * @package VLT\Reform
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

$reform_body_class = (array) apply_filters( 'reform_preview_body_class', [ 'reform-preview-body' ], $form );
$reform_classes    = implode( ' ', array_map( 'sanitize_html_class', (array) apply_filters( 'reform_preview_classes', [ 'reform-preview' ], $form ) ) );
?><!DOCTYPE html>
<html <?php language_attributes(); ?> style="margin-top:0 !important">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex">
	<?php wp_head(); ?>
</head>
<body <?php body_class( $reform_body_class ); ?>>
	<main class="<?php echo esc_attr( $reform_classes ); ?>">
		<?php do_action( 'reform_preview_before', $form ); ?>
		<?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered form ?>
		<?php do_action( 'reform_preview_after', $form ); ?>
	</main>
	<?php wp_footer(); ?>
</body>
</html>
