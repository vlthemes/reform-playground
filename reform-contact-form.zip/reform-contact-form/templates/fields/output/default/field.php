<?php
/**
 * A mirror of another field's value
 *
 * Variables: $field (settings, with name and type), $control (the input, printed by the field), $error (its
 * message, hidden until there is one), $choices (checkbox and radio: each option's value, label, id, input and
 * control), $form.
 * Copy to your-theme/reform/fields/output/default/field.php to change it, or to a folder of your own next to default/ for a new style.
 *
 * @package VLT\Reform
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

echo $control; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped by the field
