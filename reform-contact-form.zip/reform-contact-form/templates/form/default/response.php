<?php
/**
 * What the response box shows after sending
 *
 * Variables: $status (success, invalid, failed, spam, aborted, locked: logged-in users only), $message, $form.
 * Copy to your-theme/reform/form/default/response.php to change it.
 *
 * @package VLT\Reform
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="reform-alert reform-alert--<?php echo esc_attr( $status ); ?>">
	<?php echo reform_icon( 'success' === $status ? 'check' : 'alert', 'reform-alert__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own SVG ?>
	<span class="reform-alert__text"><?php echo esc_html( $message ); ?></span>
</div>
