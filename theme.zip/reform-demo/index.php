<?php
/**
 * Every page of the demo: header, the post or the list, footer
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="header">
	<div class="wrap">
		<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<span class="logo__mark" aria-hidden="true">Re:</span>
			<?php bloginfo( 'name' ); ?>
		</a>
		<nav class="nav" aria-label="<?php esc_attr_e( 'Main', 'reform-demo' ); ?>">
			<?php wp_nav_menu( [ 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'wp_page_menu', 'depth' => 1 ] ); ?>
		</nav>
	</div>
</header>

<main class="main">
	<div class="wrap">
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class( 'entry' ); ?>>
				<h1><?php the_title(); ?></h1>
				<?php the_content(); ?>
			</article>
		<?php endwhile; ?>
	</div>
</main>

<footer class="footer">
	<div class="wrap">
		<span><?php bloginfo( 'name' ); ?></span>
		<span><?php printf( esc_html__( 'Forms by %s', 'reform-demo' ), '<a href="https://wordpress.org/plugins/reform-contact-form/">ReForm</a>' ); ?></span>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
