<?php
/**
 * Reform Demo: the theme of the Reform demo on WordPress Playground (scripts/build-playground.js zips it)
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', static function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', [ 'search-form', 'gallery', 'caption', 'style', 'script' ] );
	add_theme_support( 'responsive-embeds' );

	register_nav_menus( [ 'primary' => __( 'Header', 'reform-demo' ) ] );
} );

add_action( 'wp_enqueue_scripts', static function () {
	// The demo runs with networking on
	wp_enqueue_style( 'reform-demo-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400..700&display=swap', [], null );
	wp_enqueue_style( 'reform-demo', get_stylesheet_uri(), [ 'reform-demo-fonts' ], wp_get_theme()->get( 'Version' ) );
} );
